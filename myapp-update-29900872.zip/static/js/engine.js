/* Free offline notes engine.
   Turns PDF/OCR/pasted text lines into: sections, key points, key terms, mind map,
   flashcards, quiz, exam questions, memory tricks and a checklist. No AI needed. */
"use strict";
const Engine = (() => {
  const STOP = new Set(("a an the and or but if then else of to in on at by for with from as is are was were be been being this that these those it its into than such can could may might will would shall should do does did done not no nor so too very also only just more most less least many much each every some any all both either neither one two three four five first second third there their they them we our you your he she his her i me my which who whom whose what when where why how about above below over under between through during before after again further once here out up down off same other own few use used uses using via per eg ie etc fig figure table page pages slide slides unit chapter section example examples called given following follows thus hence therefore however since because while where whereas also let lets get gets got make makes made like well way ways new used shown show shows see note notes important etc. ex e.g i.e").split(" "));
  const BUL = /^\s*(?:[•●▪◦○■□►▸➢➤✓✔\-–—*·]|\(?\d{1,2}[.)]|\(?[a-hA-H][.)]|\(?(?:i|ii|iii|iv|v|vi|vii|viii|ix|x)\))\s+/;
  const words = t => (t.toLowerCase().match(/[a-z][a-z0-9\-]{2,}/g) || []).filter(w => !STOP.has(w));
  const wc = t => t.split(/\s+/).filter(Boolean).length;
  const cap = s => s ? s[0].toUpperCase() + s.slice(1) : s;
  const uniq = (arr, key = x => x) => { const s = new Set(); return arr.filter(x => { const k = key(x); if (s.has(k)) return false; s.add(k); return true; }); };
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const stripNum = t => t.replace(/^\s*((unit|chapter|module|section|part|lecture)\s*[\divxlc]+[:.\-–)]*|\d+(\.\d+)*[.)]?|[ivx]+\.)\s*/i, "").replace(/[:\-–]\s*$/, "").trim();
  const shortLabel = (t, n = 4) => { const w = stripNum(t).split(/\s+/); return w.slice(0, n).join(" ") + (w.length > n ? "…" : ""); };
  const shorten = (t, n = 32) => { const w = t.split(/\s+/); if (w.length <= n) return t; const cut = t.search(/[;,:]\s/); if (cut > 40 && wc(t.slice(0, cut)) <= n) return t.slice(0, cut) + "."; return w.slice(0, n).join(" ") + "…"; };
  const median = arr => { const a = [...arr].sort((x, y) => x - y); return a.length ? a[Math.floor(a.length / 2)] : 0; };

  /* ---------- reading ---------- */
  async function readPdf(file, onPage) {
    const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer(), isEvalSupported: false }).promise;
    let meta = null; try { meta = (await pdf.getMetadata()).info; } catch { }
    const lines = [], N = Math.min(pdf.numPages, 500);
    for (let p = 1; p <= N; p++) {
      onPage && onPage(p, N);
      const page = await pdf.getPage(p), tc = await page.getTextContent();
      const rows = [];
      for (const it of tc.items) {
        if (!it.str || !it.str.trim()) continue;
        const y = it.transform[5], x = it.transform[4], s = Math.abs(it.transform[3]) || it.height || 10;
        let r = null;
        for (let k = rows.length - 1; k >= 0 && k >= rows.length - 6; k--) if (Math.abs(rows[k].y - y) < Math.max(2, s * .45)) { r = rows[k]; break; }
        if (!r) { r = { y, items: [], s: 0 }; rows.push(r); }
        r.items.push({ x, str: it.str, w: it.width || 0 }); r.s = Math.max(r.s, s);
      }
      rows.sort((a, b) => b.y - a.y);
      for (const r of rows) {
        r.items.sort((a, b) => a.x - b.x);
        let txt = "", end = null; const segs = [];   // segs: the separate table cells / columns on this line
        for (const i of r.items) {
          if (end === null || i.x - end > r.s * 2) segs.push({ t: "", x0: i.x, x1: i.x }); else if (i.x - end > r.s * .2 && !/\s$/.test(segs[segs.length - 1].t)) segs[segs.length - 1].t += " ";
          segs[segs.length - 1].t += i.str; segs[segs.length - 1].x1 = i.x + i.w;
          if (end !== null && i.x - end > r.s * .2 && !/\s$/.test(txt) && !/^\s/.test(i.str)) txt += " "; txt += i.str; end = i.x + i.w; }
        txt = txt.replace(/\s+/g, " ").trim();
        if (txt) lines.push({ t: txt, s: Math.round(r.s * 10) / 10, p, y: Math.round(r.y), segs: segs.map(s => ({ t: s.t.replace(/\s+/g, " ").trim(), x0: Math.round(s.x0), x1: Math.round(s.x1) })).filter(s => s.t) });
      }
    }
    return { pdf, lines, meta, pages: N };
  }

  let tess = null;
  async function ocr(canvasesOrFiles, onPage) {
    if (!window.Tesseract) await new Promise((ok, bad) => { const s = document.createElement("script"); s.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js"; s.onload = ok; s.onerror = () => bad(new Error("Free OCR needs internet the first time.")); document.head.appendChild(s); });
    tess = tess || await Tesseract.createWorker("eng");
    const lines = [];
    for (let i = 0; i < canvasesOrFiles.length; i++) {
      onPage && onPage(i + 1, canvasesOrFiles.length);
      const { data } = await tess.recognize(canvasesOrFiles[i]);
      const ls = data.lines && data.lines.length ? data.lines.map(l => ({ t: l.text.trim(), s: Math.round((l.bbox.y1 - l.bbox.y0) / 2) })) : data.text.split("\n").map(t => ({ t: t.trim(), s: 10 }));
      ls.filter(l => l.t.length > 1 && /[a-z]{2}/i.test(l.t)).forEach(l => lines.push({ ...l, p: i + 1 }));
    }
    return lines;
  }
  // words with their position on the page (top-down y), from free OCR: for scanned timetables
  async function ocrWords(canvases, onPage) {
    if (!window.Tesseract) await new Promise((ok, bad) => { const s = document.createElement("script"); s.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js"; s.onload = ok; s.onerror = () => bad(new Error("Free OCR needs internet the first time.")); document.head.appendChild(s); });
    tess = tess || await Tesseract.createWorker("eng");
    const pages = [];
    for (let i = 0; i < canvases.length; i++) {
      onPage && onPage(i + 1, canvases.length);
      const { data } = await tess.recognize(canvases[i]);
      pages.push({ page: i + 1, words: (data.words || []).map(w => ({ t: w.text.trim(), x0: w.bbox.x0, y0: w.bbox.y0, x1: w.bbox.x1, y1: w.bbox.y1 })).filter(w => w.t),
        lines: (data.lines || []).map(l => ({ t: l.text.trim(), y: (l.bbox.y0 + l.bbox.y1) / 2, x0: l.bbox.x0 })) });
    }
    return pages;
  }
  // scanned timetables: find the student's page from its heading, then read it closely (two OCR passes, merged)
  async function renderPage(pdf, p, scale, bw, crop) {
    const page = await pdf.getPage(p), vp = page.getViewport({ scale });
    const c = document.createElement("canvas"); c.width = vp.width; c.height = Math.round(vp.height * (crop || 1));
    const ctx = c.getContext("2d"); await page.render({ canvasContext: ctx, viewport: vp }).promise;
    if (bw) { const im = ctx.getImageData(0, 0, c.width, c.height), d = im.data;
      for (let i = 0; i < d.length; i += 4) { const v = .3 * d[i] + .59 * d[i + 1] + .11 * d[i + 2] < 170 ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = v; } ctx.putImageData(im, 0, 0); }
    return c;
  }
  async function ocrPass(canvas, psm) {
    tess = tess || await Tesseract.createWorker("eng");
    await tess.setParameters({ tessedit_pageseg_mode: psm });
    const { data } = await tess.recognize(canvas);
    return { text: data.text, words: (data.words || []).map(w => ({ t: w.text.trim(), x0: w.bbox.x0, y0: w.bbox.y0, x1: w.bbox.x1, y1: w.bbox.y1 })).filter(w => w.t),
      lines: (data.lines || []).map(l => ({ t: l.text.trim(), y: (l.bbox.y0 + l.bbox.y1) / 2, x0: l.bbox.x0 })) };
  }
  const loadOcr = () => window.Tesseract ? Promise.resolve() : new Promise((ok, bad) => { const s = document.createElement("script"); s.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js"; s.onload = ok; s.onerror = () => bad(new Error("Free OCR needs internet the first time.")); document.head.appendChild(s); });
  async function headingText(pdf, p) { await loadOcr(); return (await ocrPass(await renderPage(pdf, p, 2, false, .16), "6")).text; }
  async function ocrTimetable(pdf, isMine, onStep) {
    await loadOcr();
    const N = Math.min(pdf.numPages, 15), heads = [];
    for (let p = 1; p <= N; p++) { onStep && onStep(`Checking page ${p} of ${N}…`); heads.push({ p, text: (await ocrPass(await renderPage(pdf, p, 2, false, .16), "6")).text }); }
    let pick = heads.filter(h => isMine(h.text)).map(h => h.p);
    if (!pick.length) pick = heads.map(h => h.p);
    const pages = [];
    for (const p of pick) {
      onStep && onStep(`Reading your page (${p}) closely…`);
      const a = await ocrPass(await renderPage(pdf, p, 4, true), "11"), b = await ocrPass(await renderPage(pdf, p, 4, false), "6");
      pages.push({ page: p, heading: heads[p - 1].text, words: [...a.words, ...b.words], lines: [...a.lines, ...b.lines] });
    }
    await tess.setParameters({ tessedit_pageseg_mode: "3" });
    return { pages, picked: pick, total: N };
  }
  async function pdfPagesToCanvas(pdf, max, scale = 2) {
    const out = [];
    for (let p = 1; p <= Math.min(pdf.numPages, max); p++) {
      const page = await pdf.getPage(p), vp = page.getViewport({ scale });
      const c = document.createElement("canvas"); c.width = vp.width; c.height = vp.height;
      await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise; out.push(c);
    }
    return out;
  }
  function textToLines(text) {
    return text.split(/\r?\n/).map(t => t.replace(/\s+/g, " ").trim()).filter(Boolean).map(t => {
      const md = t.match(/^(#{1,4})\s+(.*)/);
      return md ? { t: md[2], s: 20 - md[1].length * 2, p: 1, md: md[1].length } : { t, s: 10, p: 1 };
    });
  }

  /* ---------- structure ---------- */
  function bodySize(lines) {
    const buckets = new Map();
    lines.forEach(l => buckets.set(l.s, (buckets.get(l.s) || 0) + l.t.length));
    let best = 10, n = -1; buckets.forEach((v, k) => { if (v > n) { n = v; best = k; } });
    return best;
  }
  function clean(lines, pages, body) {
    const key = t => t.toLowerCase().replace(/\d+/g, "#").replace(/\s+/g, " ").trim();
    const seen = new Map();
    lines.forEach(l => { const k = key(l.t); if (!seen.has(k)) seen.set(k, new Set()); seen.get(k).add(l.p); });
    return lines.filter(l => {
      const k = key(l.t);
      if (/^[#\s\-–|/.:()]*$/.test(k) || /^(page|slide)\s*#( of #)?$/.test(k)) return false;
      if (pages >= 4 && seen.get(k).size >= Math.max(3, pages * .3) && l.s <= body * 1.05 && l.t.length < 100) return false;
      return true;
    });
  }
  const NUMBERED = /^((\d+(\.\d+){0,3})[.)]?|(unit|chapter|module|section|part|lecture)\s*[\divxlc]+[:.\-–)]?)\s+[A-Z(]/i;
  function isHeadingText(t) {
    return t.length >= 2 && t.length <= 100 && /[A-Za-z]{2}/.test(t) && !/[,;]$/.test(t) && !(/\.$/.test(t) && wc(t) > 6) && wc(t) <= 14 && !/^(fig|figure|table)\s*\d/i.test(t);
  }
  function detectHeadings(lines, body, uniform) {
    const heads = [];
    lines.forEach((l, i) => {
      let h = false, lvl = 0;
      if (l.md) { h = true; lvl = l.md; }
      else if (!uniform && l.s >= body * 1.15 && isHeadingText(l.t)) h = true;
      else if (NUMBERED.test(l.t) && isHeadingText(l.t) && !BUL.test(l.t.replace(NUMBERED, m => m))) {
        const m = l.t.match(/^(\d+(\.\d+){0,3})[.)]?\s/);
        if (m && wc(l.t) <= 10 && !/[.]$/.test(l.t)) { h = true; lvl = m[1].split(".").length; }
        else if (/^(unit|chapter|module|section|part|lecture)/i.test(l.t)) { h = true; lvl = 1; }
      } else if (uniform && isHeadingText(l.t) && wc(l.t) <= 8 && (l.t === l.t.toUpperCase() && /[A-Z]{3}/.test(l.t) || /:$/.test(l.t) && wc(l.t) <= 6)) h = true;
      if (h) heads.push({ i, lvl });
    });
    // levels by font size when not numbered/markdown
    const sizes = uniq(heads.filter(h => !h.lvl).map(h => lines[h.i].s)).sort((a, b) => b - a);
    const clusters = [];
    sizes.forEach(s => { const c = clusters.find(c => Math.abs(c - s) < .8); if (!c) clusters.push(s); });
    heads.forEach(h => { if (!h.lvl) { const s = lines[h.i].s; h.lvl = Math.min(3, clusters.findIndex(c => Math.abs(c - s) < .8) + 1 || 2); } });
    return heads;
  }

  function buildSections(lines, pages, fileName) {
    const body = bodySize(lines);
    const uniform = new Set(lines.map(l => l.s)).size <= 2;
    lines = clean(lines, pages, body);
    const chars = lines.reduce((n, l) => n + l.t.length, 0);
    const slides = pages >= 5 && chars / pages < 900 && !uniform;
    let title = "", secs = [];
    if (slides) {
      // one title per slide: the biggest line near the top of the page
      const byPage = new Map(); lines.forEach(l => { if (!byPage.has(l.p)) byPage.set(l.p, []); byPage.get(l.p).push(l); });
      const norm = t => stripNum(t).toLowerCase().replace(/\(?(contd|cont'd|continued|cont)\.?\)?/g, "").replace(/\s*[-–(]?\s*\d+\s*\)?$/, "").trim();
      [...byPage.entries()].forEach(([p, ls]) => {
        const max = Math.max(...ls.slice(0, 6).map(l => l.s));
        const ti = ls.findIndex(l => l.s === max && isHeadingText(l.t));
        const tline = ti >= 0 && max >= body * 1.05 ? ls[ti] : null;
        const rest = ls.filter((_, k) => k !== ti);
        if (p === 1 && !title && tline) { title = tline.t; return; }
        const head = tline ? tline.t : (secs.length ? secs[secs.length - 1].heading : "Introduction");
        const last = secs[secs.length - 1];
        if (last && norm(last.heading) === norm(head)) last.lines.push(...rest);
        else secs.push({ heading: head, level: 1, lines: rest, subs: [] });
      });
    } else {
      const heads = detectHeadings(lines, body, uniform);
      // document title: biggest heading on page 1, used once
      if (heads.length) {
        const first = heads.filter(h => lines[h.i].p === 1).sort((a, b) => lines[b.i].s - lines[a.i].s)[0];
        if (first && heads.filter(h => lines[h.i].s >= lines[first.i].s - .3).length === 1 && heads.length > 2) { title = lines[first.i].t; heads.splice(heads.indexOf(first), 1); }
      }
      const levels = uniq(heads.map(h => h.lvl)).sort();
      let top = levels[0] || 1;
      if (heads.filter(h => h.lvl === top).length === 1 && levels.length > 1) { const only = heads.find(h => h.lvl === top); if (!title) title = lines[only.i].t; heads.splice(heads.indexOf(only), 1); top = levels[1]; }
      const isHead = new Map(heads.map(h => [h.i, h.lvl]));
      let cur = null, sub = null;
      lines.forEach((l, i) => {
        if (isHead.has(i)) {
          const lv = isHead.get(i);
          const prev = sub || cur;
          if (prev && !prev.lines.length && lv === prev.level && lines[i - 1] && isHead.has(i - 1) && (prev.heading + " " + l.t).length < 100) { prev.heading += " " + l.t; return; }
          if (lv <= top || !cur) { cur = { heading: l.t, level: 1, lines: [], subs: [] }; secs.push(cur); sub = null; }
          else { sub = { heading: l.t, level: 2, lines: [] }; cur.subs.push(sub); }
        } else {
          if (!cur) { cur = { heading: "Introduction", level: 1, lines: [], subs: [] }; secs.push(cur); }
          (sub || cur).lines.push(l);
        }
      });
    }
    secs = secs.filter(s => s.lines.length || s.subs.some(x => x.lines.length));
    if (!title) title = (fileName || "My notes").replace(/\.(pdf|png|jpe?g|txt)$/i, "").replace(/[_-]+/g, " ");
    return { title, secs };
  }

  /* ---------- text items ---------- */
  function toItems(lines) {
    const out = [];
    for (const l of lines) {
      const t = l.t;
      const last = out[out.length - 1];
      if (BUL.test(t)) out.push({ b: true, t: t.replace(BUL, "").trim() });
      else if (last && !/[.:;!?]$/.test(last.t) && (/^[a-z(,]/.test(t) || (!last.b && last.t.length > 50))) last.t += " " + t;
      else out.push({ b: false, t });
    }
    const res = [];
    out.forEach(o => o.t = o.t.replace(/([a-z])- ([a-z])/g, "$1$2"));   // "Al- though" → "Although"
    out.forEach(o => {
      if (o.b || o.t.length < 160) { if (o.t.length > 2) res.push(o); return; }
      o.t.split(/(?<=[.!?])\s+(?=[A-Z(])/).forEach(s => s.length > 2 && res.push({ b: false, t: s }));
    });
    return res.filter(o => /[a-z]{2}/i.test(o.t));
  }
  const NOISE = /^\s*(what we will cover|agenda|outline|contents|table of contents|thank you|thanks|references|bibliography|questions\??|q\s*&\s*a|any questions|acknowledg|presented by|team members|about (me|us)|key words you will hear)/i;
  const isFormula = t => t.length < 160 && !/https?:|www\./.test(t) && wc(t) <= 22 && /[=≈≤≥∑Σ∫√∂∆→]/.test(t) && /[A-Za-zα-ω]/.test(t) && (t.match(/[=+\-*/^()×÷]/g) || []).length >= 2;
  const isExample = t => /^(e\.?g\.?|for example|example\s*[:\-–\d]|for instance|eg[:\s])/i.test(t) || /\bfor example\b/i.test(t);

  const TIPS = [
    [/advantage|disadvantage|merit|demerit|pros|cons|limitation|drawback|benefit/i, "Advantages and limitations are classic 5-mark questions. Learn at least 4 points each."],
    [/difference|\bvs\.?\b|versus|compar|distinguish/i, "Write differences as a table with 5 or more rows. Examiners love it."],
    [/algorithm|steps?\b|procedure|process|working|method|how to/i, "Number the steps and add a small diagram or worked example for full marks."],
    [/types?\b|classification|kinds?\b|categories/i, "Name every type with a one-line explanation and an example."],
    [/application|uses?\b|real.?world/i, "Give 3–4 real-world applications. Easy marks."],
    [/introduction|definition|what is|overview|basics/i, "Start your answer with a crisp one-line definition. That's an easy 2 marks."],
    [/architecture|structure|block diagram|model|layers?/i, "Draw the diagram first, label every part, then explain each block in one line."],
    [/properties|characteristics|features/i, "List the properties as short numbered points, ideally 5 or more."],
    [/theorem|proof|derivation|derive/i, "Practise this derivation once in writing. Long-answer favourite."],
  ];

  /* ---------- main ---------- */
  function build(lines, opts = {}) {
    const { title, secs } = buildSections(lines, opts.pages || 1, opts.fileName);
    const S = secs.slice(0, 60);
    S.forEach(s => { s.items = toItems(s.lines); s.subs.forEach(x => x.items = toItems(x.lines)); s.all = [...s.items, ...s.subs.flatMap(x => x.items)]; });
    // keyword statistics
    const tf = new Map(), df = new Map(), surface = new Map(), bi = new Map();
    S.forEach(s => {
      const seen = new Set();
      const text = [s.heading, ...s.subs.map(x => x.heading), ...s.all.map(i => i.t)].join(" \n ");
      (text.match(/[A-Za-z][A-Za-z0-9\-]{2,}/g) || []).forEach(raw => {
        const w = raw.toLowerCase(); if (STOP.has(w)) return;
        tf.set(w, (tf.get(w) || 0) + 1); seen.add(w);
        const m = surface.get(w) || new Map(); m.set(raw, (m.get(raw) || 0) + 1); surface.set(w, m);
      });
      seen.forEach(w => df.set(w, (df.get(w) || 0) + 1));
      text.split(/[.,;:()\n!?]/).forEach(ch => { const ws = (ch.match(/[A-Za-z][A-Za-z0-9\-]{2,}/g) || []); for (let i = 0; i + 1 < ws.length; i++) { const a = ws[i].toLowerCase(), b = ws[i + 1].toLowerCase(); if (STOP.has(a) || STOP.has(b) || a === b) continue; const k = a + " " + b; bi.set(k, (bi.get(k) || 0) + 1); } });
    });
    const N = Math.max(1, S.length);
    const idf = w => Math.log(1 + N / (df.get(w) || 1));
    const score = w => (tf.get(w) || 0) * idf(w);
    const sf = w => { const m = surface.get(w); if (!m) return w; let best = w, n = -1; m.forEach((v, k) => { if (v > n || (v === n && k !== k.toLowerCase())) { n = v; best = k; } }); return best; };
    const acronyms = new Set([...tf.keys()].filter(w => { const s = sf(w); return /^[A-Z]{2,6}s?$/.test(s) && tf.get(w) >= 2; }));
    let kws = [...tf.keys()].filter(w => tf.get(w) >= 2 && w.length > 3 || acronyms.has(w)).map(w => ({ k: w, label: sf(w), sc: score(w) * (acronyms.has(w) ? 1.6 : 1) }));
    [...bi.entries()].filter(([, c]) => c >= 2).forEach(([k, c]) => { const [a, b] = k.split(" "); kws.push({ k, label: sf(a) + " " + sf(b), sc: c * (idf(a) + idf(b)) * 1.7 }); });
    kws.sort((a, b) => b.sc - a.sc);
    // drop unigrams covered by a stronger bigram
    const big = kws.filter(k => k.k.includes(" ")).slice(0, 15);
    kws = kws.filter(k => k.k.includes(" ") || !big.some(b => b.k.split(" ").includes(k.k) && b.sc >= k.sc * .7));
    const topK = kws.slice(0, 40);
    const kwScore = new Map(topK.map(k => [k.k, k.sc]));
    const sentScore = t => { const ws = new Set(words(t)); let s = 0; ws.forEach(w => s += (score(w) || 0)); topK.forEach(k => { if (k.k.includes(" ") && t.toLowerCase().includes(k.k)) s += k.sc; }); return s / Math.sqrt(Math.max(6, wc(t))); };
    const hl = (t, extra = []) => {
      let n = 0;
      for (const k of [...extra, ...topK]) {
        if (n >= 2) break;
        const re = new RegExp("(^|[^\\w*])(" + k.label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")(?![\\w*])", "i");
        if (re.test(t) && !t.includes("**" + k.label)) { t = t.replace(re, "$1**$2**"); n++; }
      }
      return t;
    };
    const secKeywords = (s, n) => {
      const text = [s.heading, ...(s.all || s.items).map(i => i.t)].join(" ").toLowerCase();
      return topK.filter(k => text.includes(k.k)).map(k => ({ ...k, local: (text.split(k.k).length - 1) * k.sc })).sort((a, b) => b.local - a.local).slice(0, n);
    };

    // definitions
    const defs = [];
    const DEF = /^(?:an?\s+|the\s+)?([A-Za-z][\w\-()/' ]{1,48}?)\s+(?:is|are|refers to|is defined as|are defined as|is called|means|denotes|is known as|represents|can be defined as)\s+(.{12,260}?)\.?$/;
    const COLON = /^([A-Z][\w\-()/' ]{1,40}):\s+(.{12,240})$/;
    const BADTERM = /^(it|this|that|these|those|there|which|he|she|they|we|you|here|following|above|below|result|output|answer|data|value|example|figure|table|gap|idea|goal|aim|note|problem|step|why|what|how|our|my|key|main|one|each|all|both|today|so|then|also|first|next|finally|if|when|while|using|since|because|although|though|as|for|in|on|with|to|by|from|after|before|during|of|without|not|no)\b/i;
    S.forEach(s => s.all.forEach(i => {
      const colon = !i.t.match(DEF) && i.t.match(COLON);
      const m = i.t.match(DEF) || colon;
      if (!m) return;
      const term = m[1].trim(), mean = m[2].trim();
      if (wc(term) > (colon ? 4 : 6) || BADTERM.test(term) || /^\d|\[\d/.test(term) || wc(mean) < (colon ? 6 : 4)) return;
      if (colon && !/^(a|an|the|[a-z])/.test(mean)) return;   // "X: A, B, C" lists are not definitions
      const tl = term.toLowerCase();
      const strong = acronyms.has(tl) || words(term).some(w => kwScore.has(w)) || topK.some(k => tl.includes(k.k));
      if (strong) defs.push({ term: cap(term), meaning: cap(mean.replace(/\s+/g, " ")), sec: s.heading });
    }));
    const keyTerms = uniq(defs, d => d.term.toLowerCase()).slice(0, 16).map(d => ({ term: d.term, meaning: shorten(d.meaning, 30) }));
    topK.filter(k => !keyTerms.some(t => t.term.toLowerCase().includes(k.k))).slice(0, Math.max(0, 14 - keyTerms.length)).forEach(k => {
      let ctx = null; S.some(s => s.all.some(i => { if (i.t.toLowerCase().includes(k.k) && wc(i.t) >= 6 && wc(i.t) <= 40 && /[.!?)]$/.test(i.t)) { ctx = i.t; return true; } }));
      if (ctx) keyTerms.push({ term: cap(k.label), meaning: shorten(ctx, 26) });
    });

    // sections → notes
    const pick = (items, n) => {
      const bul = items.filter(i => i.b);
      const pool = bul.length >= 3 ? bul : items;
      const ranked = pool.map((it, idx) => ({ it, idx, sc: sentScore(it.t) + (it.b ? .5 : 0) - (isFormula(it.t) ? 5 : 0) })).filter(x => wc(x.it.t) >= 3);
      const keep = new Set(ranked.sort((a, b) => b.sc - a.sc).slice(0, n).map(x => x.idx));
      return pool.filter((_, idx) => keep.has(idx)).map(i => shorten(i.t, 32));
    };
    const sections = S.map(s => {
      const formula = uniq(s.all.filter(i => isFormula(i.t)).map(i => i.t)).slice(0, 3).join("\n") || null;
      const ex = s.all.find(i => isExample(i.t));
      const allText = [s.heading, ...s.subs.map(x => x.heading)].join(" ");
      const tip = (TIPS.find(([re]) => re.test(allText)) || [])[1] || (formula ? "Write the formula, define every symbol, then show one substitution." : null);
      const secK = secKeywords(s, 3);
      return {
        heading: s.heading,
        points: pick(s.items.length ? s.items : s.all, s.subs.length ? 4 : 6).map(p => hl(p, secK)),
        subs: s.subs.filter(x => x.items.length).slice(0, 8).map(x => ({ heading: x.heading, points: pick(x.items, 4).map(p => hl(p, secK)) })),
        formula, example: ex ? shorten(ex.t, 45) : null, examTip: tip,
      };
    }).filter(s => s.points.length || s.subs.length);

    // TL;DR + summary
    const content = sections.filter(s => !NOISE.test(s.heading));
    const allSent = S.filter(s => !NOISE.test(s.heading)).flatMap((s, si) => s.all.filter(i => !i.b && wc(i.t) >= 8 && wc(i.t) <= 45 && !isFormula(i.t)).map(i => ({ t: i.t, sc: sentScore(i.t) * (si < S.length * .3 ? 1.25 : 1) })));
    const firstDef = defs[0] ? `${defs[0].term} ${/s$/.test(defs[0].term) ? "are" : "is"} ${defs[0].meaning.replace(/^[A-Z]/, c => c.toLowerCase())}` : null;
    const fullSent = allSent.filter(x => /[.!?]$/.test(x.t) && wc(x.t) >= 10 && /^[A-Z]/.test(x.t));
    const tl = (fullSent.length ? fullSent : allSent).sort((a, b) => b.sc - a.sc).slice(0, 2).map(x => shorten(x.t, 35));
    const tldr = hl([firstDef ? shorten(firstDef, 35) : null, ...tl].filter(Boolean).slice(0, 2).join(" "));
    const summary = content.slice(0, 8).map(s => `**${shortLabel(s.heading, 6)}**: ${(s.points[0] || s.subs[0]?.points[0] || "").replace(/\*\*/g, "")}`).filter(x => !/:\s*$/.test(x));

    // mind map
    const usedLabels = new Set();
    const lab = (t, n) => { const L = shortLabel(t, n); usedLabels.add(L.toLowerCase()); return L; };
    const rootLabel = shortLabel(title, 4);
    let branches;
    // slide decks: short "divider" slides (e.g. "Literature Review") become branches, the slides after them their children
    const real = sections.filter(s => !NOISE.test(s.heading));
    const isDivider = s => !s.subs.length && !/\?$/.test(s.heading) && (s.points.length <= 1 && wc(stripNum(s.heading)) <= 6 || s.points.length <= 2 && wc(stripNum(s.heading)) <= 4 && !/^(why|what|how)\b/i.test(s.heading));
    if (real.length > 10 && real.filter(isDivider).length >= 3) {
      const groups = [];
      real.forEach(s => { if (isDivider(s)) groups.push({ head: s.heading, kids: [] }); else { if (!groups.length) groups.push({ head: "Introduction", kids: [] }); groups[groups.length - 1].kids.push(s); } });
      branches = groups.filter(g => g.kids.length).slice(0, 8).map(g => ({ label: lab(g.head, 4),
        children: g.kids.map(k => ({ k, w: k.points.join(" ").length + (k.formula ? 200 : 0) })).sort((a, b) => b.w - a.w).slice(0, 5)
          .sort((a, b) => g.kids.indexOf(a.k) - g.kids.indexOf(b.k)).map(({ k }) => ({ label: lab(k.heading.replace(/^(steps?|worked example)\s*[\d\-a-z]*\s*:\s*/i, ""), 4), children: [] })) }));
    } else if (S.length >= 2) {
      let chosen = S.map((s, i) => ({ s, i, w: s.all.reduce((n, x) => n + x.t.length, 0) })).filter(x => !NOISE.test(x.s.heading));
      if (chosen.length > 7) chosen = chosen.sort((a, b) => b.w - a.w).slice(0, 7).sort((a, b) => a.i - b.i);
      branches = chosen.map(({ s }) => {
        const children = s.subs.length
          ? s.subs.slice(0, 5).map(x => ({ label: lab(x.heading, 4), children: secKeywords({ heading: x.heading, all: x.items }, 2).filter(k => !usedLabels.has(k.label.toLowerCase())).map(k => ({ label: lab(k.label, 4), children: [] })) }))
          : secKeywords(s, 4).filter(k => !rootLabel.toLowerCase().includes(k.k)).map(k => ({ label: lab(k.label, 4), children: [] }));
        return { label: lab(s.heading, 4), children };
      });
    } else {
      branches = topK.slice(0, 6).map(k => {
        const co = new Map();
        S.forEach(s => s.all.forEach(i => { const t = i.t.toLowerCase(); if (!t.includes(k.k)) return; topK.forEach(o => { if (o.k !== k.k && t.includes(o.k)) co.set(o.label, (co.get(o.label) || 0) + o.sc); }); }));
        return { label: cap(k.label), children: [...co.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([l]) => ({ label: cap(l), children: [] })) };
      });
    }
    const mindmap = { label: rootLabel, children: branches };

    // flashcards
    const cards = [];
    defs.slice(0, 12).forEach(d => cards.push({ q: `What is **${d.term}**?`, a: shorten(d.meaning, 40) }));
    content.forEach(s => { if (s.formula) cards.push({ q: `Formula(s) in "${shortLabel(s.heading, 7)}"?`, a: s.formula }); });
    content.slice(0, 10).forEach(s => { const pts = [...s.points, ...s.subs.flatMap(x => x.points)].slice(0, 3); if (pts.length >= 2) cards.push({ q: `Key points of "${shortLabel(s.heading, 7)}"?`, a: pts.map(p => "• " + p).join("\n") }); });
    const clozes = [];
    allSent.slice(0, 40).forEach(x => {
      const k = topK.find(k => x.t.toLowerCase().includes(k.k) && k.label.length > 3);
      if (!k) return;
      const re = new RegExp(k.label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      clozes.push({ q: shorten(x.t, 35).replace(re, "_____"), a: k.label, k });
    });
    uniq(clozes, c => c.a.toLowerCase()).slice(0, 8).forEach(c => cards.push({ q: "Fill in the blank: " + c.q, a: "**" + c.a + "**" }));
    const flashcards = uniq(cards, c => c.q).slice(0, 24);

    // quiz
    const quiz = [];
    const termPool = uniq([...defs.map(d => d.term), ...topK.map(k => cap(k.label))], t => t.toLowerCase());
    const distract = (correct, n) => shuffle(termPool.filter(t => t.toLowerCase() !== correct.toLowerCase() && !t.toLowerCase().includes(correct.toLowerCase()) && !correct.toLowerCase().includes(t.toLowerCase()))).slice(0, n);
    uniq(defs, d => d.term.toLowerCase()).slice(0, 6).forEach(d => {
      const opts = distract(d.term, 3); if (opts.length < 3) return;
      const all = shuffle([d.term, ...opts]);
      quiz.push({ q: `Which term matches: "${shorten(d.meaning, 30)}"`, options: all, answer: all.indexOf(d.term), why: `${d.term}: ${shorten(d.meaning, 25)}` });
    });
    uniq(clozes, c => c.a.toLowerCase()).slice(0, 10 - quiz.length).forEach(c => {
      const opts = distract(c.a, 3); if (opts.length < 3) return;
      const all = shuffle([cap(c.a), ...opts]);
      quiz.push({ q: c.q, options: all, answer: all.indexOf(cap(c.a)), why: "From your notes." });
    });

    // exam questions
    const examQuestions = [];
    uniq(defs, d => d.term.toLowerCase()).slice(0, 3).forEach(d => examQuestions.push({ marks: 2, q: `Define ${d.term}.`, outline: [shorten(d.meaning, 30), "Add one example"] }));
    content.forEach(s => {
      const pts = [...s.points, ...s.subs.flatMap(x => x.points)];
      const h = stripNum(s.heading).replace(/\?$/, "");
      if (pts.length >= 5 || s.formula || s.subs.length >= 2) examQuestions.push({ marks: 10, q: `Explain ${h} in detail${s.formula ? " with the formula and an example" : " with a neat diagram/example"}.`, outline: [...s.subs.map(x => stripNum(x.heading)), ...pts.slice(0, 5).map(p => p.replace(/\*\*/g, "")), ...(s.formula ? ["Formula: " + s.formula.split("\n")[0]] : [])].slice(0, 8) });
      else if (pts.length >= 2) examQuestions.push({ marks: 5, q: `${/advantage|difference|types|application/i.test(h) ? "List and explain" : "Explain"} ${h}.`, outline: pts.slice(0, 5).map(p => p.replace(/\*\*/g, "")) });
    });

    // memory tricks + checklist
    const mnemonics = [];
    const heads = (branches.length >= 3 ? branches.map(b => b.label) : content.slice(0, 7).map(s => stripNum(s.heading))).filter(h => /^[A-Za-z]/.test(h)).slice(0, 7);
    if (heads.length >= 3) mnemonics.push(`Main topics in order, first letters **${heads.map(h => h[0].toUpperCase()).join("-")}**: ${heads.map(h => shortLabel(h, 3)).join(" → ")}`);
    content.forEach(s => { const pts = s.points.map(p => p.replace(/\*\*/g, "").trim()); if (pts.length >= 3 && pts.length <= 7 && pts.every(p => wc(p) <= 8 && /^[A-Za-z]/.test(p)) && mnemonics.length < 3) mnemonics.push(`${shortLabel(s.heading, 5)}: **${pts.map(p => p[0].toUpperCase()).join("")}** (${pts.map(p => shortLabel(p, 2)).join(", ")})`); });
    const checklist = (branches.length >= 3 ? branches.map(b => b.label) : content.map(s => s.heading)).slice(0, 8).map(h => `I can explain ${shortLabel(h, 8)} without looking`);

    return {
      title: title.length > 90 ? shortLabel(title, 10) : title,
      notes: { tldr, eli5: null, summary, sections, keyTerms, mindmap },
      tools: { flashcards, quiz: quiz.slice(0, 10), examQuestions: examQuestions.slice(0, 10), mnemonics, checklist },
    };
  }

  /* ---------- tutor retrieval (no AI needed) ---------- */
  function chunks(text, size = 700) {
    const paras = text.split(/\n(?=\S)/), out = []; let cur = "";
    paras.forEach(p => { if ((cur + p).length > size && cur) { out.push(cur.trim()); cur = ""; } cur += p + "\n"; });
    if (cur.trim()) out.push(cur.trim());
    return out;
  }
  function search(text, q, n = 3) {
    const qs = words(q); if (!qs.length) return [];
    const cs = chunks(text), df = new Map();
    cs.forEach(c => new Set(words(c)).forEach(w => df.set(w, (df.get(w) || 0) + 1)));
    return cs.map((c, i) => { const ws = words(c); let s = 0; qs.forEach(w => { const f = ws.filter(x => x === w || x.startsWith(w.slice(0, 5))).length; if (f) s += (f / (f + 1.2)) * Math.log(1 + cs.length / (df.get(w) || 1)); }); return { i, c, s }; })
      .filter(x => x.s > 0).sort((a, b) => b.s - a.s).slice(0, n);
  }

  return { readPdf, ocr, ocrWords, ocrTimetable, headingText, pdfPagesToCanvas, textToLines, build, search, chunks, shortLabel };
})();
