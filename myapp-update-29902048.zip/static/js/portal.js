/* Portal reader: turns portal tables (synced by the server, or pasted from any browser)
   into attendance / marks / exam changes the student reviews before saving. */
"use strict";
const Portal = (() => {
  const num = s => { const m = String(s ?? "").replace(/,/g, "").match(/-?\d+(\.\d+)?/); return m ? +m[0] : null; };
  const norm = s => String(s || "").toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]/g, "");
  const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  const pad = n => String(n).padStart(2, "0");
  function parseDate(s) {
    s = String(s || "").trim();
    let m;
    if ((m = s.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/))) return `${m[1]}-${pad(m[2])}-${pad(m[3])}`;
    if ((m = s.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/))) { const y = m[3].length === 2 ? "20" + m[3] : m[3]; return `${y}-${pad(m[2])}-${pad(m[1])}`; } // Indian dd-mm-yyyy
    if ((m = s.match(/(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([A-Za-z]{3,9})[,\s\-]+(\d{2,4})/))) { const mo = MONTHS[m[2].slice(0, 4).toLowerCase()] || MONTHS[m[2].slice(0, 3).toLowerCase()]; if (mo) return `${m[3].length === 2 ? "20" + m[3] : m[3]}-${pad(mo)}-${pad(m[1])}`; }
    if ((m = s.match(/([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})/))) { const mo = MONTHS[m[1].slice(0, 3).toLowerCase()]; if (mo) return `${m[3]}-${pad(mo)}-${pad(m[2])}`; }
    return null;
  }
  const timeOf = s => { const m = String(s || "").match(/(\d{1,2})[:.](\d{2})\s*(am|pm)?/i); if (!m) return ""; let h = +m[1]; if (/pm/i.test(m[3] || "") && h < 12) h += 12; if (/am/i.test(m[3] || "") && h === 12) h = 0; return `${pad(h)}:${m[2]}`; };

  function headerRow(t) {
    for (let i = 0; i < Math.min(t.length, 4); i++) if (t[i].filter(c => /[a-z]{2}/i.test(c)).length >= 2) return i;
    return 0;
  }
  function tablesFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    return [...doc.querySelectorAll("table")].map(t => [...t.rows].map(r => [...r.cells].map(c => c.textContent.replace(/\s+/g, " ").trim())).filter(r => r.some(Boolean))).filter(t => t.length > 1);
  }
  // plain text fallback: lines split on tabs or 2+ spaces become rows
  function tablesFromText(text) {
    const rows = text.split(/\r?\n/).map(l => l.split(/\t| {2,}/).map(c => c.trim()).filter(Boolean)).filter(r => r.length >= 3);
    return rows.length > 1 ? [rows] : [];
  }

  function readTables(tables, kind) {
    const out = { att: [], marks: [], exams: [] };
    for (const t of tables) {
      const hi = headerRow(t), H = t[hi].map(h => h.toLowerCase());
      const col = (re, not) => H.findIndex(h => re.test(h) && !(not && not.test(h)));
      const subj = (() => { let c = col(/subject|course|paper|title/, /code|faculty|teacher|staff|student|type/); if (c < 0) c = col(/name/, /student|father|faculty|teacher|staff/); return c; })();
      const code = col(/code/);
      const name = r => (r[subj] || r[code] || "").replace(/\s*\(.*?\)\s*$/, "").trim();
      const rows = t.slice(hi + 1).filter(r => r.length >= 2 && !/^(total|grand total|overall)/i.test(r[0] || ""));
      const maxIn = h => { const m = String(h).match(/(?:\/|out of|max\.?|\()\s*(\d{1,3})/i); return m ? +m[1] : null; };

      // attendance
      const attC = col(/attend|present|\bp\b/, /%|percent|total|eligib/), totC = col(/total|conducted|delivered|held|classes|lectures|sessions/, /%|percent|attend|present|absent/), absC = col(/absent/), pctC = col(/%|percent/);
      if ((kind === "attendance" || kind === "auto") && subj >= 0 && (attC >= 0 || pctC >= 0)) {
        rows.forEach(r => {
          let a = num(r[attC]), tt = num(r[totC]);
          const frac = String(r[attC] ?? "").match(/(\d+)\s*\/\s*(\d+)/);
          if (frac) { a = +frac[1]; tt = +frac[2]; }
          if (tt == null && absC >= 0 && a != null) tt = a + (num(r[absC]) || 0);
          if (name(r) && a != null && tt != null && tt >= a && tt > 0) out.att.push({ n: name(r), a, t: tt });
          else if (name(r) && pctC >= 0 && num(r[pctC]) != null) out.att.push({ n: name(r), pct: num(r[pctC]) });
        });
      }
      // marks
      const intC = col(/internal|\bcia\b|\bia\b|sessional|\bcie\b|\bmid|continuous|\btest|\bassessment|\bca\b/, /max|out of|total marks|grade|attend/), extC = col(/external|\bend\b|end[- ]?sem|\bsee\b|\bese\b|semester exam|university|theory|final/, /max|out of|date|grade|attend/);
      const crC = col(/credit/), grC = col(/grade/, /point/);
      const isAttTable = attC >= 0 && totC >= 0;
      if ((kind === "marks" || kind === "auto") && !isAttTable && subj >= 0 && (intC >= 0 || extC >= 0 || grC >= 0)) {
        rows.forEach(r => {
          if (!name(r)) return;
          const io = num(r[intC]), eo = num(r[extC]);
          if (io == null && eo == null && (grC < 0 || !r[grC])) return;
          out.marks.push({ n: name(r), cr: num(r[crC]), io, im: maxIn(t[hi][intC] || ""), eo, em: maxIn(t[hi][extC] || ""), grade: grC >= 0 ? r[grC] : null });
        });
      }
      // exams
      const dateC = col(/date|day/), typeC = col(/exam|type|test|assessment|category/, /date|code/), tmC = col(/time|session|slot|shift/);
      if ((kind === "exams" || kind === "auto") && dateC >= 0) {
        rows.forEach(r => {
          const d = parseDate(r[dateC]);
          const sub = name(r) || (typeC >= 0 ? r[typeC] : "");
          if (d && sub) out.exams.push({ sub, type: typeC >= 0 && typeC !== subj ? r[typeC] : (kind === "exams" ? "Exam" : "Exam"), date: d, time: timeOf(tmC >= 0 ? r[tmC] : r.join(" ")) });
        });
      }
    }
    return out;
  }

  const AI_PROMPT = text => `Extract a student's data from this college portal page. Reply with ONLY JSON:
{"attendance":[{"subject":"","attended":0,"total":0}],"marks":[{"subject":"","credits":null,"internal":null,"internalMax":null,"external":null,"externalMax":null}],"exams":[{"subject":"","type":"","date":"YYYY-MM-DD","time":"HH:MM"}]}
Use empty arrays when something is not on the page. Dates on Indian portals are usually DD-MM-YYYY.
<page>
${text.slice(0, 12000)}
</page>`;
  function fromAi(j) {
    const out = { att: [], marks: [], exams: [] };
    (j.attendance || []).forEach(x => x.subject && x.total && out.att.push({ n: x.subject, a: +x.attended || 0, t: +x.total }));
    (j.marks || []).forEach(x => x.subject && out.marks.push({ n: x.subject, cr: x.credits ?? null, io: x.internal ?? null, im: x.internalMax ?? null, eo: x.external ?? null, em: x.externalMax ?? null }));
    (j.exams || []).forEach(x => x.subject && /^\d{4}-\d{2}-\d{2}$/.test(x.date || "") && out.exams.push({ sub: x.subject, type: x.type || "Exam", date: x.date, time: x.time || "" }));
    return out;
  }

  // compare with the planner and describe each change
  function diff(found, P) {
    const changes = [];
    const match = (list, n, key = "n") => { const k = norm(n); return list.find(x => { const o = norm(x[key]); return o && (o === k || (k.length >= 4 && o.length >= 4 && (o.includes(k) || k.includes(o)))); }); };
    uniqBy(found.att, x => norm(x.n)).forEach(r => {
      if (r.pct != null) { changes.push({ type: "att", label: `${r.n}: portal shows ${r.pct}% (no class counts, so not imported)`, disabled: true }); return; }
      const ex = match(P.att.subs, r.n);
      if (ex && ex.a === r.a && ex.t === r.t) return;
      changes.push({ type: "att", label: ex ? `Attendance · ${ex.n}: ${ex.a}/${ex.t} → ${r.a}/${r.t}` : `Attendance · add ${r.n}: ${r.a}/${r.t}`, apply: () => { if (ex) { ex.a = r.a; ex.t = r.t; } else P.att.subs.push({ id: Math.random().toString(36).slice(2, 10), n: r.n, a: r.a, t: r.t }); } });
    });
    const sem = P.sems[P.cur];
    uniqBy(found.marks, x => norm(x.n)).forEach(r => {
      const ex = match(sem.subs, r.n);
      const parts = [r.io != null && `internal ${r.io}${r.im ? "/" + r.im : ""}`, r.eo != null && `end-sem ${r.eo}${r.em ? "/" + r.em : ""}`, r.cr != null && `${r.cr} credits`, r.grade && `grade ${r.grade}`].filter(Boolean).join(", ");
      if (ex && (r.io == null || ex.io === r.io) && (r.eo == null || ex.eo === r.eo) && (r.cr == null || ex.cr === r.cr)) return;
      changes.push({ type: "marks", label: `Marks (${sem.name}) · ${ex ? ex.n : "add " + r.n}: ${parts}`, apply: () => {
        const s = ex || (sem.subs.push({ n: r.n, cr: 3, io: null, im: 40, eo: null, em: 60 }), sem.subs[sem.subs.length - 1]);
        if (r.cr != null) s.cr = r.cr; if (r.io != null) s.io = r.io; if (r.im) s.im = r.im; if (r.eo != null) s.eo = r.eo; if (r.em) s.em = r.em;
      } });
    });
    uniqBy(found.exams, x => norm(x.sub) + x.date).forEach(r => {
      if (P.exams.some(e => e.date === r.date && norm(e.sub) && (norm(e.sub).includes(norm(r.sub)) || norm(r.sub).includes(norm(e.sub))))) return;
      changes.push({ type: "exam", label: `Exam · ${r.sub} ${r.type} on ${r.date}${r.time ? " " + r.time : ""}`, apply: () => P.exams.push({ id: Math.random().toString(36).slice(2, 10), sub: r.sub, type: r.type, date: r.date, time: r.time, syl: "" }) });
    });
    return changes;
  }
  function uniqBy(a, f) { const s = new Set(); return a.filter(x => { const k = f(x); if (s.has(k)) return false; s.add(k); return true; }); }
  function merge(a, b) { return { att: [...a.att, ...b.att], marks: [...a.marks, ...b.marks], exams: [...a.exams, ...b.exams] }; }
  const count = f => f.att.length + f.marks.length + f.exams.length;

  /* ---------- Amrita student portal (students.amrita.edu): exact layouts ---------- */
  const CODE = /^\s*(\d{2}[A-Z]{2,5}\d{3})\s*/;
  function mirrorFrom(results, prev) {
    const m = { syncedAt: Date.now(), attendance: null, marks: [], gatepass: null, absent: null };
    (results || []).filter(r => r.ok).forEach(r => (r.tables || []).forEach(t => {
      const H = t[0].map(h => h.toLowerCase().trim()), ix = n => H.indexOf(n);
      const cell = (row, n) => (ix(n) >= 0 ? row[ix(n)] : "") || "";
      if (H.includes("present") && H.includes("total")) {
        m.attendance = { term: r.term || "", sem: r.sem || "", rows: t.slice(1).filter(row => num(cell(row, "total")) != null).map(row => {
          const c = cell(row, "course");
          return { code: (c.match(CODE) || [, ""])[1], course: c.replace(CODE, "").trim() || c, faculty: cell(row, "faculty"), total: num(cell(row, "total")) || 0, present: num(cell(row, "present")) || 0,
            dl: num(cell(row, "duty leave")) || 0, absent: num(cell(row, "absent")) || 0, pct: num(cell(row, "percentage")) || 0, medical: num(cell(row, "medical")) || 0 };
        }) };
      } else if (H.includes("marks obtained") && H.includes("max marks")) {
        m.marks.push({ sem: r.sem || "", term: r.term || "", rows: t.slice(1).map(row => ({ course: cell(row, "course name"), code: cell(row, "course code"), got: num(cell(row, "marks obtained")), max: num(cell(row, "max marks")), comp: cell(row, "component name"), exam: cell(row, "exam name") })).filter(x => x.course && x.max != null) });
      } else if (H.includes("absent dates") && H.includes("course")) {
        // "22MAT122 Mathematics for Computing 2" | "Sl No Date Period 1 2026-01-08 4 2 2026-01-13 1 …"
        m.absent = { term: r.term || "", rows: t.slice(1).map(row => {
          const c = cell(row, "course"), dates = [];
          for (const x of cell(row, "absent dates").matchAll(/(\d{4}-\d{2}-\d{2})\s+(\d{1,2})\b/g)) dates.push({ date: x[1], period: +x[2] });
          return { code: (c.match(CODE) || [, ""])[1], course: c.replace(CODE, "").trim() || c, dates };
        }).filter(x => x.code || x.course) };
      } else if (H.includes("type") && H.includes("from") && H.includes("to") && H.includes("status") && !H.includes("pass name")) {
        m.leaves = t.slice(1).map(row => ({ type: cell(row, "type"), from: cell(row, "from"), to: cell(row, "to"), status: cell(row, "status") })).filter(x => /^\d{4}-\d{2}-\d{2}$/.test(x.from));
      } else if (H.includes("pass name") && H.includes("final status")) {
        m.gatepass = t.slice(1).map(row => ({ id: cell(row, "id"), name: cell(row, "pass name"), from: cell(row, "from"), to: cell(row, "to"), level: cell(row, "level status"), status: cell(row, "final status"), created: cell(row, "created on") })).filter(x => x.id);
      }
    }));
    // a term whose marks page had no table yet still counts as synced (empty)
    (results || []).filter(r => r.ok && r.kind === "marks" && r.sem && !m.marks.some(b => b.sem === r.sem)).forEach(r => m.marks.push({ sem: r.sem, term: r.term || "", rows: [] }));
    m.marks.sort((a, b) => (parseInt(a.sem.replace(/\D/g, "")) || 0) - (parseInt(b.sem.replace(/\D/g, "")) || 0));
    if (prev) { if (!m.attendance) m.attendance = prev.attendance; if (!m.marks.length) m.marks = prev.marks || []; if (!m.gatepass) m.gatepass = prev.gatepass; if (!m.absent) m.absent = prev.absent; if (!m.leaves) m.leaves = prev.leaves; m.aumsMarks = prev.aumsMarks; }
    // start-of-day present-count (present + duty + medical) per course: a course whose present count rose today means you attended
    const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    if (prev?.dayBase?.date === today) m.dayBase = prev.dayBase;
    else if (prev?.attendance?.rows?.length) m.dayBase = { date: today, totals: Object.fromEntries(prev.attendance.rows.map(x => [x.code || x.course, x.present + x.dl + x.medical])) };
    // daily log of [present, total] per course: the calendar's green comes from the day-to-day rise, so a class
    // shows present only when attendance was actually recorded that day (handles teacher swaps, extra classes)
    m.attLog = { ...(prev?.attLog || {}) };
    if (m.attendance?.rows?.length) m.attLog[today] = Object.fromEntries(m.attendance.rows.map(x => [x.code || x.course, [x.present + x.dl + x.medical, x.total]]));
    const keep = Object.keys(m.attLog).sort().slice(-120);
    m.attLog = Object.fromEntries(keep.map(k => [k, m.attLog[k]]));
    m.found = !!(m.attendance || m.marks.length || m.gatepass);
    return m;
  }
  const isEndSem = x => /end\s*sem|end\s*semester|\bese\b|final exam|semester exam/i.test(x.comp + " " + x.exam);
  const isMid = x => /mid[\s-]*term|mid[\s-]*sem/i.test(x.comp + " " + x.exam);
  function courseTotals(rows) {
    const by = new Map();
    rows.forEach(x => { const k = x.code || x.course; if (!by.has(k)) by.set(k, { code: x.code, course: x.course, items: [] }); by.get(k).items.push(x); });
    return [...by.values()].map(c => {
      const mid = c.items.filter(isMid), es = c.items.filter(isEndSem), ca = c.items.filter(x => !isEndSem(x) && !isMid(x));
      const sum = (a, f) => a.reduce((s, x) => s + (x[f] || 0), 0);
      return { ...c, midGot: sum(mid, "got"), midMax: sum(mid, "max"), caGot: sum(ca, "got"), caMax: sum(ca, "max"),
        allGot: sum([...mid, ...ca], "got"), allMax: sum([...mid, ...ca], "max"), esGot: es.length ? sum(es, "got") : null, esMax: es.length ? sum(es, "max") : null };
    }).sort((a, b) => a.code.localeCompare(b.code));
  }
  // Amrita weighting: Mid-Term (/50) scales to midW (30 or 40); quizzes/labs/assignments scale to the rest of the internal max
  function internal(s) {
    const midW = +s.midW || 30, caW = Math.max(0, (+s.im || 70) - midW);
    const [mg, mm] = s.mid || [0, 0], [cg, cm] = s.ca || [0, 0];
    const parts = [mm && [mg / mm, midW], cm && caW && [cg / cm, caW]].filter(Boolean);
    if (!parts.length) return null;
    // a part not published yet is projected at the same rate as what's already marked
    const w = parts.reduce((a, p) => a + p[1], 0), got = parts.reduce((a, p) => a + p[0] * p[1], 0);
    s.projected = w < midW + caW;
    return Math.round(got / w * (midW + caW) * 100) / 100;
  }
  // copy portal numbers into the Attendance and Marks tabs
  function applyMirror(m, P, uid) {
    if (m.attendance && m.attendance.rows.length) {
      const keep = P.att.subs.filter(s => !s.portal && !m.attendance.rows.some(r => norm(r.course) === norm(s.n)));
      P.att.subs = m.attendance.rows.map(r => { const ex = P.att.subs.find(s => (s.code && s.code === r.code) || norm(s.n) === norm(r.course));
        // medical leave counts as present (portal % leaves it out)
        return { id: ex?.id || uid(), n: r.course, code: r.code, a: r.present + r.dl + r.medical, t: r.total, med: r.medical, portal: true }; }).concat(keep);
    }
    m.marks.forEach(block => {
      if (!block.sem || !block.rows.length) return;
      let sem = P.sems.find(s => s.name === block.sem);
      if (!sem) { sem = { id: uid(), name: block.sem, subs: [] }; P.sems.push(sem); }
      sem.term = block.term;
      const rows = block.rows;
      courseTotals(rows).forEach(c => {
        let s = sem.subs.find(x => (x.code && x.code === c.code) || norm(x.n) === norm(c.course));
        if (!s) { s = { n: c.course, cr: 3, io: null, im: 70, eo: null, em: 30 }; sem.subs.push(s); }
        // the portal lists raw scores; internal = Mid-Term scaled to 30/40 + the rest scaled to (internal max − mid weight).
        // Defaults 70 internal / 30 end-sem, mid → 30; whatever the student sets (wSet) is kept on every sync.
        if (!s.wSet) { s.im = 70; s.em = 30; s.midW = s.midW || 30; }
        // myAmrita hasn't got the Mid-Term yet but AUMS has published it: use AUMS's (out of 50)
        const am = !c.midMax && (m.aumsMarks?.[block.sem]?.[c.code] || []).find(x => /mid/i.test(x.exam) && x.val != null);
        const mid = am ? [am.val, 50] : [c.midGot, c.midMax];
        Object.assign(s, { n: c.course, code: c.code, mid, ca: [c.caGot, c.caMax], portal: true,
          raw: `Mid ${mid[1] ? +mid[0].toFixed(2) + "/" + mid[1] + (am ? " (AUMS)" : "") : "not yet"} · others ${+c.caGot.toFixed(2)}/${+c.caMax.toFixed(2)}` });
        s.io = internal(s);
        if (c.esGot != null) Object.assign(s, { eo: Math.round(c.esGot / (c.esMax || 1) * (+s.em || 30) * 100) / 100 });
      });
      // courses with marks only on AUMS: their AUMS Mid-Term (out of 50) feeds the internal estimate
      const seen = new Set(courseTotals(rows).map(c => c.code));
      Object.entries(m.aumsMarks?.[block.sem] || {}).filter(([code]) => !seen.has(code)).forEach(([code, list]) => {
        const s = sem.subs.find(x => x.code === code), mid = list.find(x => /mid/i.test(x.exam) && x.val != null);
        if (!s || !mid) return;
        if (!s.wSet) { s.im = 70; s.em = 30; s.midW = s.midW || 30; }
        Object.assign(s, { mid: [mid.val, 50], ca: [0, 0], portal: true, raw: `Mid ${mid.val}/50 (AUMS)` });
        s.io = internal(s);
      });
      // drop subjects a wrongly numbered earlier sync put here (kept: your own, graded, or still on the portal for this semester)
      const here = new Set([...seen, ...Object.keys(m.aumsMarks?.[block.sem] || {})]);
      sem.subs = sem.subs.filter(x => x.n && (!x.portal || here.has(x.code) || x.grade));
    });
    P.sems.sort((a, b) => (parseInt(a.name.replace(/\D/g, "")) || 99) - (parseInt(b.name.replace(/\D/g, "")) || 99));
    const curSem = m.attendance?.sem || (m.marks.length ? m.marks[m.marks.length - 1].sem : null);
    // a semester after the current one can't exist yet (left over from an older, miscounted sync) unless it has grades
    const curN = parseInt(String(curSem || "").replace(/\D/g, "")) || 0;
    if (curN) P.sems = P.sems.filter(s => (parseInt(s.name.replace(/\D/g, "")) || 0) <= curN || s.subs.some(x => x.grade));
    const ci = P.sems.findIndex(s => s.name === curSem); if (ci >= 0) P.cur = ci;
    fixSems(m, P, uid);
  }
  /* Every course belongs to the semester the portal lists it in (marks pages per semester; attendance = the current one).
     Older, miscounted syncs left last semester's courses under this one, and AUMS grades then stuck to them there:
     move each back (keeping its grade and credits), drop duplicates, and keep the current semester to its real courses. */
  function fixSems(m, P, uid) {
    if (!m || !P?.sems?.length) return;
    const home = {};
    (m.marks || []).forEach(b => b.sem && courseTotals(b.rows || []).forEach(c => { if (c.code) home[c.code] = b.sem; }));
    const curSem = m.attendance?.sem, cur = new Set((m.attendance?.rows || []).map(r => r.code).filter(Boolean));
    cur.forEach(code => { home[code] = curSem; });
    const semOf = name => P.sems.find(s => s.name === name) || (P.sems.push({ id: uid(), name, subs: [] }), P.sems[P.sems.length - 1]);
    P.sems.slice().forEach(sem => {
      sem.subs = sem.subs.filter(x => {
        const want = x.code && home[x.code];
        if (!want || want === sem.name) return true;
        const to = semOf(want), same = to.subs.find(y => y.code === x.code);
        if (same) { ["grade", "gradeSrc", "cr", "crSet"].forEach(k => { if (x[k] != null && same[k] == null) same[k] = x[k]; }); }
        else to.subs.push(x);
        return false;
      });
      const seen = new Set();   // one row per course
      sem.subs = sem.subs.filter(x => !x.code || (seen.has(x.code) ? false : seen.add(x.code)));
    });
    // the current semester has only what the portal lists for it now (plus anything you typed in yourself)
    const now = curSem && cur.size && P.sems.find(s => s.name === curSem);
    // the current semester = the courses myAmrita lists for it (attendance or marks) or AUMS has marks for; anything else was left by an older sync or sample data
    if (now) {
      const aumsCur = new Set(Object.keys(m.aumsMarks?.[curSem] || {}));
      now.subs = now.subs.filter(x => x.code ? cur.has(x.code) || home[x.code] === curSem || aumsCur.has(x.code) || x.aumsReg === curSem : !x.portal);
      // every course on the attendance page is a course this semester, even before AUMS adds its credits
      (m.attendance.rows || []).forEach(r => { if (r.code && !now.subs.some(x => x.code === r.code))
        now.subs.push({ id: uid(), n: r.course || r.code, code: r.code, cr: null, io: null, im: 70, eo: null, em: 30 }); });
    }
    P.sems = P.sems.filter(s => s.subs.length || s.name === curSem);
    P.sems.sort((a, b) => (parseInt(a.name.replace(/\D/g, "")) || 99) - (parseInt(b.name.replace(/\D/g, "")) || 99));
    const ci = P.sems.findIndex(s => s.name === curSem); if (ci >= 0) P.cur = ci;
  }
  /* AUMS "View Marks": rows = assessments, columns = course codes, "NP" = not published yet */
  function aumsMarksFrom(cache) {
    const out = {};
    (cache.pages || []).forEach(pg => (pg.tables || []).forEach(t => {
      const H = t[0] || []; if (!/exam name/i.test(H[0] || "")) return;
      const sem = (String(pg.label).match(/·\s*(\d{1,2})\s*$/) || [])[1]; if (!sem) return;
      const cols = H.map((h, i) => (/^\d{2}[A-Z]{2,5}\d{3}$/.test(h.trim()) ? [i, h.trim()] : null)).filter(Boolean);
      const bySem = {};   // the same table can appear twice (Marks / Exam Scores): the last copy wins
      t.slice(1).forEach(r => cols.forEach(([i, code]) => { const v = (r[i] || "").trim(); if (!v) return;
        (bySem[code] = bySem[code] || []).push({ exam: (r[0] || "").trim(), val: /^np$/i.test(v) ? null : parseFloat(v), np: /^np$/i.test(v) }); }));
      if (Object.keys(bySem).length) out["Sem " + sem] = bySem;
    }));
    return out;
  }
  // "Midterm exam" ≈ "Mid-Term", "Quiz -1" ≈ "Quiz 1", "Continous Assesment" ≈ "Continuous Assessment"
  const examKey = s => String(s || "").toLowerCase().replace(/continou?s/g, "continuous").replace(/asses+ment/g, "assessment").replace(/\b(exam|examination|test)\b/g, "").replace(/[^a-z0-9]/g, "");

  const passTime = s => { const d = new Date(String(s || "").replace(" ", "T")); return isNaN(d) ? null : d; };

  return { readTables, tablesFromHtml, tablesFromText, diff, merge, count, AI_PROMPT, fromAi, parseDate, mirrorFrom, applyMirror, fixSems, courseTotals, passTime, isEndSem, internal, aumsMarksFrom, examKey };
})();
