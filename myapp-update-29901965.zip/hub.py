"""BTech Study Desk - local server (Windows PC or Android tablet via Termux).

Runs on port 8765. Everything stays on the device:
  data/planner.json        exams, marks, attendance, plan
  data/notes/<id>.json     generated notes (also mirrored as Markdown in ../notes/)
  data/sources/<id>.txt    extracted text of each PDF (for the AI tutor)
  data/portal.json         portal links + settings
  data/portal-cache.json   last raw portal fetch
  data/lan.json            phone/tablet pairing
  data/portal-browser/     Edge profile that keeps the portal sign-in (Windows only)

No paid services. Optional free local AI through Ollama (http://127.0.0.1:11434).
"""
import base64
import io
import json
import os
import platform
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

from flask import Flask, Response, jsonify, make_response, redirect, request, send_file, send_from_directory

APP_DIR = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("STUDYDESK_HOME", APP_DIR.parent))   # Windows: C:\Users\basar\StudyBuddy
DATA = ROOT / "data"
NOTES = DATA / "notes"
SOURCES = DATA / "sources"
NOTES_MD = ROOT / "notes"
PROFILE = DATA / "portal-browser"
for d in (DATA, NOTES, SOURCES, NOTES_MD):
    d.mkdir(parents=True, exist_ok=True)

EDITION = "classmates" if ".classmates" in str(ROOT) else "cr" if re.search(r"amrita\.cr\b", str(ROOT)) else "personal"   # Students / CR's / Admin Portal
IS_ANDROID = "ANDROID_ROOT" in os.environ or "com.termux" in os.environ.get("PREFIX", "")
IS_WINDOWS = platform.system() == "Windows"
PLATFORM = "android" if IS_ANDROID else "windows" if IS_WINDOWS else "other"
PORT = int(os.environ.get("STUDYDESK_PORT", 8765))
URL = f"http://127.0.0.1:{PORT}"
OLLAMA = os.environ.get("OLLAMA_HOST_URL", "http://127.0.0.1:11434")
OLLAMA_PREFERRED = ["qwen2.5:7b", "llama3.1:8b", "qwen2.5:3b", "llama3.2:3b", "qwen2.5:1.5b", "gemma2:2b", "qwen2.5:0.5b"]
DEFAULT_MODEL = "qwen2.5:3b"   # fine on the PC and on a 12 GB Xiaomi Pad 7
STARTUP_LNK = Path(os.environ.get("APPDATA", "")) / r"Microsoft\Windows\Start Menu\Programs\Startup\BTech Study Desk.lnk"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024
lock = threading.Lock()
portal_state = {"login_open": False, "login_pending": False, "syncing": False, "last_error": None}


# ---------------------------------------------------------------- storage
def read_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def write_json(path, data):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with lock:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, path)


def safe_id(s):
    return re.sub(r"[^A-Za-z0-9_-]", "", s)[:64]


DEFAULT_LINKS = [   # myAmrita pages every student has (used on a fresh install)
    {"id": "att", "label": "Class attendance (current semester)", "kind": "attendance", "url": "https://students.amrita.edu/client/class-attendance?academic_term_id=current"},
    {"id": "marks", "label": "Marks (every semester)", "kind": "marks", "url": "https://students.amrita.edu/client/mark?academic_term_id=each"},
    {"id": "gp", "label": "Gate pass", "kind": "gatepass", "url": "https://students.amrita.edu/hostel/index"},
    {"id": "absent", "label": "Absent report (current semester)", "kind": "absent", "url": "https://students.amrita.edu/client/absent-report?academic_term_id=current"},
    {"id": "leave", "label": "Leave list", "kind": "leave", "url": "https://students.amrita.edu/client/leave-list"},
]


def portal_cfg():
    fresh = not (DATA / "portal.json").exists()
    cfg = read_json(DATA / "portal.json", {})
    if fresh:
        cfg.update(links=DEFAULT_LINKS, autoSync=False, syncEveryHours=3)   # turned on once the student has signed in (welcome screen)
    cfg.setdefault("links", [])
    # older setups: add the Absent Report and Leave List (period-wise present / absent / leave)
    if any("students.amrita.edu" in l.get("url", "") for l in cfg["links"]):
        missing = [d for d in DEFAULT_LINKS if d["id"] in ("absent", "leave") and not any(d["url"].split("?")[0] in l.get("url", "") for l in cfg["links"])]
        if missing:
            cfg["links"] += missing
            write_json(DATA / "portal.json", cfg)
    cfg.setdefault("autoSync", False)
    cfg.setdefault("alerts", True)
    cfg.setdefault("alertHour", 8)
    return cfg


# ---------------------------------------------------------------- phone/tablet access (LAN pairing)
def lan_cfg():
    cfg = read_json(DATA / "lan.json", {})
    cfg.setdefault("enabled", False)
    cfg.setdefault("devices", [])          # long-lived device tokens
    if not cfg.get("code") or time.time() - cfg.get("codeAt", 0) > 600:
        cfg["code"] = f"{secrets.randbelow(1000000):06d}"
        cfg["codeAt"] = time.time()
        write_json(DATA / "lan.json", cfg)
    return cfg


def is_local():
    return request.remote_addr in ("127.0.0.1", "::1")


def lan_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    return [ip for ip in ips if re.match(r"^(10|172|192\.168)\.", ip)] or ips


LOCAL_ONLY = ("/api/agent", "/api/quit", "/api/startup", "/api/lan", "/api/restore", "/api/portal/login", "/api/ai/pull", "/api/aums/signin")


@app.before_request
def guard():
    if is_local():
        return None
    cfg = lan_cfg()
    if not cfg["enabled"]:
        return Response("Study Desk: Wi-Fi access is turned off on the main device.", 403)
    if request.path == "/pair":
        return None
    if request.cookies.get("sd_device") not in cfg["devices"]:
        return redirect("/pair")
    if request.path.startswith(LOCAL_ONLY):
        return jsonify(error="local_only", message="Do this on the main device."), 403
    return None


PAIR_PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Pair Study Desk</title>
<body style="font-family:system-ui;max-width:420px;margin:60px auto;padding:0 16px">
<h2>Pair this device</h2><p>Enter the 6-digit code shown on the main device under <b>Portal &amp; settings → Phone &amp; tablet</b>.</p>
<form><input name=code inputmode=numeric autocomplete=one-time-code maxlength=6 style="font-size:28px;width:8ch;letter-spacing:4px" autofocus>
<button style="font-size:20px">Pair</button></form><p style="color:#c33">{err}</p></body>"""


@app.get("/pair")
def pair():
    cfg = lan_cfg()
    code = request.args.get("code", "").strip()
    if not code:
        return PAIR_PAGE.replace("{err}", "")
    if not secrets.compare_digest(code, cfg["code"]):
        return PAIR_PAGE.replace("{err}", "Wrong or expired code. Check the main device."), 403
    token = secrets.token_urlsafe(24)
    cfg["devices"].append(token)
    cfg["code"] = ""        # one use per code
    write_json(DATA / "lan.json", cfg)
    resp = make_response(redirect("/"))
    resp.set_cookie("sd_device", token, max_age=60 * 60 * 24 * 365 * 4, httponly=True, samesite="Lax")
    return resp


@app.get("/api/lan")
def lan_get():
    cfg = lan_cfg()
    return jsonify(enabled=cfg["enabled"], code=cfg["code"], devices=cfg["devices"] and [f"device {i + 1}" for i in range(len(cfg["devices"]))] or [],
                   urls=[f"http://{ip}:{PORT}" for ip in lan_ips()])


@app.post("/api/lan")
def lan_set():
    cfg = lan_cfg()
    cfg["enabled"] = bool(request.get_json(force=True).get("enabled"))
    write_json(DATA / "lan.json", cfg)
    return lan_get()


@app.post("/api/lan/code")
def lan_code():
    cfg = lan_cfg()
    cfg["codeAt"] = 0
    write_json(DATA / "lan.json", cfg)
    return lan_get()


@app.post("/api/lan/revoke")
def lan_revoke():
    cfg = lan_cfg()
    cfg["devices"] = []
    write_json(DATA / "lan.json", cfg)
    return lan_get()


# ---------------------------------------------------------------- pages
_index_cache = {}


@app.get("/")
def index():
    # scripts and styles get ?v=<code version>: the phone keeps them cached until the next app update (much faster opening)
    st = APP_DIR / "static"   # version = app version + newest change to the page's files, so an edited file is never served stale
    v = f'{code_version()}.{int(max(f.stat().st_mtime for f in [st / "index.html", st / "style.css", *st.glob("js/*.js")]))}'
    if _index_cache.get("v") != v:
        html = (APP_DIR / "static" / "index.html").read_text(encoding="utf-8")
        html = re.sub(r'((?:src|href)="(?:js/[\w.-]+\.js|style\.css))"', lambda m: f'{m.group(1)}?v={v}"', html)
        html = html.replace("<head>", f'<head><script>window.APP_V="{v}"</script>', 1)
        _index_cache.update(v=v, html=html)
    resp = make_response(_index_cache["html"])
    resp.headers["Content-Type"] = "text/html; charset=utf-8"
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/<path:name>")
def static_files(name):
    resp = send_from_directory(APP_DIR / "static", name)
    resp.headers["Cache-Control"] = "public, max-age=31536000, immutable" if request.args.get("v") else "no-cache"
    return resp


# ---------------------------------------------------------------- status
def ollama_models():
    if IS_ANDROID:   # no Ollama on phones: don't wait for it
        return None
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=1.5) as r:
            return [m["name"] for m in json.load(r).get("models", [])]
    except Exception:
        return None


def pick_model(models):
    for want in OLLAMA_PREFERRED:
        if want in models:
            return want
    return models[0] if models else None


@app.get("/api/status")
def status():
    models = ollama_models()
    return jsonify({
        "app": "btech-study-desk",
        "platform": PLATFORM,
        "local": is_local(),
        "ai": {"running": models is not None, "models": models or [], "model": pick_model(models or [])},
        "startup": STARTUP_LNK.exists() if IS_WINDOWS else False,
        "portal": {**portal_state, "lastSync": portal_cfg().get("lastSync")},
        "browser": can_browse(),
        "dataDir": str(ROOT),
    })


# ---------------------------------------------------------------- planner + notes + sources
@app.get("/api/planner")
def get_planner():
    return jsonify(read_json(DATA / "planner.json", None))


@app.get("/api/planner/rev")
def planner_rev():
    return jsonify(rev=(read_json(DATA / "planner.json", None) or {}).get("rev", 0))


planner_lock = threading.Lock()


def _planner_update(fn):
    """Read-modify-write the planner under a lock and bump its revision, so every window sees the change."""
    with planner_lock:
        p = read_json(DATA / "planner.json", None) or {"exams": [], "events": []}
        fn(p)
        p["rev"] = int(p.get("rev", 0)) + 1
        write_json(DATA / "planner.json", p)
        return p


@app.put("/api/planner")
def put_planner():
    body = request.get_json(force=True)

    def merge(p):
        # exams and calendar dates change only through their own add/remove calls below,
        # so an older copy of the planner in another window can never wipe them
        keep = {k: p.get(k, []) for k in ("exams", "events")} if p.get("rev") else {}
        p.clear()
        p.update(body)
        p.update(keep)
    p = _planner_update(merge)
    return jsonify(ok=True, rev=p["rev"])


def _list_ops(kind):
    def add():
        items = request.get_json(force=True).get("items", [])

        def fn(p):
            lst = p.setdefault(kind, [])
            have = {x.get("id") for x in lst}
            lst.extend(x for x in items if x.get("id") and x["id"] not in have)
        p = _planner_update(fn)
        return jsonify(rev=p["rev"], items=p[kind])

    def remove(item_id=None):
        def fn(p):
            p[kind] = [] if item_id is None else [x for x in p.get(kind, []) if x.get("id") != item_id]
        p = _planner_update(fn)
        return jsonify(rev=p["rev"], items=p[kind])
    app.add_url_rule(f"/api/planner/{kind}", f"{kind}_add", add, methods=["POST"])
    app.add_url_rule(f"/api/planner/{kind}/<item_id>", f"{kind}_remove", remove, methods=["DELETE"])
    app.add_url_rule(f"/api/planner/{kind}", f"{kind}_clear", remove, methods=["DELETE"])


_list_ops("exams")
_list_ops("events")


@app.get("/api/notes")
def list_notes():
    out = [read_json(p, None) for p in NOTES.glob("*.json")]
    out = [n for n in out if n]
    out.sort(key=lambda n: n.get("createdAt", 0), reverse=True)
    return jsonify(out)


@app.put("/api/notes/<nid>")
def put_note(nid):
    body = request.get_json(force=True)
    note, md = body.get("note"), body.get("markdown")
    write_json(NOTES / f"{safe_id(nid)}.json", note)
    if md:
        name = re.sub(r'[<>:"/\\|?*]+', "", f"{note.get('subject') or 'General'} - {note.get('title') or nid}")[:120]
        (NOTES_MD / f"{name}.md").write_text(md, encoding="utf-8")
    return jsonify(ok=True)


@app.patch("/api/notes/<nid>/progress")
def patch_progress(nid):
    p = NOTES / f"{safe_id(nid)}.json"
    note = read_json(p, None)
    if note is None:
        return jsonify(error="not found"), 404
    note["progress"] = request.get_json(force=True)
    write_json(p, note)
    return jsonify(ok=True)


@app.delete("/api/notes/<nid>")
def delete_note(nid):
    trash = DATA / "trash"
    trash.mkdir(exist_ok=True)
    for p in (NOTES / f"{safe_id(nid)}.json", SOURCES / f"{safe_id(nid)}.txt"):
        if p.exists():
            os.replace(p, trash / p.name)   # recoverable, never hard-deleted
    return jsonify(ok=True)


@app.put("/api/sources/<nid>")
def put_source(nid):
    (SOURCES / f"{safe_id(nid)}.txt").write_bytes(request.get_data()[:5_000_000])
    return jsonify(ok=True)


@app.get("/api/sources/<nid>")
def get_source(nid):
    p = SOURCES / f"{safe_id(nid)}.txt"
    return Response(p.read_text(encoding="utf-8", errors="replace") if p.exists() else "", mimetype="text/plain")


# ---------------------------------------------------------------- class timetable (ATU: timetable.nithitsuki.com/<batch>/<section>/<sem>)
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]


def _parse_timetable(h):
    from html import unescape
    marks = sorted((h.find(f">{d}<"), d) for d in DAYS if h.find(f">{d}<") >= 0)
    days = {d: [] for _, d in marks}
    titles = list(re.finditer(r'title="([^"]+?)"', h))
    for k, m in enumerate(titles):
        t = unescape(m.group(1))
        mm = re.match(r"^(.+?)\s*\n\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*$", t)
        if not mm:
            continue
        day = next((d for p, d in reversed(marks) if p < m.start()), None)
        if not day:
            continue
        cell = h[m.end(): titles[k + 1].start() if k + 1 < len(titles) else m.end() + 800][:800]
        spans = [unescape(s).strip() for s in re.findall(r"<span[^>]*>([^<]*)</span>", cell)]
        days[day].append({"name": mm.group(1).strip(), "short": (spans[0] if spans else "")[:12], "start": mm.group(2).zfill(5), "end": mm.group(3).zfill(5),
                          "lab": any(s.upper() == "LAB" for s in spans)})
    for d in days:
        days[d].sort(key=lambda x: x["start"])
    # subject list: "MFC(A)" … "22MAT220" … "Mathematics for Computing 3"
    text = re.sub(r"<[^>]+>", "\n", h)
    lines = [unescape(l).strip() for l in text.splitlines() if l.strip()]
    short = {s["name"]: s["short"] for sl in days.values() for s in sl}
    subjects = [{"code": l, "name": lines[i + 1], "short": short.get(lines[i + 1], "")}
                for i, l in enumerate(lines) if re.match(r"^\d{2}[A-Z]{2,5}\d{3}$", l) and i + 1 < len(lines)]
    # "Foundation Elective I: Message of Bhagavadgita, … Business Communication": one slot shared by the elective options
    electives = []
    for i, l in enumerate(lines):
        if re.match(r"^foundation elective", l, re.I):
            for x in lines[i + 1:i + 12]:
                if re.match(r"^(color|ics|share|day)$", x, re.I):
                    break
                electives.append(x.strip(", "))
    return {"days": days, "subjects": subjects, "electives": [e for e in electives if e]}


@app.get("/api/timetable")
def timetable_get():
    return jsonify(read_json(DATA / "timetable.json", None))


@app.post("/api/timetable/sync")
def timetable_sync():
    url = (request.get_json(force=True).get("url") or "").strip()
    if not re.match(r"^https?://", url):
        return jsonify(error="bad_url", message="Paste the full timetable link (https://…)."), 400
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (StudyDesk timetable sync)"})
        h = urllib.request.urlopen(req, timeout=25).read().decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        return jsonify(error="fetch_failed", message=f"Couldn't open the timetable page ({str(e)[:120]})."), 502
    tt = _parse_timetable(h)
    if not any(tt["days"].values()):
        return jsonify(error="no_classes", message="No classes found on that page. Is it your section's timetable link?"), 422
    tt.update(url=url, fetchedAt=int(time.time() * 1000))
    write_json(DATA / "timetable.json", tt)
    return jsonify(tt)


# ---------------------------------------------------------------- any file → text lines (Word, Excel, PowerPoint, CSV, HTML, .ics, WhatsApp .zip)
def _xml_text(xml, para_tag, text_tag):
    import xml.etree.ElementTree as ET
    root = ET.fromstring(xml)
    out = []
    for p in root.iter():
        if p.tag.endswith("}" + para_tag):
            s = "".join(t.text or "" for t in p.iter() if t.tag.endswith("}" + text_tag)).strip()
            if s:
                out.append(s)
    return out


def _docx(z):
    import xml.etree.ElementTree as ET
    root = ET.fromstring(z.read("word/document.xml"))
    body = next(e for e in root if e.tag.endswith("}body"))
    out = []
    for el in body:
        tag = el.tag.split("}")[1]
        if tag == "p":
            s = "".join(t.text or "" for t in el.iter() if t.tag.endswith("}t")).strip()
            if s:
                out.append(s)
        elif tag == "tbl":   # one line per table row, cells joined with " | "
            for tr in el.iter():
                if tr.tag.endswith("}tr"):
                    cells = ["".join(t.text or "" for t in tc.iter() if t.tag.endswith("}t")).strip() for tc in tr if tc.tag.endswith("}tc")]
                    if any(cells):
                        out.append(" | ".join(cells))
    return out


def _xlsx(z):
    import xml.etree.ElementTree as ET
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")):
            shared.append("".join(t.text or "" for t in si.iter() if t.tag.endswith("}t")))
    out = []
    for name in sorted(n for n in z.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml", n)):
        for row in ET.fromstring(z.read(name)).iter():
            if not row.tag.endswith("}row"):
                continue
            cells = []
            for c in row:
                v = next((x.text for x in c if x.tag.endswith("}v")), None)
                is_t = next((x for x in c if x.tag.endswith("}is")), None)
                if c.get("t") == "s" and v is not None:
                    v = shared[int(v)]
                elif is_t is not None:
                    v = "".join(t.text or "" for t in is_t.iter() if t.tag.endswith("}t"))
                elif v and re.match(r"^\d{5}(\.\d+)?$", v) and 30000 < float(v) < 60000:   # Excel date serial
                    from datetime import timedelta
                    v = (date(1899, 12, 30) + timedelta(days=int(float(v)))).strftime("%d.%m.%Y")
                cells.append((v or "").strip())
            if any(cells):
                out.append(" | ".join(cells))
    return out


def _ics(text):
    out, ev = [], {}
    for line in re.sub(r"\r?\n[ \t]", "", text).splitlines():
        k, _, v = line.partition(":")
        k = k.split(";")[0].upper()
        if k == "BEGIN" and v.strip() == "VEVENT":
            ev = {}
        elif k in ("SUMMARY", "DTSTART", "DTEND"):
            ev[k] = v.strip()
        elif k == "END" and v.strip() == "VEVENT" and ev.get("DTSTART"):
            d = lambda s: f"{s[6:8]}.{s[4:6]}.{s[0:4]}"   # noqa: E731
            end = ev.get("DTEND", ev["DTSTART"])
            out.append(f"{ev.get('SUMMARY', 'Event')} {d(ev['DTSTART'])}" + (f" to {d(end)}" if end[:8] != ev["DTSTART"][:8] else ""))
    return out


def _html(text):
    from html import unescape
    text = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
    text = re.sub(r"(?i)</t[dh]>", " | ", text)
    text = re.sub(r"(?i)<br\s*/?>|</(p|div|tr|li|h\d)>", "\n", text)
    return [l.strip(" |") for l in unescape(re.sub(r"<[^>]+>", " ", text)).splitlines() if l.strip(" |")]


def _decode(b):
    for enc in ("utf-8-sig", "utf-16", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            pass
    return b.decode("utf-8", "replace")


@app.post("/api/extract")
def extract():
    name = request.args.get("name", "").lower()
    data = request.get_data()
    kind = ""
    try:
        if zipfile.is_zipfile(io.BytesIO(data)):
            z = zipfile.ZipFile(io.BytesIO(data))
            names = z.namelist()
            if "word/document.xml" in names:
                lines = _docx(z)
            elif "xl/workbook.xml" in names:
                lines = _xlsx(z)
            elif any(n.startswith("ppt/slides/slide") for n in names):
                lines = []
                for n in sorted((n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)), key=lambda n: int(re.findall(r"\d+", n)[-1])):
                    lines += _xml_text(z.read(n), "p", "t")
            else:   # WhatsApp export .zip (chat .txt + media)
                txt = next((n for n in names if n.lower().endswith(".txt")), None)
                if not txt:
                    return jsonify(error="unsupported", message="That zip has no chat or document inside."), 400
                lines, kind = _decode(z.read(txt)).splitlines(), "whatsapp"
        elif name.endswith(".ics") or data[:15].upper().startswith(b"BEGIN:VCALENDAR"):
            lines, kind = _ics(_decode(data)), "calendar"
        elif name.endswith((".html", ".htm")) or data[:200].lower().lstrip().startswith((b"<!doctype html", b"<html")):
            lines = _html(_decode(data))
        elif name.endswith(".csv"):
            import csv
            lines = [" | ".join(c.strip() for c in row) for row in csv.reader(io.StringIO(_decode(data))) if any(row)]
        elif name.endswith((".doc", ".xls", ".ppt")):
            return jsonify(error="old_office", message="Old .doc/.xls/.ppt files can't be read. Save it as .docx/.xlsx/.pptx or PDF and try again."), 400
        else:
            lines = _decode(data).splitlines()
    except Exception as e:  # noqa: BLE001
        return jsonify(error="unreadable", message=f"Couldn't read that file ({str(e)[:120]})."), 400
    return jsonify(lines=[l for l in lines if l.strip()][:20000], kind=kind)


# ---------------------------------------------------------------- free local AI (optional)
def ollama_payload(body, model, stream):
    payload = {"model": model, "messages": [{"role": "user", "content": body["prompt"]}], "stream": stream,
               "options": {"num_ctx": 8192 if IS_ANDROID else 16384, "temperature": 0.3}}
    if body.get("json"):
        payload["format"] = "json"
    return payload


@app.post("/api/ai/stream")
def ai_stream():
    model = pick_model(ollama_models() or [])
    if not model:
        return jsonify(error="no_ai", message="Free AI is not running."), 503
    body = request.get_json(force=True)
    req = urllib.request.Request(OLLAMA + "/api/chat", data=json.dumps(ollama_payload(body, model, True)).encode(),
                                 headers={"Content-Type": "application/json"})

    def gen():
        try:
            with urllib.request.urlopen(req, timeout=1800) as r:
                for line in r:
                    if not line.strip():
                        continue
                    chunk = json.loads(line)
                    piece = chunk.get("message", {}).get("content", "")
                    if piece:
                        yield piece
                    if chunk.get("done"):
                        break
        except Exception as e:  # noqa: BLE001
            yield f"\n[AI error: {e}]"
    return Response(gen(), mimetype="text/plain; charset=utf-8", headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})


@app.post("/api/ai/pull")
def ai_pull():
    req = urllib.request.Request(OLLAMA + "/api/pull", data=json.dumps({"model": DEFAULT_MODEL, "stream": False}).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=7200) as r:
            return jsonify(json.load(r))
    except Exception as e:  # noqa: BLE001
        return jsonify(error="pull_failed", message=str(e)), 502


# ---------------------------------------------------------------- portal (Windows: Edge + Playwright; Android: the APK's WebView)
from contextlib import contextmanager  # noqa: E402

from agent import AGENT, AUMS_PASSWORD_TOKEN, Context as AgentContext  # noqa: E402


def can_browse():
    return IS_WINDOWS or (IS_ANDROID and AGENT.alive())


def _no_browser(what):
    msg = f"{what} needs My App open on the tablet (it lends its browser to the hub)." if IS_ANDROID else f"{what} runs on the Windows PC or the tablet hub."
    return jsonify(error="no_browser", message=msg), 400


@contextmanager
def _browser(headless=True):
    """A signed-in browser context: Edge on Windows, the My App APK's hidden WebView on Android."""
    if IS_ANDROID:
        ctx = AgentContext(headless)
        try:
            yield ctx
        finally:
            ctx.close()
        return
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        ctx = _launch(p, headless)
        try:
            yield ctx
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass


@app.get("/api/agent/next")
def agent_next():
    job = AGENT.next_job(float(request.args.get("wait", 25)))
    return jsonify(job) if job else ("", 204)


@app.post("/api/agent/result")
def agent_result():
    AGENT.put_result(request.get_json(force=True))
    return jsonify(ok=True)


def _launch(p, headless):
    return p.chromium.launch_persistent_context(
        str(PROFILE), channel="msedge", headless=headless,
        viewport=None if not headless else {"width": 1366, "height": 900},
        args=["--disable-blink-features=AutomationControlled"],
    )


def _login_worker(url):
    portal_state["login_open"] = True
    portal_state["last_error"] = None
    try:
        with _browser(headless=False) as ctx:
            if IS_ANDROID:
                ctx.show(url)          # sign-in window inside My App; returns when the student taps Done
                return
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            while True:  # wait until the student closes the window
                try:
                    if not ctx.pages:
                        break
                    ctx.pages[0].wait_for_timeout(1000)
                except Exception:
                    break
            try:
                ctx.close()
            except Exception:
                pass
    except Exception as e:  # noqa: BLE001
        portal_state["last_error"] = str(e)
    finally:
        portal_state["login_open"] = False


@app.post("/api/portal/login")
def portal_login():
    if not can_browse():
        return _no_browser("Portal sign-in")
    if portal_state["login_open"] or portal_state["login_pending"]:
        return jsonify(error="busy", message="A sign-in window is already open."), 409
    url = request.get_json(force=True).get("url", "")
    if not re.match(r"^https?://", url):
        return jsonify(error="bad_url", message="The URL must start with https://"), 400

    def queued():   # waits for a running sync to finish, then opens the sign-in window
        portal_state["login_pending"] = True
        try:
            if _wait_turn(600):
                portal_state["login_open"] = True
                portal_state["syncing"] = False
                _login_worker(url)
        finally:
            portal_state["login_pending"] = False
    threading.Thread(target=queued, daemon=True).start()
    return jsonify(ok=True)


EXTRACT_JS = """() => {
  const clean = s => (s || '').replace(/\\s+/g, ' ').trim();
  const tables = [...document.querySelectorAll('table')].map(t =>
    [...t.rows].map(r => [...r.cells].map(c => clean(c.innerText))).filter(r => r.some(Boolean))
  ).filter(t => t.length > 1);
  const pw = [...document.querySelectorAll('input[type=password]')].some(i => i.offsetParent !== null);
  return {title: document.title, text: (document.body ? document.body.innerText : '').slice(0, 60000), tables, needsLogin: pw};
}"""


LOGIN_PAGE = re.compile(r"login\.microsoftonline\.com|/index/login|/login\b|/signin|/sso/", re.I)


def _settle(page, ms=12000):
    try:
        page.wait_for_load_state("networkidle", timeout=ms)
    except Exception:
        pass


def _silent_relogin(page):
    """Get back in without a password: click the portal's LOGIN button and let the remembered
    Microsoft 365 sign-in finish (account picker / "Stay signed in?" are answered, never a password).
    Returns True when signed in again, False when the student has to sign in themselves."""
    for _ in range(6):
        url = page.url
        if not LOGIN_PAGE.search(url):
            return True
        if "login.microsoftonline.com" in url:
            if page.locator("input[type=password]:visible").count():
                return False                       # Microsoft wants the password: student must sign in
            tile = page.locator("#tilesHolder [data-test-id], #tilesHolder .table[role=button], div[data-bind*='selectAccount']").first
            yes = page.locator("#idSIButton9:visible, input[type=submit][value='Yes']:visible").first
            if tile.count():
                tile.click()
            elif yes.count():
                yes.click()                        # "Stay signed in?" -> Yes
            else:
                page.wait_for_timeout(2500)
        else:
            # myAmrita: the LOGIN text runs $('#submitBtn').click(); other portals have a normal button
            clicked = page.evaluate("""() => {
              const sub = document.querySelector('#submitBtn');
              if (sub) { sub.click(); return true; }
              const el = [...document.querySelectorAll('button,a,input[type=submit],span,div')]
                .reverse().find(e => /^\\s*(log\\s*in|sign\\s*in)\\s*$/i.test(e.innerText || e.value || '') && (e.offsetWidth || e.offsetHeight));
              if (el) { el.click(); return true; }
              return false;
            }""")
            if not clicked:
                return False
        try:   # wait for the SSO hop instead of clicking again too early
            page.wait_for_url(lambda u: u != url, timeout=20000)
        except Exception:
            pass
        page.wait_for_timeout(1500)
        _settle(page, 15000)
    return not LOGIN_PAGE.search(page.url)


TERM_RE = re.compile(r"(\d{4})\s*-\s*\d{2}\s*(Odd|Even)\s*Sem", re.I)


def _term_key(name):
    m = TERM_RE.search(name or "")
    return (int(m.group(1)), 0 if m.group(2).lower() == "odd" else 1) if m and "only" not in name.lower() else None


def _current_term_key(today=None):
    today = today or date.today()   # Odd sem = Jul-Dec, Even sem = Jan-Jun of the next calendar year
    return (today.year, 0) if today.month >= 7 else (today.year - 1, 1)


def _expand_terms(page, links, batch):
    """Replace academic_term_id=current / =each with real term ids read from the portal's own selector."""
    if not any(re.search(r"academic_term_id=(current|each)", l.get("url", "")) for l in links):
        return links
    base = next(l["url"] for l in links if "academic_term_id=" in l.get("url", "")).split("?")[0]
    page.goto(base, wait_until="domcontentloaded", timeout=45000)
    _settle(page)
    if LOGIN_PAGE.search(page.url) and _silent_relogin(page):
        page.goto(base, wait_until="domcontentloaded", timeout=45000)
        _settle(page)
    opts = page.evaluate("() => [...document.querySelectorAll('select[name=academic_term_id] option')].map(o => [o.value, o.text.trim()])")
    terms = sorted(((_term_key(n), v, n) for v, n in opts if _term_key(n)), key=lambda t: t[0])
    cur = _current_term_key()
    # the batch year decides the semester number; fall back to the profile if the portal settings don't have it yet
    batch = batch or (read_json(DATA / "planner.json", {}) or {}).get("profile", {}).get("batch")
    mine = [t for t in terms if (not batch or t[0] >= (int(batch), 0)) and t[0] <= cur]

    def sem_no(key, i):   # 2025 batch: 2025-26 Odd = Sem 1, Even = Sem 2, 2026-27 Odd = Sem 3 … (never counted, so extra terms can't shift it)
        return (key[0] - int(batch)) * 2 + (1 if key[1] == 0 else 2) if batch else i + 1
    out = []
    for l in links:
        u = l.get("url", "")
        if "academic_term_id=current" in u and mine:
            out.append({**l, "url": u.replace("academic_term_id=current", "academic_term_id=" + mine[-1][1]), "term": mine[-1][2], "sem": f"Sem {sem_no(mine[-1][0], len(mine) - 1)}"})
        elif "academic_term_id=each" in u:
            for i, (k, v, n) in enumerate(mine):
                out.append({**l, "id": f"{l.get('id')}-{v}", "url": u.replace("academic_term_id=each", "academic_term_id=" + v), "term": n, "sem": f"Sem {sem_no(k, i)}"})
        else:
            out.append(l)
    return out


def _gatepass_rows(results):
    rows = []
    for r in results:
        for t in r.get("tables") or []:
            h = [c.lower() for c in t[0]]
            if "pass name" in h and "final status" in h:
                rows += [dict(zip(h, row)) for row in t[1:]]
    return rows


def _absences(results):
    """myAmrita Absent Report -> {"22MAT220|2026-11-02|1": "Mathematics for Computing 3", ...}"""
    out = {}
    for r in results:
        for t in r.get("tables") or []:
            h = [c.lower() for c in t[0]]
            if "absent dates" in h and "course" in h:
                for row in t[1:]:
                    course = row[h.index("course")] if h.index("course") < len(row) else ""
                    m = re.match(r"\s*(\d{2}[A-Z]{2,5}\d{3})\s*(.*)", course)
                    code, name = (m.group(1), m.group(2).strip()) if m else (course, course)
                    for d, p in re.findall(r"(\d{4}-\d{2}-\d{2})\s+(\d{1,2})\b", row[h.index("absent dates")] if h.index("absent dates") < len(row) else ""):
                        out[f"{code}|{d}|{p}"] = name or code
    return out


def _notify_new_absences(results):
    """The moment a teacher marks you absent: one notification per class (recent days only)."""
    now = _absences(results)
    if not now:
        return
    st = read_json(DATA / "state.json", {})
    old = st.get("absences")
    if old is not None:
        recent = (date.today() - timedelta(days=3)).isoformat()
        fresh = sorted(k for k in now if k not in old and k.split("|")[1] >= recent)
        by_course = {}
        for k in fresh:
            code, d, p = k.split("|")
            by_course.setdefault((now[k], d), []).append(p)
        for (name, d), periods in by_course.items():
            when = "today" if d == date.today().isoformat() else d
            notify(f"Marked absent: {name}", [f"Period {', '.join(sorted(periods, key=int))} · {when}", "Open My App → Attendance to see the calendar."])
    st["absences"] = sorted(now)
    write_json(DATA / "state.json", st)


def _notify_gatepass_changes(results):
    st = read_json(DATA / "state.json", {})
    old = st.get("passes", {})
    new = {r.get("id"): r.get("final status", "") for r in _gatepass_rows(results) if r.get("id")}
    if not new:
        return
    if old:
        for pid, status in new.items():
            if old.get(pid) and old[pid] != status:
                row = next(r for r in _gatepass_rows(results) if r.get("id") == pid)
                notify(f"Gate pass {status.lower()}", [f"{row.get('pass name', 'Pass')} {row.get('from', '')} → {row.get('to', '')}"])
    st["passes"] = new
    write_json(DATA / "state.json", st)


def fetch_portal(links, explore=False, quick=False):
    """quick = the light class-hours refresh: only this semester's pages (attendance, absent report, marks, gate pass);
    older semesters' marks and the leave list are kept from the last full sync, so the phone isn't busy for minutes."""
    results = []
    portal_state["syncing"] = True
    try:
        with _browser() as ctx:
            page = ctx.new_page()
            try:
                links = _expand_terms(page, links, portal_cfg().get("batch"))
            except Exception as e:  # noqa: BLE001
                portal_state["last_error"] = "term lookup: " + str(e).splitlines()[0][:200]
            if quick:
                sems = [int(re.sub(r"\D", "", l.get("sem") or "") or 0) for l in links]
                top = max(sems or [0])
                links = [l for l, n in zip(links, sems) if l.get("id") != "leave" and (not str(l.get("id", "")).startswith("marks-") or n == top)]
            api_log = []

            def on_response(resp):
                try:
                    if explore and "json" in (resp.headers.get("content-type") or "") and len(api_log) < 60:
                        api_log.append({"url": resp.url, "body": resp.text()[:20000]})
                except Exception:
                    pass
            page.on("response", on_response)
            for link in links:
                item = {"id": link.get("id"), "label": link.get("label"), "kind": link.get("kind"), "url": link.get("url"),
                        "term": link.get("term"), "sem": link.get("sem")}
                try:
                    page.goto(link["url"], wait_until="domcontentloaded", timeout=45000)
                    _settle(page)
                    if LOGIN_PAGE.search(page.url):
                        item["relogin"] = True
                        if not _silent_relogin(page):
                            item.update(ok=False, needsLogin=True, finalUrl=page.url, tables=[], text="")
                            results.append(item)
                            continue
                        page.goto(link["url"], wait_until="domcontentloaded", timeout=45000)
                        _settle(page)
                    page.wait_for_timeout(1500)   # JS portals often fill tables late
                    data = page.evaluate(EXTRACT_JS)
                    data["needsLogin"] = data["needsLogin"] or bool(LOGIN_PAGE.search(page.url))
                    if explore:
                        data["links"] = page.evaluate("() => [...document.querySelectorAll('a[href]')].map(a => [a.innerText.trim().slice(0,60), a.href]).filter(x => x[0])")
                    for fr in page.frames[1:]:
                        try:
                            sub = fr.evaluate(EXTRACT_JS)
                            data["tables"] += sub["tables"]
                            data["text"] += "\n" + sub["text"][:20000]
                            data["needsLogin"] = data["needsLogin"] or sub["needsLogin"]
                        except Exception:
                            pass
                    item.update(data, ok=not data["needsLogin"], finalUrl=page.url)
                except Exception as e:  # noqa: BLE001
                    item.update(ok=False, error=str(e).splitlines()[0][:300])
                results.append(item)
    finally:
        portal_state["syncing"] = False
    if explore:
        return {"results": results, "api": api_log}
    if any(r.get("needsLogin") for r in results):
        notify("Portal needs you to sign in", ["Your Microsoft sign-in for the portal expired.", "Open Study Desk → Portal & settings → Sign in."])
    try:
        _notify_gatepass_changes(results)
    except Exception:  # noqa: BLE001
        pass
    if quick:   # keep what this round didn't fetch (older semesters' marks, leave list) from the last sync
        got = {r.get("id") for r in results}
        results += [r for r in read_json(DATA / "portal-cache.json", {}).get("results", []) if r.get("id") not in got]
    cache = {"fetchedAt": int(time.time() * 1000), "results": results}
    write_json(DATA / "portal-cache.json", cache)
    cfg = portal_cfg()
    cfg["lastSync"] = cache["fetchedAt"]
    write_json(DATA / "portal.json", cfg)
    return cache


@app.get("/api/portal")
def get_portal():
    return jsonify(portal_cfg())


@app.put("/api/portal")
def put_portal():
    cfg = portal_cfg()
    body = request.get_json(force=True)
    for k in ("links", "autoSync", "alerts", "alertHour", "appliedAt", "batch", "syncEveryHours", "classAlerts", "classLead", "classAlarm", "alarmSound", "alarmVibrate", "alarmRepeat", "installsUrl"):
        if k in body:
            cfg[k] = body[k]
    write_json(DATA / "portal.json", cfg)
    return jsonify(cfg)


@app.post("/api/portal/sync")
def portal_sync():
    if not can_browse():
        return _no_browser("Automatic sync")
    links = [l for l in portal_cfg()["links"] if l.get("url")]
    if not links:
        return jsonify(error="no_links", message="Add a portal page first."), 400
    if not _wait_turn():
        return jsonify(error="busy", message="Still busy with the portal (a sync or a sign-in window). Try again in a few minutes."), 409
    try:
        return jsonify(fetch_portal(links))
    except Exception as e:  # noqa: BLE001
        msg = str(e).splitlines()[0][:300]
        return jsonify(error="sync_failed", message=("Sync failed: " if IS_ANDROID else "Microsoft Edge could not be started: ") + msg), 500


@app.get("/api/portal/cache")
def portal_cache():
    return jsonify(read_json(DATA / "portal-cache.json", None))


# ---------------------------------------------------------------- AUMS (grades, credits, SGPA/CGPA): the student signs in, Study Desk reads
AUMS_URL = "https://aumsblr.amrita.edu/aums/Jsp/Core_Common/index.jsp?task=off"
AUMS_KEYS = re.compile(r"grade|result|mark|credit|cgpa|sgpa|course|semester|academic|transcript|profile|registration", re.I)
aums_state = {"status": "idle", "message": "", "startedAt": 0}

FRAME_JS = """() => ({url: location.href, title: document.title,
  tables: [...document.querySelectorAll('table')].map(t => [...t.rows].map(r => [...r.cells].map(c => c.innerText.replace(/\\s+/g, ' ').trim()))).filter(t => t.length > 1 && t[0].length > 1),
  text: (document.body ? document.body.innerText : '').slice(0, 20000),
  links: [...document.querySelectorAll('a')].map(a => [(a.innerText || a.title || '').trim().slice(0, 60), a.href || '', a.getAttribute('onclick') || '']).filter(x => x[0])})"""


# AUMS sign-in saved by the student, encrypted with Windows DPAPI (only this Windows user on this PC can decrypt it)
CRED_FILE = DATA / "aums-signin.bin"


def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    src, dst = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    desc = ctypes.c_wchar_p("Study Desk AUMS") if protect else None
    if not fn(ctypes.byref(src), desc, None, None, None, 0x1, ctypes.byref(dst)):   # 0x1 = no UI
        raise OSError("Windows could not protect the AUMS sign-in.")
    try:
        return ctypes.string_at(dst.pbData, dst.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(dst.pbData)


AUMS_USER_FILE = DATA / "aums-user.json"   # Android: only the username; the password stays in the APK's Keystore


def _aums_cred():
    if IS_ANDROID:
        u = read_json(AUMS_USER_FILE, {}).get("u")
        return {"u": u, "p": AUMS_PASSWORD_TOKEN} if u else None
    if not IS_WINDOWS or not CRED_FILE.exists():
        return None
    try:
        return json.loads(_dpapi(CRED_FILE.read_bytes(), False).decode())
    except Exception:  # noqa: BLE001
        return None


@app.get("/api/aums/signin")
def aums_signin_get():
    c = _aums_cred()
    return jsonify(saved=bool(c), username=(c or {}).get("u", ""), lastSync=read_json(DATA / "aums-cache.json", {}).get("fetchedAt"))


@app.post("/api/aums/signin")
def aums_signin_set():
    b = request.get_json(force=True)
    u, pw = (b.get("username") or "").strip(), b.get("password") or ""
    if IS_ANDROID:   # the APK already saved the password in Android Keystore; never sent here
        if not u:
            return jsonify(error="bad_input", message="Enter your AUMS username."), 400
        write_json(AUMS_USER_FILE, {"u": u})
        return jsonify(saved=True, username=u)
    if not IS_WINDOWS:
        return jsonify(error="windows_only", message="Saved sign-in works on the Windows PC or in the tablet app."), 400
    if not u or not pw:
        return jsonify(error="bad_input", message="Enter both your AUMS username and password."), 400
    CRED_FILE.write_bytes(_dpapi(json.dumps({"u": u, "p": pw}).encode(), True))
    return jsonify(saved=True, username=u)


@app.delete("/api/aums/signin")
def aums_signin_delete():
    for f in (CRED_FILE, AUMS_USER_FILE):
        if f.exists():
            f.unlink()
    return jsonify(saved=False)


def _aums_worker(auto=False):
    cred = _aums_cred()
    aums_state.update(status="signing_in" if cred else "waiting_login",
                      message="Signing in to AUMS…" if cred else "Sign in to AUMS in the window that opened.", startedAt=time.time())
    portal_state["login_open"] = True
    pages = []
    try:
        with _browser(headless=bool(cred)) as ctx:      # saved sign-in: no window at all
            if IS_ANDROID and not cred:
                ctx.show(AUMS_URL)                      # the student signs in inside My App, then taps Done
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(AUMS_URL, wait_until="domcontentloaded", timeout=60000)
            if cred and "/cas/login" in page.url:
                page.fill("input[name=username]", cred["u"])
                page.fill("input[name=password]", cred["p"])
                page.click("input[type=submit], button[type=submit]")
                try:
                    page.wait_for_url(lambda u: "/cas/login" not in u, timeout=30000)
                except Exception:
                    pass
                if "/cas/login" in page.url:
                    err = page.evaluate("() => (document.querySelector('#msg, .errors, .alert-danger, .error') || {}).innerText || ''")
                    raise RuntimeError("AUMS didn't accept the saved sign-in" + (f" ({err.strip()[:80]})" if err.strip() else "") + ". Update it under Marks → AUMS sign-in.")
            deadline = time.time() + 600
            while "/cas/login" in page.url and time.time() < deadline:   # no saved sign-in: the student signs in themselves
                if not ctx.pages:
                    raise RuntimeError("The AUMS window was closed before signing in.")
                page.wait_for_timeout(1000)
            if "/cas/login" in page.url:
                raise RuntimeError("Timed out waiting for the AUMS sign-in.")
            aums_state.update(status="reading", message="Signed in. Reading grades and credits…")
            _settle(page, 15000)

            def grab(pg, label):
                for fr in pg.frames:
                    try:
                        if re.search(r"ipopeng|Core_Common/index\.jsp|/portal", fr.url) and label != "home":
                            continue
                        d = fr.evaluate(FRAME_JS)
                        d["label"] = label
                        pages.append(d)
                    except Exception:
                        pass
            home = page.url
            pages.append({"label": "menu", "menu": page.evaluate(
                "() => [...document.querySelectorAll('a')].filter(a => /grade|mark|score|registration/i.test(a.innerText)).map(a => a.outerHTML.slice(0, 400))")})
            # AUMS menu entries live in a hidden drop-down and run JavaScript, so trigger them directly (no mouse needed)
            for item in ["View Grades", "View Course Registration", "View Marks"]:
                try:
                    if page.url != home:
                        page.goto(home, wait_until="domcontentloaded", timeout=30000)
                        _settle(page, 10000)
                    ok = page.evaluate("""t => { const a = [...document.querySelectorAll('a')].find(a => a.innerText.trim().toLowerCase() === t.toLowerCase());
                        if (!a) return false; a.dispatchEvent(new MouseEvent('mouseover', {bubbles: true})); a.click(); return true; }""", item)
                    if not ok:
                        pages.append({"label": item, "error": "menu item not found"})
                        continue
                    page.wait_for_timeout(2500)
                    _settle(page, 15000)
                    grab(page, item)
                    # a semester / term selector: step through every option (each submit reloads the frame)
                    for fr in page.frames:
                        try:
                            sel = fr.evaluate("""() => { const s = [...document.querySelectorAll('select')].find(s => s.options.length > 1 && /sem|term|year|session/i.test((s.name || s.id || '') + ' ' + (s.closest('tr,div,form') || {}).innerText));
                                return s ? {name: s.name || s.id, options: [...s.options].map(o => [o.value, o.text.trim()])} : null; }""")
                        except Exception:
                            continue
                        if not sel:
                            continue
                        for val, txt in [o for o in sel["options"] if o[0] and not re.search(r"select|choose|--", o[1], re.I)][:12]:
                            try:
                                fr.evaluate("""([n, v]) => { const s = document.querySelector('select[name="' + n + '"], #' + CSS.escape(n)); s.value = v; s.dispatchEvent(new Event('change', {bubbles: true}));
                                    const b = [...document.querySelectorAll('input[type=submit],input[type=button],button')].find(b => /get|show|view|submit|go|search/i.test(b.value || b.innerText)); if (b) b.click(); }""", [sel["name"], val])
                                page.wait_for_timeout(2500)
                                _settle(page, 10000)
                                before = len(pages)
                                grab(page, f"{item} · {txt}")
                                got = pages[before:]
                                if not any(any(len(r) > 1 and r[0] for r in tb[1:]) for g in got for tb in g.get("tables", []) if tb and len(tb) > 1):
                                    del pages[before:]   # an empty future semester: don't keep it
                                    break
                            except Exception as e:  # noqa: BLE001
                                pages.append({"label": f"{item} · {txt}", "error": str(e).splitlines()[0][:200]})
                        break
                except Exception as e:  # noqa: BLE001
                    pages.append({"label": item, "error": str(e).splitlines()[0][:200]})
        write_json(DATA / "aums-cache.json", {"fetchedAt": int(time.time() * 1000), "pages": pages})
        aums_state.update(status="done", message=f"Read {len(pages)} AUMS pages.")
    except Exception as e:  # noqa: BLE001
        aums_state.update(status="error", message=str(e).splitlines()[0][:300])
    finally:
        portal_state["login_open"] = False


@app.post("/api/aums/sync")
def aums_sync():
    if not can_browse():
        return _no_browser("AUMS sync")
    if aums_state["status"] in ("queued", "waiting_login", "signing_in", "reading"):
        return jsonify(error="busy", message="AUMS is already syncing."), 409

    def queued():
        aums_state.update(status="queued", message="Waiting for the current portal sync to finish…", startedAt=time.time())
        if not _wait_turn(600):
            aums_state.update(status="error", message="Still busy with the portal. Try AUMS again in a few minutes.")
            return
        portal_state["login_open"] = True     # hand the turn from "syncing" to the AUMS worker without a gap
        portal_state["syncing"] = False
        _aums_worker()
    threading.Thread(target=queued, daemon=True).start()
    return jsonify(ok=True)


@app.get("/api/aums/status")
def aums_status():
    return jsonify(aums_state)


@app.get("/api/aums/cache")
def aums_cache():
    return jsonify(read_json(DATA / "aums-cache.json", None))


PHOTO = DATA / "profile-photo.jpg"


@app.get("/api/profile/photo")
def photo_get():
    if not PHOTO.exists():
        return Response(status=404)
    resp = send_file(PHOTO, mimetype="image/jpeg")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.put("/api/profile/photo")
def photo_put():
    data = request.get_data()
    if not data or len(data) > 8_000_000:
        return jsonify(error="bad_image", message="Choose a photo under 8 MB."), 400
    PHOTO.write_bytes(data)
    return jsonify(ok=True)


@app.delete("/api/profile/photo")
def photo_delete():
    if PHOTO.exists():
        PHOTO.unlink()
    return jsonify(ok=True)


@app.post("/api/profile/photo/portal")
def photo_from_portal():
    """Copy the student's own photo from the myAmrita profile page (signed-in Edge profile)."""
    if not can_browse():
        return _no_browser("This")

    def job(page, dialogs):
        _open(page, "https://students.amrita.edu/client/profile")
        src = page.evaluate("() => (([...document.images].find(i => /profpic/i.test(i.src)) || {}).src) || ''")
        if not src:
            return None
        is_img = lambda b: bool(b) and (b[:3] == b"\xff\xd8\xff" or b[:4] == b"\x89PNG")
        r = page.request.get(src, headers={"Referer": page.url})
        if r.ok and is_img(r.body()):
            return r.body()
        # the photo server only answers inside the page: capture the shown image at a decent size
        img = page.locator("img[src*='profpic']").first
        img.evaluate("i => { i.style.cssText = 'width:480px;height:auto;max-width:none;max-height:none;border-radius:0'; i.scrollIntoView(); }")
        page.wait_for_function("() => { const i = document.querySelector(\"img[src*='profpic']\"); return i && i.complete && i.naturalWidth > 0; }", timeout=15000)
        return img.screenshot(type="jpeg", quality=90)

    try:
        body = _portal_page(job)
    except Exception as e:  # noqa: BLE001
        return _gp_error(e)
    if not body:
        return jsonify(error="no_photo", message="No photo found on your myAmrita profile."), 404
    PHOTO.write_bytes(body)
    return jsonify(ok=True, bytes=len(body))


INSTALLS_FORM = "https://docs.google.com/forms/d/e/1FAIpQLSdmRggAUsv5_9AVSm0DHTl9thl7yMh5o38EnrA5Ycwh2lExkA/formResponse"


@app.post("/api/installs/report")
def installs_report():
    """Students Portal (classmates edition), only with the student's consent: name, roll number and section
    to the developer's own Google Form. The hub posts it so it only counts as sent once Google accepts it."""
    b = request.get_json(force=True)
    form = urllib.parse.urlencode({"entry.442910476": str(b.get("name", ""))[:80],
                                   "entry.1349217649": str(b.get("roll", ""))[:20],
                                   "entry.1693255136": str(b.get("section", ""))[:20]}).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(INSTALLS_FORM, data=form,
                                    headers={"Content-Type": "application/x-www-form-urlencoded"}), timeout=20) as r:
            return jsonify(ok=r.status == 200)
    except Exception as e:  # noqa: BLE001
        return jsonify(ok=False, message=str(e)[:200]), 502


@app.get("/api/portal/profile")
def portal_profile():
    """Only the student's own basics (name, mobile, email, campus, hostel); never Aadhaar, parents, income or address."""
    if not can_browse():
        return _no_browser("This")
    keep = {"name": "name", "email": "email", "campus": "campus", "allotment": "allotment", "mobile number": "phone"}

    def job(page, dialogs):
        _open(page, "https://students.amrita.edu/client/profile")
        rows = page.evaluate("() => { const t = document.querySelector('table'); return t ? [...t.rows].map(r => [...r.cells].map(c => c.innerText.trim())) : []; }")
        out = {keep[k.strip().lower()]: v for k, v, *_ in [r + [""] for r in rows if len(r) >= 2] if k.strip().lower() in keep}
        # the register number (BL.SC.U4AIE25000) is in the photo link; myAmrita's Email field is the personal one
        reg = page.evaluate("() => { const i = [...document.images].find(i => /roll_no=/i.test(i.src)); return i ? new URL(i.src).searchParams.get('roll_no') || '' : ''; }")
        if reg:
            out["reg"] = reg.upper()
        return out

    try:
        return jsonify(_portal_page(job))
    except Exception as e:  # noqa: BLE001
        return _gp_error(e)


# ---------------------------------------------------------------- gate pass actions (Amrita hostel portal)
GP_BASE = "https://students.amrita.edu/hostel/"
GP_TYPES = {"out": "2", "home": "1", "placement": "3"}


_turn_lock = threading.Lock()


def _wait_turn(timeout=150):
    """Portal jobs share one browser: wait until the running sync / sign-in window is finished, then take the turn."""
    end = time.time() + timeout
    while True:
        with _turn_lock:
            if not portal_state["login_open"] and not portal_state["syncing"]:
                portal_state["syncing"] = True
                return True
        if time.time() > end:
            return False
        time.sleep(1)


def _portal_page(fn):
    """Run fn(page) in the signed-in browser, one portal job at a time (waits its turn)."""
    if not _wait_turn():
        raise RuntimeError("My App is still busy with the portal (a sync or a sign-in window). Try again in a few minutes.")
    try:
        with _browser() as ctx:
            page = ctx.new_page()
            dialogs = []

            def on_dialog(d):
                dialogs.append(d.message)
                d.accept()
            page.on("dialog", on_dialog)
            return fn(page, dialogs)
    finally:
        portal_state["syncing"] = False


def _open(page, url):
    page.goto(url, wait_until="domcontentloaded", timeout=45000)
    _settle(page)
    if LOGIN_PAGE.search(page.url):
        if not _silent_relogin(page):
            raise PermissionError("needs_login")
        page.goto(url, wait_until="domcontentloaded", timeout=45000)
        _settle(page)


def _pass_list(page):
    return page.evaluate("""() => { const t = [...document.querySelectorAll('table')].find(t => /pass name/i.test(t.innerText)); if (!t) return [];
      const rows = [...t.rows].map(r => [...r.cells].map(c => c.innerText.trim())); const h = rows[0].map(x => x.toLowerCase());
      return rows.slice(1).map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); }""")


def _flash(page):
    return page.evaluate("() => [...document.querySelectorAll('.alert, .toast, .swal2-title, .swal2-html-container, .help-block, .invalid-feedback, .text-danger')].map(e => e.innerText.trim()).filter(Boolean).slice(0, 5)")


def _gp_error(e):
    if isinstance(e, PermissionError):
        notify("Portal needs you to sign in", ["Your Microsoft sign-in for the portal expired.", "Open Study Desk → Portal & settings → Sign in."])
        return jsonify(error="needs_login", message="Your portal sign-in expired. Use Portal & settings → Sign in, then try again."), 401
    return jsonify(error="failed", message=str(e).splitlines()[0][:300]), 500


@app.post("/api/gatepass/apply")
def gatepass_apply():
    if not can_browse():
        return _no_browser("This")
    b = request.get_json(force=True)
    kind = GP_TYPES.get(b.get("type", ""))
    f_date, f_time, t_date, t_time = b.get("fromDate", ""), b.get("fromTime", ""), b.get("toDate", ""), b.get("toTime", "")
    reason = (b.get("reason") or "").strip()
    if not kind or not re.match(r"^\d{4}-\d{2}-\d{2}$", f_date) or not re.match(r"^\d{4}-\d{2}-\d{2}$", t_date) \
            or not re.match(r"^\d{2}:\d{2}$", f_time) or not re.match(r"^\d{2}:\d{2}$", t_time) or not reason:
        return jsonify(error="bad_input", message="Fill in pass type, reason, from and to date/time."), 400
    dry = bool(b.get("dryRun"))

    def job(page, dialogs):
        _open(page, GP_BASE + "index")
        before = {r.get("id") for r in _pass_list(page)}
        # open the portal's "Add" pop-up like a person would, then fill it (fields work even if the pop-up animates)
        page.evaluate("() => { const b = [...document.querySelectorAll('a,button,span')].find(e => (e.innerText || '').trim() === 'Add' && (e.offsetWidth || e.offsetHeight)); if (b) b.click(); }")
        page.wait_for_timeout(1200)
        filled = page.evaluate("""v => {
          const set = (n, val) => { const e = document.querySelector('[name=' + n + ']'); e.value = val;
            e.dispatchEvent(new Event('input', {bubbles: true})); e.dispatchEvent(new Event('change', {bubbles: true})); };
          set('pass_id', v.kind);              // runs the page's own pass-type handler first
          set('pass_remarks', v.reason); set('pass_date_from', v.fd); set('pass_time_from', v.ft);
          set('pass_date_to', v.td); set('pass_time_to', v.tt);
          return Object.fromEntries(['pass_id','pass_remarks','pass_date_from','pass_time_from','pass_date_to','pass_time_to'].map(n => [n, document.querySelector('[name=' + n + ']').value]));
        }""", {"kind": kind, "reason": reason, "fd": f_date, "ft": f_time, "td": t_date, "tt": t_time})
        if dry:
            return {"ok": True, "dryRun": True, "filled": filled}
        page.evaluate("() => document.querySelector('[name=student_gate_pass_add]').closest('form').requestSubmit(document.querySelector('[name=student_gate_pass_add]'))")
        try:
            page.wait_for_load_state("domcontentloaded", timeout=30000)
        except Exception:
            pass
        _settle(page)
        if "hostel/index" not in page.url:
            _open(page, GP_BASE + "index")
        rows = _pass_list(page)
        new = [r for r in rows if r.get("id") not in before]
        return {"ok": bool(new), "pass": new[0] if new else None, "messages": dialogs + _flash(page), "filled": filled, "passes": rows[:30]}

    try:
        return jsonify(_portal_page(job))
    except Exception as e:  # noqa: BLE001
        return _gp_error(e)


@app.post("/api/gatepass/cancel")
def gatepass_cancel():
    if not can_browse():
        return _no_browser("This")
    pid = re.sub(r"\D", "", str(request.get_json(force=True).get("id", "")))
    if not pid:
        return jsonify(error="bad_input", message="Missing pass id."), 400

    def job(page, dialogs):
        _open(page, f"{GP_BASE}pass?id={pid}")
        btn = page.locator("[name=pass_cancel]")
        if not btn.count():
            return {"ok": False, "message": "This pass can't be cancelled any more."}
        btn.first.click()                             # the portal's "Are you sure???" is accepted
        try:
            page.wait_for_load_state("domcontentloaded", timeout=30000)
        except Exception:
            pass
        _settle(page)
        _open(page, GP_BASE + "index")
        rows = _pass_list(page)
        row = next((r for r in rows if r.get("id") == pid), None)
        return {"ok": bool(row and "cancel" in (row.get("final status") or "").lower()), "pass": row, "messages": dialogs + _flash(page), "passes": rows[:30]}

    try:
        return jsonify(_portal_page(job))
    except Exception as e:  # noqa: BLE001
        return _gp_error(e)


@app.get("/api/gatepass/detail")
def gatepass_detail():
    if not can_browse():
        return _no_browser("This")
    pid = re.sub(r"\D", "", request.args.get("id", ""))

    def job(page, dialogs):
        _open(page, f"{GP_BASE}pass?id={pid}")
        return {"ok": True, "id": pid, "canCancel": page.locator("[name=pass_cancel]").count() > 0,
                "text": page.evaluate("() => (document.querySelector('.content-wrapper, main, .container-fluid') || document.body).innerText.slice(0, 3000)")}

    try:
        return jsonify(_portal_page(job))
    except Exception as e:  # noqa: BLE001
        return _gp_error(e)


@app.get("/api/mirror")
def get_mirror():
    return jsonify(read_json(DATA / "portal-mirror.json", None))


@app.put("/api/mirror")
def put_mirror():
    write_json(DATA / "portal-mirror.json", request.get_json(force=True))
    return jsonify(ok=True)


# ---------------------------------------------------------------- backup / restore
BACKUP_SKIP = ("portal-browser", "trash", "lan.json", "state.json", "aums-signin.bin", "aums-user.json")  # photo is kept in backups


@app.get("/api/backup")
def backup():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in DATA.rglob("*"):
            rel = p.relative_to(DATA)
            if p.is_file() and not str(rel).startswith(BACKUP_SKIP) and not p.name.endswith(".tmp"):
                z.write(p, "data/" + rel.as_posix())
        for p in NOTES_MD.glob("*.md"):
            z.write(p, "notes/" + p.name)
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"StudyDesk-backup-{date.today().isoformat()}.zip")


@app.post("/api/restore")
def restore():
    try:
        z = zipfile.ZipFile(io.BytesIO(request.get_data()))
    except zipfile.BadZipFile:
        return jsonify(error="bad_zip", message="That isn't a Study Desk backup file."), 400
    names = [n for n in z.namelist() if n.startswith(("data/", "notes/")) and ".." not in n and not n.endswith("/")]
    if "data/planner.json" not in names and not any(n.startswith("data/notes/") for n in names):
        return jsonify(error="bad_zip", message="That isn't a Study Desk backup file."), 400
    # keep a safety copy of the current data first
    safety = ROOT / f"data-before-restore-{datetime.now():%Y%m%d-%H%M%S}"
    shutil.copytree(DATA, safety, ignore=shutil.ignore_patterns("portal-browser"))
    for n in names:
        target = ROOT / n
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(z.read(n))
    return jsonify(ok=True, restored=len(names), safetyCopy=str(safety))


# ---------------------------------------------------------------- reminders (Windows toast / Android notification)
PS_APP_ID = r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"


def notify(title, lines, alarm=False):
    """alarm=True: rings like an alarm (alarm sound + vibration, keeps ringing until tapped) — used for class reminders."""
    lines = [l for l in lines if l]
    if IS_ANDROID and os.environ.get("MYAPP_STANDALONE"):   # inside the My App APK: a real Android notification
        try:
            from java import jclass
            n = jclass("app.myapp.amrita.Notify")
            if alarm:   # general ringing settings (Settings → Alarm ringing)
                c = portal_cfg()
                n.alarm(title, "\n".join(lines), c.get("alarmSound", "alarm"), c.get("alarmVibrate", True) is not False, c.get("alarmRepeat", True) is not False)
            else:
                n.show(title, "\n".join(lines))
        except Exception:  # noqa: BLE001
            pass
        return
    if IS_ANDROID:
        if shutil.which("termux-notification"):
            subprocess.run(["termux-notification", "--id", "studydesk", "--title", title, "--content", "\n".join(lines),
                            "--action", f"termux-open-url {URL}", "--priority", "high"], check=False, timeout=30)
        return
    if not IS_WINDOWS:
        print(title, lines)
        return
    body = "".join(f"<text>{xml_escape(l)}</text>" for l in lines[:2])
    rep = portal_cfg().get("alarmRepeat", True) is not False
    sound = (f'<audio src="ms-winsoundevent:Notification.Looping.Alarm" loop="{str(rep).lower()}"/>' if portal_cfg().get("alarmSound", "alarm") == "alarm"
             else '<audio src="ms-winsoundevent:Notification.Reminder"/>') if alarm else ""
    xml = (f'<toast activationType="protocol" launch="{URL}"{' scenario="reminder"' if alarm else ''}><visual><binding template="ToastGeneric">'
           f"<text>{xml_escape(title)}</text>{body}</binding></visual>{sound}</toast>")
    script = (
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null;"
        "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null;"
        "$x = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        f"$x.LoadXml('{xml.replace(chr(39), chr(39) * 2)}');"
        f"[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{PS_APP_ID}').Show([Windows.UI.Notifications.ToastNotification]::new($x))"
    )
    enc = base64.b64encode(script.encode("utf-16-le")).decode()
    subprocess.run(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-EncodedCommand", enc],
                   creationflags=NOWIN, timeout=30, check=False)


def build_alerts():
    plan = read_json(DATA / "planner.json", None)
    if not plan or plan.get("example"):
        return []
    today = date.today()
    out = []
    for e in sorted(plan.get("exams", []), key=lambda e: e.get("date", "")):
        try:
            d = (date.fromisoformat(e["date"]) - today).days
        except (KeyError, ValueError):
            continue
        if 0 <= d <= 3 or d == 7:
            when = "TODAY" if d == 0 else "tomorrow" if d == 1 else f"in {d} days"
            out.append(f"{e.get('sub', '')} {e.get('type', '')} {when}".strip())
    for ev in plan.get("events", []):   # imported deadlines and exams from calendars / WhatsApp
        try:
            d = (date.fromisoformat(ev["start"]) - today).days
        except (KeyError, ValueError):
            continue
        if ev.get("type") in ("deadline", "exam") and 0 <= d <= 2:
            out.append(f"{ev.get('title', '')[:60]} {'TODAY' if d == 0 else 'tomorrow' if d == 1 else 'in 2 days'}")
    att = plan.get("att", {})   # attended already includes medical leave for portal subjects
    mn = float(att.get("min") or 75)
    for s in att.get("subs", []):
        a, t = float(s.get("a") or 0), float(s.get("t") or 0)
        if t and a / t * 100 < mn:
            out.append(f"{s.get('n', 'A subject')}: attendance {a / t * 100:.0f}% (below {mn:.0f}%)")
    return out


# ---------------------------------------------------------------- class reminders: 5 min before each class, with attendance now / if present / if bunk
def _nrm(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def _class_message(slot, tt, mirror, min_pct):
    rows = (mirror or {}).get("attendance", {}).get("rows", []) if mirror else []
    row = next((r for r in rows if _nrm(r.get("course")) == _nrm(slot["name"])), None)
    sub = next((s for s in tt.get("subjects", []) if s["name"] == slot["name"]), None)
    if not row and sub:
        row = next((r for r in rows if r.get("code") and r["code"][2:] == sub["code"][2:]), None)
    el = [_nrm(e) for e in tt.get("electives", []) if re.search(r"[a-z]{3}", e, re.I)]
    if not row and _nrm(slot["name"]) in el:   # elective slot (BG) → the student's elective
        row = next((r for r in rows if _nrm(r.get("course")) in el), None)
    w = (3 if re.search(r"mathematics for computing|^mfc$", slot["name"] + "|" + slot["short"], re.I) else 2) if slot.get("lab") else 1
    title = f"{slot['short']}{' LAB' if slot.get('lab') else ''} at {slot['start']} · {slot['name']}"
    if not row:
        return title, "Class starts in 5 minutes."
    a = row.get("present", 0) + row.get("dl", 0) + row.get("medical", 0)
    t = row.get("total", 0)
    now, pres, bunk = (a / t * 100 if t else 100), (a + w) / (t + w) * 100, a / (t + w) * 100
    verdict = "don't bunk" if bunk < min_pct else "risky to bunk" if bunk < min_pct + 2 else "safe to bunk"
    return title, f"Attendance {now:.1f}% · if present {pres:.1f}% · if bunk {bunk:.1f}% ({verdict})"


def class_alert_loop():
    sent = set()
    while True:
        try:
            cfg = portal_cfg()
            tt = read_json(DATA / "timetable.json", None)
            plan = read_json(DATA / "planner.json", {}) or {}
            bells = {k: v for k, v in (plan.get("alarmSubs") or {}).items() if v}   # subject -> minutes before (True = default)
            if (cfg.get("classAlerts", True) or bells) and tt:
                now = datetime.now()
                today = now.date().isoformat()
                holiday = any(e.get("type") == "holiday" and e.get("start", "") <= today <= (e.get("end") or e.get("start", ""))
                              for e in plan.get("events", []))
                default_lead = int(cfg.get("classLead", 5))
                if not holiday:
                    for slot in tt.get("days", {}).get(now.strftime("%a"), []):
                        bell = bells.get(slot.get("short"))
                        if not bell and not cfg.get("classAlerts", True):
                            continue
                        lead = int(bell) if bell and bell is not True else default_lead
                        h, m = map(int, slot["start"].split(":"))
                        mins = (h * 60 + m) - (now.hour * 60 + now.minute)
                        key = today + slot["start"] + slot["short"]
                        if 0 < mins <= lead and key not in sent:
                            sent.add(key)
                            title, body = _class_message(slot, tt, read_json(DATA / "portal-mirror.json", None),
                                                         float((plan.get("att") or {}).get("min") or 75))
                            notify(title, [body], alarm=bool(cfg.get("classAlarm")) or bool(bell))
        except Exception:  # noqa: BLE001 - the loop must never die
            pass
        time.sleep(30)


@app.post("/api/alerts/class-test")
def class_alert_test():
    """Show what the reminder for the next class will look like."""
    tt = read_json(DATA / "timetable.json", None)
    if not tt:
        return jsonify(error="no_timetable", message="Add your class timetable link first."), 400
    plan = read_json(DATA / "planner.json", {}) or {}
    for i in range(0, 15):
        d = date.fromordinal(date.today().toordinal() + i)
        slots = tt.get("days", {}).get(d.strftime("%a"), [])
        if i == 0:
            nowm = datetime.now().hour * 60 + datetime.now().minute
            slots = [s for s in slots if int(s["start"][:2]) * 60 + int(s["start"][3:]) > nowm]
        if slots:
            title, body = _class_message(slots[0], tt, read_json(DATA / "portal-mirror.json", None), float((plan.get("att") or {}).get("min") or 75))
            notify(title, [body], alarm=bool(portal_cfg().get("classAlarm")))
            return jsonify(ok=True, title=title, body=body)
    return jsonify(error="none", message="No upcoming classes found."), 404


@app.post("/api/alerts/test")
def alerts_test():
    items = build_alerts() or ["Reminders are working. You'll get exam and attendance alerts here."]
    notify("BTech Study Desk", ["\n".join(items[:3]), f"+{len(items) - 3} more" if len(items) > 3 else ""])
    return jsonify(ok=True, items=items)


def background_loop():
    state_p = DATA / "state.json"
    time.sleep(120)   # never sync while the app is just opening: let the student use it first
    while True:
        try:
            cfg, st = portal_cfg(), read_json(state_p, {})
            now, today = datetime.now(), date.today().isoformat()
            every = float(cfg.get("syncEveryHours") or 3) * 3600
            if now.weekday() < 6 and (8, 0) <= (now.hour, now.minute) <= (17, 30):
                every = min(every, 1800)   # class hours: near real-time attendance
            last = (cfg.get("lastSync") or 0) / 1000
            full_every = float(cfg.get("syncEveryHours") or 3) * 3600
            quick = time.time() - (cfg.get("lastFullSync") or 0) / 1000 < full_every   # a full sync ran recently: light refresh only
            if (can_browse() and cfg.get("autoSync") and cfg["links"] and 6 <= now.hour <= 23 and time.time() - last >= every
                    and not portal_state["login_open"] and not portal_state["syncing"]):
                try:
                    if _wait_turn(0):
                        fetch_portal(cfg["links"], quick=quick)     # also notifies gate pass approvals
                        if not quick:
                            c2 = portal_cfg(); c2["lastFullSync"] = c2.get("lastSync"); write_json(DATA / "portal.json", c2)
                except Exception:  # noqa: BLE001
                    pass
                st = read_json(state_p, {})
            aums_last = (read_json(DATA / "aums-cache.json", {}).get("fetchedAt") or 0) / 1000
            if (can_browse() and _aums_cred() and 6 <= now.hour <= 23 and time.time() - aums_last > 7 * 86400
                    and not portal_state["login_open"] and not portal_state["syncing"]):
                _aums_worker(auto=True)          # grades + credits refresh, silently
            if now.hour >= int(cfg.get("alertHour", 8)):
                if cfg.get("alerts", True) and st.get("alerted") != today:
                    items = build_alerts()
                    if items:
                        notify(f"{len(items)} study reminder{'s' if len(items) > 1 else ''}",
                               ["\n".join(items[:3]), f"+{len(items) - 3} more. Open Study Desk." if len(items) > 3 else "Open Study Desk."])
                    st["alerted"] = today
                    write_json(state_p, st)
        except Exception:  # noqa: BLE001 - the loop must never die
            pass
        time.sleep(600)


# ---------------------------------------------------------------- start with Windows / quit
@app.post("/api/startup")
def startup():
    if not IS_WINDOWS:
        return jsonify(startup=False)
    enable = bool(request.get_json(force=True).get("enabled"))
    if enable:
        pyw = Path(sys.executable).with_name("pythonw.exe")
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK);"
              "$s.TargetPath=$env:TGT;$s.Arguments=$env:ARGS;$s.WorkingDirectory=$env:WD;"
              "$s.IconLocation=$env:ICO;$s.Description='BTech Study Desk (background reminders)';$s.Save()")
        env = {**os.environ, "LNK": str(STARTUP_LNK), "TGT": str(pyw), "ARGS": f'"{APP_DIR / "server.py"}" --background',
               "WD": str(APP_DIR), "ICO": str(APP_DIR / "static" / "icon.ico")}
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=env, check=False, creationflags=NOWIN)
    elif STARTUP_LNK.exists():
        STARTUP_LNK.unlink()
    return jsonify(startup=STARTUP_LNK.exists())


@app.post("/api/quit")
def quit_app():
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return jsonify(ok=True)


# ---------------------------------------------------------------- admin: who installed the classmates app
# Only your own edition: it reads your private Google Apps Script link (with its secret key, saved in your data, never in
# the app code) and notifies you of each new install that a classmate agreed to report (name, roll number, section).
INSTALLS_FILE = DATA / "installs.json"


def check_installs(notify_new=True):
    url = portal_cfg().get("installsUrl", "")
    if not url.startswith("https://script.google.com/"):
        return {"error": "no link"}
    seen = read_json(INSTALLS_FILE, {"rows": [], "checked": None})
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "MyApp"}), timeout=30) as r:
            got = json.loads(r.read(2_000_000))
    except Exception as e:  # noqa: BLE001
        return {**seen, "error": str(e)[:200]}
    if "rows" not in got:
        return {**seen, "error": got.get("error", "unexpected reply")}
    old = {row.get("t") for row in seen["rows"]}
    new = [row for row in got["rows"] if row.get("t") not in old]
    seen = {"rows": sorted(got["rows"], key=lambda x: x.get("t", 0), reverse=True), "checked": datetime.now().isoformat(timespec="minutes")}
    write_json(INSTALLS_FILE, seen)
    if notify_new and new and old:   # the first check only fills the list
        lines = [f"{x.get('name', '?')} · {x.get('roll', '')} · {x.get('section', '')}" for x in new[:5]]
        notify(f"{len(new)} new install{'s' if len(new) > 1 else ''} of Students Portal", lines)
    return {**seen, "new": len(new)}


def installs_loop():
    time.sleep(60)
    while True:
        if portal_cfg().get("installsUrl"):
            check_installs()
        time.sleep(30 * 60)


@app.get("/api/installs")
def get_installs():
    return jsonify(read_json(INSTALLS_FILE, {"rows": [], "checked": None}))


@app.post("/api/installs/check")
def post_installs_check():
    return jsonify(check_installs(notify_new=False))


# ---------------------------------------------------------------- admin: calendar + exams for every phone
# On your PC (it has the signing key and GitHub) you edit the default academic calendar and end-sem exams and press
# Publish: a signed content.json goes to GitHub. Every phone checks it on opening and every 30 minutes, checks your
# signature, and shows the new dates at once (no app update, no restart). Phones can't publish: they have no key.
CONTENT_FILE = DATA / "content.json"                   # newest verified copy on this device
SIGN_KEY = ROOT / "android-tools" / "update-key.txt"   # private key: only on your PC
UPDATES_REPO = ROOT / "myapp-updates"                  # your GitHub folder (public)
content_state = {"checked": None, "error": None}


def _canon(d):
    return json.dumps(d, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _bundled():
    return {"v": int(read_json(APP_DIR / "static" / "default-calendar.json", {}).get("v", 0) or 0),
            "calendar": read_json(APP_DIR / "static" / "default-calendar.json", {}),
            "exams": read_json(APP_DIR / "static" / "default-exams.json", {})}


def content_now():
    got, own = read_json(CONTENT_FILE, None), _bundled()
    return got if got and int(got.get("v", 0)) > own["v"] else own


def can_publish():
    return SIGN_KEY.exists() and (UPDATES_REPO / ".git").exists()


def check_content():
    """Newest published calendar + exams: GitHub (signed by your PC) or the class board (your admin key, from any device)."""
    best = None
    try:
        import ed25519
        got = json.loads(_fetch(UPDATE_BASE + "content.json?t=" + str(int(time.time())), 2_000_000))
        data, sig = got["data"], bytes.fromhex(got["sig"])
        if not ed25519.verify(bytes.fromhex(UPDATE_KEY), _canon(data), sig):
            raise ValueError("calendar update failed the signature check, ignored")
        best = data
        content_state.update(error=None)
    except urllib.error.HTTPError as e:
        content_state.update(error=None if e.code == 404 else str(e)[:200])   # nothing published yet
    except Exception as e:  # noqa: BLE001
        content_state["error"] = str(e)[:200]
    try:   # published from your phone (only your admin key can write it)
        b = board_call(action="getContent", since=int(content_now().get("v", 0)))
        if b.get("data") and int(b["data"].get("v", 0)) > int((best or {}).get("v", 0)):
            best = b["data"]
    except Exception:  # noqa: BLE001
        pass
    if best and int(best.get("v", 0)) > int(content_now().get("v", 0)):
        write_json(CONTENT_FILE, best)
    content_state["checked"] = datetime.now().isoformat(timespec="minutes")


def content_loop():
    time.sleep(15)
    while True:
        if "OWNER/" not in UPDATE_BASE:
            check_content()
        time.sleep(30 * 60)


@app.get("/default-calendar.json")
def default_calendar():
    resp = jsonify(content_now()["calendar"])
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/default-exams.json")
def default_exams():
    resp = jsonify(content_now()["exams"])
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/api/content")
def get_content_version():
    return jsonify({"v": int(content_now().get("v", 0)), **content_state})


DRAFT_FILE = DATA / "admin-draft.json"   # edits on a phone, until you publish


def admin_ok():
    """You, the admin: My App on your PC (signing key + GitHub) or your phone with the admin key."""
    return is_local() and (can_publish() or bool(board_cfg().get("admin")))


def admin_source():
    d = read_json(DRAFT_FILE, None)
    return d if d and not can_publish() else content_now()


@app.get("/api/admin/content")
def admin_content():
    return jsonify({**admin_source(), "canPublish": admin_ok(), "pc": can_publish()})


@app.put("/api/admin/content")
def admin_save():
    """Save your edits (on the PC into the app's files; on your phone as a draft) - not published yet."""
    if not admin_ok():
        return jsonify(error="Only the admin can change everyone's calendar. Add your admin key in Admin → CRs."), 403
    b = request.get_json(force=True)
    c = admin_source()
    cal, ex = {**c["calendar"], "events": b["calendar"]["events"]}, {**c["exams"], "exams": b["exams"]["exams"]}
    for k in ("name",):
        if b["calendar"].get(k): cal[k] = b["calendar"][k]
        if b["exams"].get(k): ex[k] = b["exams"][k]
    if can_publish():
        write_json(APP_DIR / "static" / "default-calendar.json", cal)
        write_json(APP_DIR / "static" / "default-exams.json", ex)
    else:
        write_json(DRAFT_FILE, {"v": c.get("v", 0), "calendar": cal, "exams": ex})
    return jsonify(ok=True, draft=True)


@app.post("/api/admin/publish")
def admin_publish():
    """Every phone shows the saved calendar + exams within minutes. From your PC: signed, to GitHub and the class board.
    From your phone: to the class board (your admin key)."""
    if not admin_ok():
        return jsonify(error="Only the admin can publish. Add your admin key in Admin → CRs."), 403
    v = int(time.time())
    src = admin_source()
    cal, ex = {**src["calendar"], "v": v}, {**src["exams"], "v": v}
    data = {"v": v, "calendar": cal, "exams": ex}
    where = []
    if can_publish():
        import ed25519
        write_json(APP_DIR / "static" / "default-calendar.json", cal)   # the next app update carries them too
        write_json(APP_DIR / "static" / "default-exams.json", ex)
        sig = ed25519.sign(bytes.fromhex(SIGN_KEY.read_text().strip()), _canon(data))
        (UPDATES_REPO / "content.json").write_text(json.dumps({"data": data, "sig": sig.hex()}, ensure_ascii=False), encoding="utf-8")
        git = ["git", "-C", str(UPDATES_REPO)]
        try:
            subprocess.run(git + ["add", "content.json"], check=True, capture_output=True, timeout=60)
            subprocess.run(git + ["commit", "-q", "-m", f"Calendar & exams {datetime.now():%d %b %H:%M}"], check=True, capture_output=True, timeout=60)
            r = subprocess.run(git + ["push", "-q", "origin", "main"], capture_output=True, timeout=180, text=True)
            if not r.returncode:
                where.append("GitHub")
        except subprocess.CalledProcessError:
            pass
    if board_cfg().get("admin"):
        try:
            r = board_call(action="setContent", data=data)
            if r.get("ok"):
                where.append("class board")
        except Exception:  # noqa: BLE001
            pass
    if not where:
        return jsonify(error="Couldn't publish (no internet?). Your changes are saved; try again."), 502
    write_json(CONTENT_FILE, data)
    if DRAFT_FILE.exists():
        DRAFT_FILE.unlink()
    return jsonify(ok=True, v=v, events=len(cal.get("events", [])), exams=len(ex.get("exams", [])), where=where)


# ---------------------------------------------------------------- class board: CR posts + class chat
# Lives in the developer's Google Sheet (Apps Script). The link alone opens nothing: every request carries this phone's
# class token, a CR code or the admin key, and the script checks it (CRs: own class, own posts; classmates: own class).
BOARD_URL = "https://script.google.com/macros/s/AKfycbwpFFyh74J2z7e67Vrtm4J8ADByTwYn-428RTXBlsqxpXDjwz8k3i5OUSHneHLbQ27M/exec"
BOARD_FILE = DATA / "class-board.json"
BOARD_ADMIN_FILE = ROOT / "android-tools" / "board-admin-key.txt"   # only on your PC
board_state = {"checked": None, "error": None, "busy": False}
_board_lock = threading.Lock()


def board_cfg():
    c = read_json(BOARD_FILE, {})
    if not c.get("admin") and BOARD_ADMIN_FILE.exists():
        c["admin"] = BOARD_ADMIN_FILE.read_text().strip()
    return c


def _branch(b):
    x = re.sub(r"[^A-Z]", "", str(b or "").upper())
    return "AIDS" if x in ("AID", "AIDS", "AIANDDS") else x


def my_class():
    pr = (read_json(DATA / "planner.json", {}) or {}).get("profile", {})
    if not (pr.get("batch") and pr.get("branch") and pr.get("section")):
        return ""
    return f"{pr['batch']}-{_branch(pr['branch'])}-{str(pr['section']).strip().upper()}"


def board_call(**b):
    c = board_cfg()
    for k in ("token", "cr", "admin"):
        if c.get(k) and k not in b:
            b[k] = c[k]
    req = urllib.request.Request(BOARD_URL, data=json.dumps(b).encode(), headers={"Content-Type": "text/plain", "User-Agent": "MyApp"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read(3_000_000))


def board_view():
    c = board_cfg()
    posts = sorted((x for x in c.get("posts", {}).values() if not x.get("deleted")), key=lambda x: -float(x.get("created") or 0))
    chat = sorted(c.get("chat", {}).values(), key=lambda x: float(x.get("created") or 0))[-300:]
    return {"class": c.get("class") or my_class(), "joined": bool(c.get("token")), "cr": c.get("crInfo"), "admin": bool(c.get("admin")),
            "posts": posts, "chat": chat, "crs": c.get("crs", []), **board_state}


def board_sync(notify_new=True):
    """Fetch new posts + chat for this phone's class; notify about new CR posts."""
    if not _board_lock.acquire(blocking=False):
        return board_view()
    board_state["busy"] = True
    try:
        c = read_json(BOARD_FILE, {})
        pr = (read_json(DATA / "planner.json", {}) or {}).get("profile", {})
        klass = (c.get("crInfo") or {}).get("class") or my_class()
        if not klass:
            board_state.update(error="Fill in your batch, branch and section in Profile first.")
            return board_view()
        # every classmate links their phone to their class once (one phone per roll number)
        is_admin = bool(board_cfg().get("admin"))   # the admin reads every class with the key: no member link needed
        if not c.get("token") and not c.get("cr") and not is_admin and pr.get("roll") and pr.get("name"):
            j = board_call(action="join", **{"class": klass}, roll=pr["roll"], name=pr["name"])
            if j.get("token"):
                c.update(token=j["token"], **{"class": klass}); write_json(BOARD_FILE, c)
            else:
                board_state.update(error=j.get("error")); return board_view()
        if c.get("class") and c["class"] != klass and not c.get("cr"):   # section changed: start fresh for the new class
            c = {"token": c.get("token")}
        if EDITION == "cr" and c.get("token") and not c.get("cr"):   # CR's Portal: did the admin make this roll number a CR?
            w = board_call(action="who")
            if w.get("cr") and w["cr"] != c.get("crInfo"):
                c["crInfo"] = w["cr"]; write_json(BOARD_FILE, c)
            elif not w.get("cr") and c.get("crInfo"):
                c.pop("crInfo", None); write_json(BOARD_FILE, c)
        f = board_call(action="feed", **{"class": klass}, since=c.get("since", 0))
        if f.get("error"):
            board_state.update(error=f["error"]); return board_view()
        posts, chat, seen = c.get("posts", {}), c.get("chat", {}), float(c.get("seen", 0) or 0)
        new = []
        for x in f.get("posts", []):
            own = x.get("by") == "Admin" if is_admin else bool(c.get("crInfo")) and x.get("by") == c["crInfo"]["name"] + " (CR)"
            if x["id"] not in posts and not x.get("deleted") and not own and float(x.get("created") or 0) > seen:   # the admin hears every CR too
                new.append(x)
            posts[x["id"]] = x
        for x in f.get("chat", []):
            chat[x["id"]] = x
        c.update(posts=posts, chat=chat, crs=f.get("crs", []), since=f.get("now", c.get("since", 0)), seen=f.get("now", seen), **{"class": klass})
        write_json(BOARD_FILE, c)
        if notify_new and new and seen:   # the very first sync only fills the list
            label = {"announcement": "📢", "test": "📝 Test", "timetable": "🕒 Timetable", "deadline": "📌 Due"}
            notify(f"{len(new)} new from your CR" if len(new) > 1 else f"{label.get(new[0]['kind'], '📢')} {new[0]['title']}",
                   [f"{label.get(x['kind'], '')} {x['title']}" + (f" · {x['date']}" if x.get("date") else "") for x in new[:4]])
        board_state.update(checked=datetime.now().isoformat(timespec="minutes"), error=None)
    except Exception as e:  # noqa: BLE001
        board_state["error"] = str(e)[:200]
    finally:
        board_state["busy"] = False
        _board_lock.release()
    return board_view()


def board_loop():
    time.sleep(45)
    while True:
        if my_class() or board_cfg().get("cr"):
            board_sync()
        h = datetime.now().hour
        time.sleep(5 * 60 if 7 <= h <= 22 else 30 * 60)


@app.get("/api/class")
def get_class():
    return jsonify(board_view())


@app.post("/api/class/sync")
def post_class_sync():
    return jsonify(board_sync(notify_new=False))


def _board_write(action, **extra):
    b = request.get_json(force=True) or {}
    keep = {k: b[k] for k in ("id", "kind", "title", "body", "date", "time", "end", "course", "text", "class") if k in b}
    r = board_call(action=action, **keep, **extra)
    if r.get("error"):
        return jsonify(r), 400
    return jsonify({**board_sync(notify_new=False), "result": r})


@app.post("/api/class/post")
def class_post():
    return _board_write("post")


@app.post("/api/class/edit")
def class_edit():
    return _board_write("edit")


@app.post("/api/class/del")
def class_del():
    return _board_write("del")


@app.post("/api/class/chat")
def class_chat():
    return _board_write("chat")


@app.post("/api/class/hide")
def class_hide():
    return _board_write("hide")


@app.post("/api/class/cr")
def class_cr():
    """CR's Portal: the CR types the code the admin gave them."""
    code = str((request.get_json(force=True) or {}).get("code", "")).strip().upper()
    if not code:
        c = read_json(BOARD_FILE, {}); c.pop("cr", None); c.pop("crInfo", None); write_json(BOARD_FILE, c)
        return jsonify(board_view())
    r = board_call(action="who", cr=code)
    if not r.get("cr"):
        return jsonify(error="That CR code isn't valid (or was switched off by the admin)."), 400
    c = read_json(BOARD_FILE, {}); c.update(cr=code, crInfo=r["cr"], since=0, posts={}, chat={}); write_json(BOARD_FILE, c)
    return jsonify(board_sync(notify_new=False))


@app.get("/api/class/adminkey")
def class_admin_key():
    """Your PC only: the admin key, to type into your phone once (Admin → CRs)."""
    if not (is_local() and BOARD_ADMIN_FILE.exists()):
        return jsonify(error="Only on your PC."), 403
    return jsonify(key=BOARD_ADMIN_FILE.read_text().strip())


@app.post("/api/class/admin")
def class_admin():
    """Admin only (your PC, or your phone after you paste the admin key): CR codes, resets, any class."""
    b = request.get_json(force=True) or {}
    if b.get("setKey") is not None:
        c = read_json(BOARD_FILE, {}); c["admin"] = str(b["setKey"]).strip(); write_json(BOARD_FILE, c)
        return jsonify(board_call(action="who"))
    if not board_cfg().get("admin"):
        return jsonify(error="Admin key not set on this device."), 403
    act = b.get("action")
    if act not in ("crCreate", "crList", "crActive", "memberReset", "classes", "feed", "post", "del", "hide"):
        return jsonify(error="unknown action"), 400
    keep = {k: v for k, v in b.items() if k != "action"}
    return jsonify(board_call(action=act, **keep))


# ---------------------------------------------------------------- home-screen widget: today's classes
# Same as the Today page: classes of the day (or the next class day), attendance % per subject, and the alarm bell.
# Written to data/widget.json (the Android widget reads it even when the app isn't running) and refreshed often.
WIDGET_FILE = DATA / "widget.json"


def _nrm(x):
    return re.sub(r"[^a-z0-9]", "", str(x or "").lower())


def _class_weight(sl):
    if not sl.get("lab"):
        return 1
    return 3 if re.search(r"mathematics for computing|^mfc$", f"{sl.get('name', '')}|{sl.get('short', '')}", re.I) else 2


def _att_row(sl, tt, rows):
    r = next((x for x in rows if _nrm(x.get("course")) == _nrm(sl.get("name"))), None)
    sub = next((x for x in tt.get("subjects", []) if x.get("name") == sl.get("name")), None)
    if not r and sub:
        r = next((x for x in rows if x.get("code") == sub.get("code") or (x.get("code") and x["code"][2:] == str(sub.get("code", ""))[2:])), None)
    el = [_nrm(e) for e in tt.get("electives", []) if re.search(r"[a-z]{3}", e, re.I)]
    if not r and _nrm(sl.get("name")) in el:
        r = next((x for x in rows if _nrm(x.get("course")) in el), None)
    return r


def _holiday_on(day, events):
    return next((e for e in events if e.get("type") == "holiday" and e.get("start", "") <= day <= (e.get("end") or e.get("start", ""))), None)


def widget_data():
    tt = read_json(DATA / "timetable.json", None)
    plan = read_json(DATA / "planner.json", {}) or {}
    mirror = read_json(DATA / "portal-mirror.json", {}) or {}
    rows = (mirror.get("attendance") or {}).get("rows", [])
    events = list(content_now().get("calendar", {}).get("events", [])) + list(plan.get("events", []))
    cfg = portal_cfg()
    bells, lead, all_on = plan.get("alarmSubs") or {}, int(cfg.get("classLead") or 5), bool(cfg.get("classAlarm"))
    minimum = float((plan.get("att") or {}).get("min") or 75)
    out = {"made": datetime.now().isoformat(timespec="minutes"), "classes": [], "note": "", "title": "Today"}
    if not tt or not tt.get("days"):
        out["note"] = "Open the app and add your class timetable."
        return out
    today = date.today()
    day, slots, note = today, [], ""
    for i in range(15):
        d = today + timedelta(days=i)
        ds, dow = d.isoformat(), d.strftime("%a")
        hol = _holiday_on(ds, events)
        if i == 0 and hol:
            note = "Holiday today" + (f" · {hol['title']}" if not hol.get("weekly") and hol.get("title") not in (None, "", "Holiday") else "")
        if hol or not tt["days"].get(dow):
            if i == 0 and not note:
                note = "No classes today"
            continue
        day, slots = d, tt["days"][dow]
        break
    out["title"] = day.strftime("%A") if day == today else f"Next · {day.strftime('%A %d %b')}"
    out["note"], out["date"], out["isToday"] = note, day.isoformat(), day == today
    period = 1
    for sl in sorted(slots, key=lambda x: x.get("start", "")):
        w = _class_weight(sl)
        r = _att_row(sl, tt, rows)
        att = if_p = if_b = None
        status = ""
        if r and r.get("total"):
            got, tot = r.get("present", 0) + r.get("dl", 0) + r.get("medical", 0), r["total"]
            att = round(got / tot * 100, 1)
            if_p, if_b = round((got + w) / (tot + w) * 100, 1), round(got / (tot + w) * 100, 1)   # same as the Today page
            status = "Don't bunk" if if_b < minimum else "Risky" if if_b < minimum + 2 else "Safe to bunk"
        v = bells.get(sl.get("short"))
        mins = lead if v is True else int(v or 0)
        out["classes"].append({
            "short": sl.get("short", ""), "name": sl.get("name", ""), "start": sl.get("start", ""), "end": sl.get("end", ""),
            "lab": bool(sl.get("lab")), "periods": f"Period {period}" + (f" → {period + w - 1}" if w > 1 else ""),
            "att": att, "low": att is not None and att < minimum, "bell": mins, "bellOn": bool(mins or all_on),
            "ifPresent": if_p, "ifBunk": if_b, "status": status})
        period += w
    return out


def write_widget():
    try:
        d = widget_data()
        old = read_json(WIDGET_FILE, {})
        if {k: v for k, v in old.items() if k != "made"} != {k: v for k, v in d.items() if k != "made"}:
            write_json(WIDGET_FILE, d)
            if IS_ANDROID and os.environ.get("MYAPP_STANDALONE"):
                try:
                    from java import jclass
                    jclass("app.myapp.amrita.TodayWidget").refreshAll()
                except Exception:  # noqa: BLE001 - an older app without the widget
                    pass
        return d
    except Exception as e:  # noqa: BLE001
        return {"error": str(e)[:200]}


def widget_loop():
    time.sleep(5)
    while True:
        write_widget()
        time.sleep(10 * 60)


@app.get("/api/widget")
def get_widget():
    return jsonify(write_widget())


@app.post("/api/widget/bell")
def widget_bell():
    """Bell on the widget: alarm for that subject on/off (the default 'minutes before' from Settings)."""
    short = str((request.get_json(force=True) or {}).get("short", "")).strip()
    plan = read_json(DATA / "planner.json", {}) or {}
    bells = plan.get("alarmSubs") or {}
    if bells.get(short):
        bells.pop(short, None)
    elif short:
        bells[short] = True
    plan["alarmSubs"] = bells
    write_json(DATA / "planner.json", plan)
    return jsonify(write_widget())


# ---------------------------------------------------------------- small app updates (no 22 MB APK)
# The app's own code (server.py, agent.py, static/) is ~0.5 MB. A signed update pack replaces just that;
# hubmain.py runs the newest one at the next start. A new APK is only needed when the Android part changes (minApk).
UPDATE_BASE = "https://raw.githubusercontent.com/mallikarjunreddy8/myapp-updates/main/"   # set by android/make_update.py
UPDATE_KEY = "867b77390a18417b0db2e171d0c1c5cd9b3b1e2683a1bb0d3c48a72e4ca90783"   # public half; the private key never leaves your PC
UPDATE_DIR = ROOT / "code-update"
update_state = {"checked": None, "available": None, "ready": None, "notes": "", "size": 0, "apk": None, "error": None, "busy": False}


def code_version():
    return int(read_json(APP_DIR / "static" / "code-version.json", {}).get("v", 0))


def _fetch(url, limit):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "MyApp-updater", "Cache-Control": "no-cache"}), timeout=30) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("download too big")
    return data


def check_update():
    if "OWNER/" in UPDATE_BASE or update_state["busy"]:
        return
    update_state["busy"] = True
    try:
        import ed25519, hashlib
        m = json.loads(_fetch(UPDATE_BASE + "manifest.json?t=" + str(int(time.time())), 64_000))
        update_state.update(checked=datetime.now().isoformat(timespec="minutes"), error=None)
        v, cur = int(m["v"]), code_version()
        have = int(read_json(UPDATE_DIR / "static" / "code-version.json", {}).get("v", 0))
        apk_ver = int(os.environ.get("MYAPP_APK_VER", "0") or 0)
        if v <= cur:
            update_state.update(available=None, ready=None, apk=None)
            return
        update_state.update(available=v, notes=m.get("notes", ""), size=m.get("size", 0))
        if apk_ver and int(m.get("minApk", 0)) > apk_ver:   # this one changes the Android part: needs the full APK
            # your own edition gets its APK from your private repo; CRs get theirs
            update_state["apk"] = m.get({"personal": "apkPersonal", "cr": "apkCR"}.get(EDITION, "apk")) or m.get("apk") or None
            return
        if have >= v:
            update_state["ready"] = have
            return
        blob = _fetch(UPDATE_BASE + m["zip"], 8_000_000)
        digest = hashlib.sha256(blob).hexdigest()
        if digest != m["sha256"] or not ed25519.verify(bytes.fromhex(UPDATE_KEY), f"myapp-update:{v}:{digest}".encode(), bytes.fromhex(m["sig"])):
            raise ValueError("update pack failed the signature check, not installed")
        tmp = ROOT / "code-update.tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            for n in z.namelist():
                if n.startswith(("/", "\\")) or ".." in n.split("/"):
                    raise ValueError("bad path in update pack")
            z.extractall(tmp)
        if int(read_json(tmp / "static" / "code-version.json", {}).get("v", 0)) != v or not (tmp / "server.py").exists():
            raise ValueError("update pack is incomplete")
        shutil.rmtree(UPDATE_DIR, ignore_errors=True)
        tmp.rename(UPDATE_DIR)
        update_state["ready"] = v
    except Exception as e:
        update_state["error"] = str(e)[:200]
    finally:
        update_state["busy"] = False


def update_loop():
    time.sleep(180)   # well after opening, so the check never slows the start
    while True:
        check_update()
        time.sleep(6 * 3600)


@app.get("/api/update")
def get_update():
    return jsonify({**update_state, "current": code_version(), "enabled": "OWNER/" not in UPDATE_BASE})


@app.post("/api/update/check")
def post_update_check():
    check_update()
    return get_update()


def main():
    if os.environ.get("MYAPP_STANDALONE"):
        threading.Thread(target=update_loop, daemon=True).start()
    threading.Thread(target=content_loop, daemon=True).start()   # calendar + exams you publish
    threading.Thread(target=board_loop, daemon=True).start()     # CR posts + class chat
    threading.Thread(target=widget_loop, daemon=True).start()    # home-screen widget
    if EDITION == "personal":   # your own edition only
        threading.Thread(target=installs_loop, daemon=True).start()
    threading.Thread(target=background_loop, daemon=True).start()
    threading.Thread(target=class_alert_loop, daemon=True).start()
    if "--background" not in sys.argv and "--no-browser" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(URL)).start()
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
