/* Calendar importer: academic calendar PDFs, exam timetable PDFs and WhatsApp chat exports
   → dated events (exams, holidays, deadlines, events) filtered for the student's section and courses. */
"use strict";
const Cal = (() => {
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  const pad = n => String(n).padStart(2, "0");
  const ymd = (y, m, d) => (m >= 1 && m <= 12 && d >= 1 && d <= 31 && y > 2000 && y < 2100) ? `${y}-${pad(m)}-${pad(d)}` : null;
  const fixY = y => (y = +y) < 100 ? 2000 + y : y;
  const DAYNAME = /\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?\b/gi;
  // one regex for every date style we accept; named groups say which style matched
  const DATE = /(?<d1>\d{1,2})[.\/-](?<m1>\d{1,2})[.\/-](?<y1>\d{2,4})|(?<y2>20\d{2})[.\/-](?<m2>\d{1,2})[.\/-](?<d2>\d{1,2})|(?<d3>\d{1,2})(?:st|nd|rd|th)?[\s\-]*(?<mn3>jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?[,\s\-]*(?<y3>\d{2,4})?|(?<mn4>jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?\s+(?<d4>\d{1,2})(?:st|nd|rd|th)?,?\s*(?<y4>\d{4})?/gi;
  function findDates(text, yearHint) {
    const out = [];
    for (const m of text.matchAll(DATE)) {
      const g = m.groups; let v = null;
      if (g.d1) v = ymd(fixY(g.y1), +g.m1, +g.d1);
      else if (g.y2) v = ymd(+g.y2, +g.m2, +g.d2);
      else if (g.d3) v = ymd(g.y3 ? fixY(g.y3) : yearHint(MON[g.mn3.toLowerCase().slice(0, 3)]), MON[g.mn3.toLowerCase().slice(0, 3)], +g.d3);
      else if (g.mn4) v = ymd(g.y4 ? +g.y4 : yearHint(MON[g.mn4.toLowerCase().slice(0, 3)]), MON[g.mn4.toLowerCase().slice(0, 3)], +g.d4);
      if (v) out.push({ v, i: m.index, len: m[0].length, raw: m[0] });
    }
    return out;
  }
  // "Nov" without a year → the academic year that contains today (Jul–Jun)
  function academicYearHint(today = new Date()) {
    const startY = today.getMonth() >= 6 ? today.getFullYear() : today.getFullYear() - 1;
    return m => (m >= 7 ? startY : startY + 1);
  }
  const TYPES = [
    ["exam", /\b(exams?|examinations?|tests?|mid[\s-]*terms?|end[\s-]*sem\w*|periodicals?|quiz\w*|viva|practicals?|lab exams?|assessments?|ESE|CAT)\b/i],
    ["holiday", /\b(holiday|vacation|break|recess|deepavali|diwali|pongal|onam|christmas|ganesh|ganapathi|dussehra|ayudha|navarathri|vijaya|republic day|independence day|gandhi|ugadi|ramzan|bakrid|good friday|new year|holi)\b/i],
    ["deadline", /\b(last date|deadline|submission|submit|registration|fee|due|apply|application)\b/i],
  ];
  const classify = t => (TYPES.find(([, re]) => re.test(t)) || ["event"])[0];
  const cleanTitle = (t, dates) => {
    let s = t;
    [...dates].sort((a, b) => b.i - a.i).forEach(d => s = s.slice(0, d.i) + " " + s.slice(d.i + d.len));
    return s.replace(DAYNAME, " ").replace(/\b(to|till|upto|from|on|and)\b\s*$/i, "").replace(/^\s*(\d+[.)]|s\.?\s*no\.?|\d{1,3}(?=\s+[A-Za-z]))\s*/i, "").replace(/\b(FN|AN|F\.N\.|A\.N\.)\b/g, " ").replace(/[\s|,:;\-–—()]+$/g, "").replace(/^[\s|,:;\-–—()]+/, "").replace(/\s{2,}/g, " ").trim();
  };
  const SESS = s => /\bF\.?N\.?\b|forenoon|morning/i.test(s) ? "09:30" : /\bA\.?N\.?\b|afternoon/i.test(s) ? "14:00" : ((s.match(/(\d{1,2})[:.](\d{2})\s*(am|pm)?/i) || []).length ? (m => { let h = +m[1]; if (/pm/i.test(m[3] || "") && h < 12) h += 12; return `${pad(h)}:${m[2]}`; })(s.match(/(\d{1,2})[:.](\d{2})\s*(am|pm)?/i)) : "");

  /* relevance for this student: their course codes/names, their branch and section */
  function relevance(text, me) {
    const t = text.toUpperCase();
    const mine = (me.branch || "AIE").toUpperCase();
    // "for UG-S3,S5, S7 and PG S3" / "for UG-S1 and PG S1": keep only lines for the student's semester
    const sems = [...t.matchAll(/(?:^|[^A-Z0-9])S(\d{1,2})(?!\d)/g)].map(m => +m[1]);
    if (sems.length && me.semNo) return sems.includes(me.semNo) ? { score: 2, why: `for S${me.semNo}` } : { score: -2, why: `for S${[...new Set(sems)].join(", S")} only` };
    // who the row is for beats what course it is: a shared course code can be another section's exam
    const secs = [];   // "AIE-D", "AIE A-D", "AIE A, B & D", "AIE A to D"
    for (const m of t.matchAll(new RegExp(`\\b${mine}\\s*[-–]?\\s*([A-H](?:\\s*(?:[-–,&/]|TO|AND)\\s*[A-H])*)\\b`, "g"))) {
      m[1].replace(/\s+/g, "").replace(/([A-H])(?:[-–]|TO)([A-H])/g, (_, a, b) => { for (let c = a.charCodeAt(0); c <= b.charCodeAt(0); c++) secs.push(String.fromCharCode(c)); return ""; })
        .split(/[,&/]|AND/).forEach(x => /^[A-H]$/.test(x) && secs.push(x));
    }
    if (secs.length && !secs.includes((me.section || "").toUpperCase())) return { score: -2, why: `other section (${mine}-${secs.join(",")})` };
    const branches = (t.match(/\b(AIE|CSE|ECE|EEE|EAC|ELC|MEE|MECH|CIVIL|CHE|ARE|AID|CYS|RAI|BBA|MBA|MCA|BCA)\b/g) || []);
    if (branches.length && !branches.includes(mine)) return { score: -2, why: "other branch" };
    const codes = me.codes || [];
    const rowCodes = t.match(/\b\d{2}[A-Z]{2,5}\d{3}\b/g) || [];   // a course code that isn't one of this semester's courses
    if (rowCodes.length && codes.length && !rowCodes.some(c => codes.includes(c))) return { score: -1, why: "not one of your current courses" };
    if (codes.some(c => c && t.includes(c.toUpperCase()))) return { score: 3, why: secs.length ? `your course, ${mine}-${me.section}` : "your course" };
    if ((me.names || []).some(n => n && n.length > 6 && t.includes(n.toUpperCase()))) return { score: 3, why: "your course" };
    if (secs.length) return { score: 3, why: `${mine}-${me.section}` };
    if (branches.includes(mine)) return { score: 2, why: mine };
    return { score: 1, why: "everyone" };
  }

  /* PDF / pasted lines → events (free engine) */
  function fromLines(lines, me, kind) {
    const hint = academicYearHint();
    const rows = []; const texts = lines.map(l => l.t ?? l);
    texts.forEach((line, i) => {
      const dates = findDates(line, hint);
      if (!dates.length) return;
      let title = cleanTitle(line, dates);
      // a date-only row in a table: the description is usually on the line before/after
      if (title.replace(/[^a-z]/gi, "").length < 4) title = cleanTitle([texts[i - 1], texts[i + 1]].filter(x => x && !findDates(x, hint).length).join(" "), []) || title;
      if (title.replace(/[^a-z]/gi, "").length < 3) return;
      const isRange = dates.length >= 2 && /\b(to|till|upto|-|–)\b|\s[-–]\s/i.test(line.slice(dates[0].i + dates[0].len, dates[1].i + 1));
      const start = dates[0].v, end = isRange && dates[1].v >= start ? dates[1].v : start;
      const type = kind === "timetable" ? "exam" : classify(title + " " + line);
      // judge the row itself; borrow the previous line only when the row says nothing about who it's for
      let rel = relevance(line, me);
      if (rel.score === 1 && texts[i - 1] && !findDates(texts[i - 1], hint).length) rel = relevance(line + " " + texts[i - 1], me);
      if (kind === "timetable" && !/\b\d{2}[A-Z]{2,5}\d{3}\b|\b(FN|AN)\b|\d{1,2}[:.]\d{2}\s*(am|pm)/i.test(line)) return;   // a heading, not an exam row
      const code = (line.match(/\b\d{2}[A-Z]{2,5}\d{3}\b/) || [])[0], ci = code ? (me.codes || []).indexOf(code) : -1;
      if (ci >= 0 && me.names[ci]) title = `${me.names[ci]} (${code})`;
      const noDates = dates.reduce((s, d) => s.replace(d.raw, " "), line);
      rows.push({ id: "e" + Math.random().toString(36).slice(2, 9), title: title.slice(0, 140), type, start, end, time: type === "exam" ? SESS(noDates) : "", rel: rel.score, why: rel.why, src: line.slice(0, 200) });
      // exam timetables often list several exams per line ("03.11 22AIE204 / 04.11 22AIE205")
      if (!isRange && dates.length > 1 && kind === "timetable") dates.slice(1).forEach(d => rows.push({ ...rows[rows.length - 1], id: "e" + Math.random().toString(36).slice(2, 9), start: d.v, end: d.v }));
    });
    return dedupe(rows);
  }
  function dedupe(rows) {
    const seen = new Map();
    rows.forEach(r => { const k = r.start + "|" + r.title.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 30); if (!seen.has(k) || seen.get(k).rel < r.rel) seen.set(k, r); });
    return [...seen.values()].sort((a, b) => a.start.localeCompare(b.start));
  }

  /* WhatsApp "Export chat" .txt → messages → events */
  const WA = /^\[?(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4}),?\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*([ap]\.?\s?m\.?)?\]?\s*(?:-\s*)?([^:]{1,60}):\s([\s\S]*)$/i;
  function parseWhatsApp(text) {
    const msgs = [];
    text.split(/\r?\n/).forEach(line => {
      const m = line.replace(/[‎‏]/g, "").match(WA);
      if (m) { const [, a, b, y] = m; const mdy = +b > 12 && +a <= 12;   // Indian phones export DD/MM/YY; US style only when it can't be DD/MM
        msgs.push({ date: ymd(fixY(y), +(mdy ? a : b), +(mdy ? b : a)), who: m[7].trim(), text: m[8] }); }
      else if (msgs.length) msgs[msgs.length - 1].text += "\n" + line;
    });
    return msgs.filter(m => m.date && !/<media omitted>|this message was deleted/i.test(m.text));
  }
  const WD = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  function fromWhatsApp(text, me, days = 90) {
    const msgs = parseWhatsApp(text), since = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10), out = [];
    const KEY = /\b(exam|test|quiz|mid|end sem|viva|lab|assignment|submission|submit|deadline|due|holiday|leave|cancel+ed|postponed|rescheduled|class|seminar|workshop|fee|register|registration|project|record|review|presentation)\b/i;
    msgs.filter(m => m.date >= since && KEY.test(m.text)).forEach(m => {
      const base = new Date(m.date + "T12:00");
      const hint = mm => (mm < base.getMonth() + 1 - 6 ? base.getFullYear() + 1 : base.getFullYear());
      let dates = findDates(m.text, hint).map(d => d.v);
      if (/\btomorrow\b|\btmrw\b|\btmr\b/i.test(m.text)) dates.push(new Date(+base + 864e5).toISOString().slice(0, 10));
      if (/\btoday\b|\btonight\b/i.test(m.text)) dates.push(m.date);
      const wd = m.text.match(/\b(?:on|this|next|by)\s+(sun|mon|tue|wed|thu|fri|sat)[a-z]*/i);
      if (wd) { const t = WD[wd[1].toLowerCase()]; const d = new Date(base); d.setDate(d.getDate() + ((t - d.getDay() + 7) % 7 || 7)); dates.push(d.toISOString().slice(0, 10)); }
      dates = [...new Set(dates)].filter(d => d >= m.date);
      if (!dates.length) return;
      const firstLine = m.text.split("\n").find(l => KEY.test(l)) || m.text.split("\n")[0];
      const rel = relevance(m.text, me);
      dates.slice(0, 2).forEach(d => out.push({ id: "w" + Math.random().toString(36).slice(2, 9), title: firstLine.replace(/\s+/g, " ").slice(0, 120), type: classify(m.text), start: d, end: d, time: SESS(m.text), rel: rel.score < 0 ? rel.score : Math.max(1, rel.score), why: rel.score < 0 ? rel.why : `WhatsApp · ${m.who}, ${m.date}`, src: m.text.slice(0, 300) }));
    });
    return dedupe(out);
  }

  const AI_PROMPT = (text, me, kind) => `You read a college ${kind === "timetable" ? "exam timetable" : kind === "whatsapp" ? "class WhatsApp chat" : "academic calendar"} for a B.Tech student.
Student: branch ${me.branch || "AIE"}, section ${me.section || "?"}, batch ${me.batch || "?"}, roll ${me.roll || "?"}. Their courses: ${(me.codes || []).map((c, i) => c + " " + ((me.names || [])[i] || "")).join("; ")}.
List every dated item that applies to this student (their courses, their branch/section, or everyone). Skip items only for other branches/sections.
Reply with ONLY JSON: {"events":[{"title":"short title","type":"exam|holiday|deadline|event","start":"YYYY-MM-DD","end":"YYYY-MM-DD","time":"HH:MM or empty","course":"course code if any"}]}
Dates in India are DD-MM-YYYY. Academic year runs July to June.
<document>
${text.slice(0, 9000)}
</document>`;
  function fromAi(j, me) {
    return (j.events || []).filter(e => /^\d{4}-\d{2}-\d{2}$/.test(e.start || "")).map(e => {
      const rel = relevance((e.title || "") + " " + (e.course || ""), me);
      return { id: "a" + Math.random().toString(36).slice(2, 9), title: String(e.title || "").slice(0, 140), type: ["exam", "holiday", "deadline", "event"].includes(e.type) ? e.type : classify(e.title || ""),
        start: e.start, end: /^\d{4}-\d{2}-\d{2}$/.test(e.end || "") && e.end >= e.start ? e.end : e.start, time: /^\d{2}:\d{2}$/.test(e.time || "") ? e.time : "", rel: rel.score < 0 ? rel.score : Math.max(1, rel.score), why: rel.score < 0 ? rel.why : "found by AI", src: "" };
    });
  }

  /* "one row per day" calendars (Amrita's academic calendar): "05-Jul Sun H", descriptions on their own lines,
     placed next to the row they belong to; the year comes from the month heading ("July - 2026") */
  const DAYROW = /^(\d{1,2})[-\s.](jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?\s+(mon|tue|wed|thu|fri|sat|sun)[a-z]*\b(.*)$/i;
  const MONTHHEAD = /\b(january|february|march|april|may|june|july|august|september|october|november|december)\s*[-–]?\s*(20\d{2})\b/i;
  const NOISE = /^(st|nd|rd|th|ug-?|date days.*|&\s*pg-?s\d|ug-\s*s1|amrita school.*|academic calendar.*|[1-5]\s*(st|nd|rd|th)?\s*sat)$/i;
  const HEADER = /^(date|days|date\s*days|s\d(\s*,\s*s\d)+|ug-?\s*s\d(\s*,\s*s\d)*|&?\s*pg-?\s*s\d|ug-?|branch\/?|doe,?\s*session)$/i;
  const isDayRowTable = lines => lines.filter(l => DAYROW.test(l.t)).length >= 20;
  function fromDayRows(lines, me) {
    const out = [], pages = [...new Set(lines.map(l => l.p))];
    for (const pg of pages) {
      const L = lines.filter(l => l.p === pg);
      const head = L.map(l => l.t.match(MONTHHEAD)).find(Boolean);
      const rows = [], blocks = [];
      L.forEach(l => {
        const m = l.t.match(DAYROW);
        if (m) { rows.push({ d: +m[1], mon: MON[m[2].toLowerCase().slice(0, 3)], dow: m[3].toLowerCase(), rest: m[4], y: l.y ?? 0, texts: [] }); return; }
        // each cell (column) of the line is its own text; wrapped lines of the same cell (same column, next line) join up
        (l.segs && l.segs.length ? l.segs : [{ t: l.t, x0: 0, x1: 0 }]).forEach(sg => {
          const t = sg.t.trim();
          if (!t || NOISE.test(t) || HEADER.test(t) || MONTHHEAD.test(t) && t.length < 25 || /^note:/i.test(t)) return;
          const y = l.y ?? 0, xc = (sg.x0 + (sg.x1 || sg.x0)) / 2;
          // a wrapped line continues the cell above it: same column (left edge or centre) and the sentence flows on
          const blk = blocks.find(b => Math.abs(b.yEnd - y) < 24 && (Math.abs(b.x0 - sg.x0) < 40 || Math.abs(b.xc - xc) < 40)
            && (/\b(for|and|of|the|to|in|on|with|or|by)$|[,\/&\-]$/i.test(b.text) || /^[a-z(\/&,]/.test(t) || /^(ug|pg)[-\s]?s\d/i.test(t)));
          if (blk) { blk.text += " " + t; blk.yEnd = y; blk.ys.push(y); }
          else blocks.push({ text: t, x0: sg.x0, xc, yEnd: y, ys: [y] });
        });
      });
      // a cell that wraps onto a date row: "…attendance shortage," / "18-Nov Wed 88 83 faculty feedback and …"
      rows.forEach(r => { const tail = r.rest.replace(/^[\sH\d]+/, "");
        if (!/^[a-z]/.test(tail)) return;
        const b = blocks.find(b => Math.abs(b.yEnd - r.y) < 24 && /\b(for|and|of|the|to|in|on|with|or|by)$|[,\/&\-]$/i.test(b.text));
        if (b) { b.text += " " + tail; r.rest = r.rest.slice(0, r.rest.length - tail.length); } });
      blocks.forEach(b => { const y = b.ys.reduce((a, v) => a + v, 0) / b.ys.length;   // a cell belongs to the row closest to its middle
        let best = null; rows.forEach(r => { if (!best || Math.abs(r.y - y) < Math.abs(best.y - y)) best = r; });
        if (best && Math.abs(best.y - y) < 60) best.texts.push(b.text.replace(/\s+/g, " ").trim()); });
      rows.forEach(r => {
        const year = head && MON[head[1].toLowerCase().slice(0, 3)] === r.mon ? +head[2] : academicYearHint()(r.mon);
        const date = ymd(year, r.mon, r.d); if (!date) return;
        const inline = r.rest.replace(/\bH\b/g, " ").replace(/\b\d{1,3}\b/g, " ").replace(/\b(st|nd|rd|th)\b/gi, " ").replace(/\bsat\b/gi, " ").replace(/\s+/g, " ").trim();
        const texts = [inline, ...r.texts].map(t => t.replace(/\b[1-5]\s*(st|nd|rd|th)?\s*sat\b/gi, " ").replace(/\s+/g, " ").trim())
          .filter(t => t && t.replace(/[^a-z]/gi, "").length > 2);
        const hol = /\bH\b/.test(r.rest) || texts.some(t => /holiday/i.test(t));
        if (hol) {
          const named = texts.find(t => /holiday/i.test(t) && t.replace(/holiday|[()\s\-]/gi, "").length > 2);
          const name = named ? named.replace(/\(\s*holiday\s*\)|-\s*holiday|\bholiday\b/gi, "").replace(/[()]/g, "").trim() : "";
          out.push({ id: "h" + Math.random().toString(36).slice(2, 9), title: name ? `${name} (holiday)` : "Holiday", type: "holiday", start: date, end: date, time: "",
            rel: 1, why: name ? "holiday" : r.dow === "sun" ? "Sunday" : "Saturday holiday", weekly: !name, src: texts.join(" · ") });
        }
        texts.filter(t => !/^holiday$/i.test(t) && !(hol && /holiday/i.test(t)) && t.split(/\s+/).length >= 3).forEach(t => {
          let rel = relevance(t, me);
          if (/first\s*years?/i.test(t) && me.semNo > 2) rel = { score: -2, why: "for first years only" };
          if (/higher\s*semesters?/i.test(t) && me.semNo > 2) rel = { score: 2, why: "for higher semesters" };
          out.push({ id: "c" + Math.random().toString(36).slice(2, 9), title: t.slice(0, 140), type: classify(t), start: date, end: date, time: "", rel: rel.score, why: rel.why, src: t });
        });
      });
    }
    // "Commencement of vacation" runs until the day before the next semester starts ("Commencement of AY … Even : 4th Jan 2027")
    const all = lines.map(l => l.t).join(" ");
    const nx = all.match(/commencement of (?:ay|academic year)[^:]*:\s*(\d{1,2})\s*(?:st|nd|rd|th)?\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*(20\d{2})/i);
    if (nx) { const next = new Date(ymd(+nx[3], MON[nx[2].toLowerCase()], +nx[1]) + "T00:00"); next.setDate(next.getDate() - 1);
      const last = ymd(next.getFullYear(), next.getMonth() + 1, next.getDate());   // local date (toISOString would shift it by the timezone)
      out.filter(e => /commencement of vacation/i.test(e.title)).forEach(e => { e.type = "holiday"; e.end = last; e.title = e.title.replace(/commencement of vacation/i, "Vacation") + ` (till ${next.toLocaleDateString(undefined, { day: "numeric", month: "short" })})`; }); }
    return dedupe(out);
  }

  /* grid timetables (Amrita end-sem timetable, often scanned): a date column on the left, course cells to the right,
     a session header (FN / AN) above each group of columns. Works on OCR words or PDF text items with positions. */
  const lev = (a, b) => { const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; };
  // OCR look-alikes collapse to one form: B/8, O/D/0, I/L/|/1, S/5, Z/2, G/6 ("22810201" = "22BIO201", "Ale" = "AIE")
  const canon = s => String(s).toUpperCase().replace(/[^A-Z0-9|]/g, "").replace(/B/g, "8").replace(/[OD]/g, "0").replace(/[IL|]/g, "1").replace(/S/g, "5").replace(/Z/g, "2").replace(/G/g, "6");
  // headings like "(B.Tech III Sem.-2025 Batch)" tell which page belongs to the student
  const ROMAN = { 1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII" };
  const pageIsMine = (text, me) => { const t = String(text).replace(/\s+/g, " ");
    const b = t.match(/(20\d{2})\s*batch/i); if (b && me.batch) return b[1] === String(me.batch);
    const s = t.match(/tech\s+([IVX]{1,4}|\d)\s*sem/i); return s && me.semNo ? (s[1] === ROMAN[me.semNo] || +s[1] === me.semNo) : false; };
  function fromGridWords(pages, me) {
    const out = [], codes = me.codes || [], names = me.names || [], ccodes = codes.map(canon);
    const branch = canon(me.branch || "AIE"), sw = semWindow();
    pages.forEach(pg => {
      const W = pg.words.map(w => ({ ...w, xc: (w.x0 + w.x1) / 2, yc: (w.y0 + w.y1) / 2, h: w.y1 - w.y0 }));
      const dates = [], seenD = new Set();
      W.forEach(w => { const m = w.t.match(/(\d{1,2})[.\-\/,](\d{1,2})[.\-\/,]?(20\d{2})/); if (!m) return;
        let y = +m[3]; const mo = +m[2];
        if (Math.abs(y - +sw.start.slice(0, 4)) > 1) y = academicYearHint()(mo);   // "24.11.2028" misread → this academic year
        const date = ymd(y, mo, +m[1]); if (!date) return;
        // one date per row position: the first OCR pass (sharper) wins over a second reading of the same cell
        if (dates.some(d => Math.abs(d.yc - w.yc) < Math.max(w.h, 10) && Math.abs(d.xc - w.xc) < 80)) return;
        dates.push({ ...w, date }); });
      const sess = W.filter(w => /^(FN|AN)\b|^(FN|AN)[*:;.\-]/i.test(w.t)).map(w => ({ ...w, kind: /^AN/i.test(w.t) ? "AN" : "FN" }));
      const branchHeads = W.filter(w => canon(w.t) === branch);
      if (!dates.length) return;
      const ds = [...dates].sort((a, b) => a.yc - b.yc);
      // a cell belongs to the nearest date row, as long as it's within ~60 % of the gap to the neighbouring row
      const rowOf = w => { let best = null; ds.forEach(d => { if (d.xc < w.x0 && (!best || Math.abs(d.yc - w.yc) < Math.abs(best.yc - w.yc))) best = d; });
        if (!best) return null;
        const i = ds.indexOf(best), gap = Math.min(...[ds[i - 1], ds[i + 1]].filter(Boolean).map(n => Math.abs(n.yc - best.yc)), 400);
        return Math.abs(best.yc - w.yc) < Math.max(0.6 * gap, 45) ? best : null; };
      const prevRow = row => ds.filter(d => d.yc < row.yc - 5).pop();
      // the session header (FN / AN) for a cell: the nearest one above it, in its column group (rows can share one header)
      const sessOf = (w, row) => { const cand = sess.filter(s => s.yc < w.yc - 5 && w.yc - s.yc < 8 * Math.max(row.h, 20));
        cand.sort((a, b) => (w.yc - a.yc) + 0.8 * Math.abs(a.xc - w.xc) - (w.yc - b.yc) - 0.8 * Math.abs(b.xc - w.xc)); return cand[0] ? cand[0].kind : ""; };
      const nearBranch = (w, row) => {   // this row's own column headers; a row without any shares the headers of the row above
        const p1 = prevRow(row), p2 = p1 && prevRow(p1);
        let heads = branchHeads.filter(b => b.yc < w.yc && b.yc > (p1 || { yc: -1e9 }).yc);
        if (!heads.length && p1 && !sess.some(s => s.yc < row.yc && s.yc > p1.yc)) heads = branchHeads.filter(b => b.yc < w.yc && b.yc > (p2 || { yc: -1e9 }).yc);
        return heads.length ? Math.min(...heads.map(b => Math.abs(b.xc - w.xc))) : null; };
      const hits = [];
      // 1) exact course codes (after fixing OCR look-alikes); no near-misses: 22AIE102 must never count as 22AIE202
      W.forEach(w => { const c = canon(w.t), i = ccodes.indexOf(c);
        if (i >= 0) hits.push({ w, i, how: "code" });
        // the same course under another scheme year: 23ENG230 on the timetable = 19ENG230 in AUMS
        else if (/^\d{2}[A-Z0-9]{2,5}\d{3}$/.test(c)) { const j = ccodes.findIndex(k => k.slice(2) === c.slice(2) && !/^\d+$/.test(c.slice(2, -3))); if (j >= 0) hits.push({ w, i: j, how: "renumbered" }); } });
      // 2) course names, for codes that differ between AUMS and the timetable (19ENG230 vs 23ENG230)
      names.forEach((n, i) => {
        if (!n || hits.some(h => h.i === i)) return;
        const key = n.toLowerCase().replace(/&/g, " ").replace(/[^a-z ]/g, " ").split(/\s+/).filter(x => x.length > 3 && !/^(introduction|engineers?|systems?|fundamentals)$/.test(x));
        if (key.length < 2) return;   // one word ("Python") is too weak: EEE's "Introduction to Python Programming" would match
        W.forEach(w => { if (w.t.toLowerCase().replace(/[^a-z]/g, "") !== key[0]) return;
          const rest = key.slice(1, 2); const ok = !rest.length || W.some(x => Math.abs(x.yc - w.yc) < w.h * 2.2 && x.x0 > w.x0 && x.x0 - w.x1 < 260 && x.t.toLowerCase().replace(/[^a-z]/g, "") === rest[0]);
          if (ok) hits.push({ w, i, how: "name" }); });
      });
      // one place per course on this page: prefer the copy under the student's branch column (e.g. AIE)
      const byCourse = new Map();
      hits.forEach(h => { const row = rowOf(h.w); if (!row) return; (byCourse.get(h.i) || byCourse.set(h.i, []).get(h.i)).push({ ...h, row }); });
      byCourse.forEach((list, i) => {
        // a name-only match must sit under the student's branch column (EEE's "Introduction to Python Programming" ≠ AIE's Python)
        list = list.filter(h => h.how !== "name" || (nearBranch(h.w, h.row) ?? 1e9) < 220);
        if (!list.length) return;
        const score = h => (h.how === "code" ? 0 : h.how === "renumbered" ? 100 : 500) + (nearBranch(h.w, h.row) ?? 250);
        const best = list.sort((a, b) => score(a) - score(b))[0];
        const s = sessOf(best.w, best.row);
        out.push({ id: "t" + Math.random().toString(36).slice(2, 9), title: `${names[i] || codes[i]} (${codes[i]})`, type: "exam", start: best.row.date, end: best.row.date,
          time: s === "AN" ? "13:30" : s === "FN" ? "09:30" : "", rel: 3, why: `your course · ${s || "session ?"}`, src: `${codes[i]} on ${best.row.date} (page ${pg.page})`, code: codes[i],
          examType: /end\s*sem/i.test(pg.heading || "") ? "End-sem" : /mid/i.test(pg.heading || "") ? "Mid-sem" : "" });
      });
    });
    const seen = new Set(); return out.filter(e => !seen.has(e.code) && seen.add(e.code)).sort((a, b) => a.start.localeCompare(b.start));
  }

  // current semester: Odd = July → mid-January (end-sem exams can spill over), Even = January → mid-July
  function semWindow(today = new Date()) {
    const y = today.getFullYear(), m = today.getMonth() + 1;
    if (m >= 7) return { start: `${y}-07-01`, end: `${y + 1}-01-15`, name: `${y}-${String(y + 1).slice(2)} Odd Sem` };
    return { start: `${y}-01-01`, end: `${y}-07-15`, name: `${y - 1}-${String(y).slice(2)} Even Sem` };
  }

  return { semWindow, isDayRowTable, fromDayRows, fromGridWords, pageIsMine, fromLines, fromWhatsApp, parseWhatsApp, AI_PROMPT, fromAi, dedupe, relevance, classify, findDates, academicYearHint };
})();
