// Minimal service worker so Chrome on the tablet can install Study Desk as an app.
// The server runs on the same device, so requests simply go to the network.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => { });
