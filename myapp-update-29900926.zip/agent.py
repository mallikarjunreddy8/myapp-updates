"""Android: the My App APK lends its hidden WebView to the hub as the portal browser.

The sync code in server.py was written against Playwright (Edge on Windows). On the tablet there is
no Edge, so this module offers the same small slice of the Playwright API (goto, evaluate, locator,
fill, frames, request.get, dialogs) and forwards each step to the APK: the APK long-polls
GET /api/agent/next, runs the step in its WebView and answers with POST /api/agent/result.
The student's Microsoft and AUMS sessions live in the APK's cookie store, never in this server.
"""
import base64
import itertools
import json
import queue
import threading
import time

# typed into the AUMS password box by the APK itself (it keeps the real password in Android Keystore)
AUMS_PASSWORD_TOKEN = "\u0001MYAPP_AUMS_PASSWORD\u0001"

# Playwright's ":visible" selector suffix, done in plain DOM
ELS = ("(s => { const vis = /:visible/.test(s); let a = [...document.querySelectorAll(s.replace(/:visible/g, ''))];"
       " return vis ? a.filter(e => e.offsetWidth || e.offsetHeight || e.getClientRects().length) : a; })")


class Agent:
    def __init__(self):
        self.jobs = queue.Queue()
        self.waiting = {}
        self.ids = itertools.count(1)
        self.seen = 0.0
        self.lock = threading.Lock()   # one portal job at a time

    # ---- APK side (Flask routes)
    def next_job(self, wait=25.0):
        self.seen = time.time()
        try:
            return self.jobs.get(timeout=wait)
        except queue.Empty:
            return None
        finally:
            self.seen = time.time()

    def put_result(self, body):
        w = self.waiting.get(body.get("id"))
        if w:
            w[1] = body
            w[0].set()

    # ---- server side
    def alive(self, grace=0.0):
        end = time.time() + grace
        while True:
            if time.time() - self.seen < 75:
                return True
            if time.time() >= end:
                return False
            time.sleep(0.5)

    def call(self, op, timeout=60.0, **args):
        if not self.alive(grace=15):
            raise RuntimeError("Open My App on the tablet so it can reach the portal, then try again.")
        i = next(self.ids)
        ev = threading.Event()
        self.waiting[i] = [ev, None]
        self.jobs.put({"id": i, "op": op, "args": args, "timeout": int(timeout * 1000)})
        if not ev.wait(timeout + 20):
            self.waiting.pop(i, None)
            raise TimeoutError(f"My App didn't finish '{op}' in time.")
        res = self.waiting.pop(i)[1]
        for msg in res.get("dialogs") or []:
            if self.on_dialog:
                self.on_dialog(_Dialog(msg))
        if res.get("error"):
            raise RuntimeError(res["error"])
        return res

    on_dialog = None


AGENT = Agent()


class _Dialog:
    def __init__(self, message):
        self.message = message

    def accept(self):   # the APK already accepted it
        pass

    def dismiss(self):
        pass


def _eval(frame, js, arg):
    res = AGENT.call("eval", frame=frame, js=js, arg=arg)
    out = json.loads(res.get("raw") or "{}")
    if "e" in out:
        raise RuntimeError("page script: " + str(out["e"])[:200])
    return out.get("v")


class Frame:
    def __init__(self, index, url):
        self.index, self.url = index, url

    def evaluate(self, js, arg=None):
        return _eval(self.index, js, arg)


class Locator:
    def __init__(self, page, sel):
        self.page, self.sel = page, sel

    @property
    def first(self):
        return self

    def count(self):
        return _eval(-1, f"s => {ELS}(s).length", self.sel)

    def click(self):
        _eval(-1, f"s => {{ const e = {ELS}(s)[0]; if (!e) throw new Error('not found: ' + s); e.click(); return true; }}", self.sel)
        self.page.wait_for_load_state()

    def evaluate(self, js, arg=None):
        return _eval(-1, f"([s, src, a]) => {{ const e = {ELS}(s)[0]; if (!e) throw new Error('not found: ' + s); return eval('(' + src + ')')(e, a); }}",
                     [self.sel, js, arg])

    def screenshot(self, **kw):
        raise RuntimeError("Screenshots aren't available in the Android app.")


class _Response:
    def __init__(self, res):
        self.status = res.get("status", 0)
        self.ok = 200 <= self.status < 300
        self._body = base64.b64decode(res.get("body") or "")

    def body(self):
        return self._body


class _Request:
    def get(self, url, headers=None):
        return _Response(AGENT.call("http", url=url, headers=headers or {}))


class Page:
    def __init__(self):
        self.request = _Request()

    @property
    def url(self):
        return AGENT.call("url").get("value", "")

    @property
    def frames(self):
        urls = AGENT.call("frames").get("value") or []
        return [Frame(-1, self.url)] + [Frame(i, u) for i, u in enumerate(urls) if u]

    def on(self, event, fn):
        if event == "dialog":
            AGENT.on_dialog = fn

    def goto(self, url, wait_until=None, timeout=45000):
        AGENT.call("goto", timeout=timeout / 1000, url=url)

    def evaluate(self, js, arg=None):
        return _eval(-1, js, arg)

    def wait_for_timeout(self, ms):
        time.sleep(ms / 1000)

    def wait_for_load_state(self, state=None, timeout=12000):
        AGENT.call("settle", timeout=timeout / 1000)

    def wait_for_url(self, pred, timeout=30000):
        end = time.time() + timeout / 1000
        while time.time() < end:
            if pred(self.url):
                return
            time.sleep(0.5)
        raise TimeoutError("page did not move on")

    def wait_for_function(self, js, timeout=30000):
        end = time.time() + timeout / 1000
        while time.time() < end:
            if self.evaluate(js):
                return
            time.sleep(0.5)
        raise TimeoutError("condition not met")

    def locator(self, sel):
        return Locator(self, sel)

    def fill(self, sel, value):
        AGENT.call("fill", sel=sel, value=value)

    def click(self, sel):
        Locator(self, sel).click()


class Context:
    """Stands in for Playwright's persistent browser context."""

    def __init__(self, headless=True):
        AGENT.lock.acquire()
        self.page, self.closed = Page(), False
        AGENT.on_dialog = None

    @property
    def pages(self):
        return [] if self.closed else [self.page]

    def new_page(self):
        return self.page

    def show(self, url):
        """Open a visible sign-in window in My App; returns when the student taps Done."""
        AGENT.call("show", timeout=900, url=url)

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            AGENT.call("reset", timeout=15)
        except Exception:  # noqa: BLE001
            pass
        finally:
            AGENT.lock.release()
