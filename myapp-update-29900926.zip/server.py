"""Starts the My App hub. All the code is in hub.py: Python keeps a compiled copy of an imported module
(but never of the script it starts), so the app opens faster, above all on phones."""
import hub

if __name__ == "__main__":
    hub.main()
