/* BTech Study Desk - app logic */
"use strict";
const APP_VERSION = "2.0.0";
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<mark>$1</mark>");
const DAY = 864e5;
const iso = d => { const x = new Date(d); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); };
const inDays = n => iso(Date.now() + n * DAY);
const uid = () => Math.random().toString(36).slice(2, 10);
const ls = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { } } };
const nz = v => v === null || v === "" || v === undefined || isNaN(v) ? null : +v;

/* ---------------- server API ---------------- */
// the shareable "Amrita BTech" APK (classmates edition) vs the developer's own My App
const isClassmates = () => !!(window.MyAppAndroid && MyAppAndroid.isClassmates && MyAppAndroid.isClassmates());
/* App lock (your own app on the phone only): a password on opening and after a minute away.
   Until you set your own in Profile → App lock, the starting password is your roll number. Only a SHA-256 hash is saved. */
const Lock = (() => {
  const avail = () => !!window.MyAppAndroid && !isClassmates();
  const cfg = () => { try { return P().appLock || {}; } catch { return {}; } };
  const on = () => avail() && !cfg().off;
  let box = null, away = 0;
  async function hash(t) {
    const d = new TextEncoder().encode("myapp-lock:" + t);
    if (crypto?.subtle) return [...new Uint8Array(await crypto.subtle.digest("SHA-256", d))].map(b => b.toString(16).padStart(2, "0")).join("");
    let h = 2166136261; for (const b of d) h = Math.imul(h ^ b, 16777619); return "f" + (h >>> 0).toString(16);
  }
  const roll = () => { try { return String(profile().roll || "").trim(); } catch { return ""; } };
  async function matches(v) { v = v.trim(); const c = cfg(); return c.hash ? (await hash(v)) === c.hash : !!roll() && v.toLowerCase() === roll().toLowerCase(); }
  const hasPassword = () => !!(cfg().hash || roll());
  function show() {
    if (box && !box.isConnected) box = null;
    if (!on() || box) return;
    box = document.createElement("div"); box.id = "app-lock"; box.className = "app-lock"; box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-labelledby", "lock-t");
    box.innerHTML = `<form class="lock-card" autocomplete="off"><div class="lock-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></div>
      <h2 id="lock-t">My App is locked</h2><p class="muted">Enter your password to open it.</p>
      <input id="lock-in" type="password" inputmode="numeric" pattern="[0-9]*" aria-label="Password" placeholder="Password" maxlength="12">
      <p class="lock-err" id="lock-err" aria-live="polite"></p>
      <button class="btn primary upd-btn" type="submit">Unlock</button>
      <p class="small muted" style="margin:18px 0 0">Developed by <b>Basare Mallikarjun</b></p></form>`;
    document.body.append(box);
    const inp = box.querySelector("#lock-in"); setTimeout(() => inp.focus(), 50);
    box.querySelector("form").onsubmit = async e => { e.preventDefault(); if (await matches(inp.value)) open(); else wrong(); };
    inp.oninput = async () => { inp.value = inp.value.replace(/\D/g, ""); const v = inp.value; if (v.trim() && await matches(v) && inp.value === v) open(); };
  }
  function open() { box?.remove(); box = null; }
  function wrong() {
    $("#lock-err").textContent = "Wrong password. Try again.";
    const c = box.querySelector(".lock-card"); c.classList.remove("shake"); void c.offsetWidth; c.classList.add("shake");
    const inp = $("#lock-in"); inp.value = ""; inp.focus();
  }
  // after the data loads: lock turned off, or nothing to check against yet (new setup) = open
  function ready() { if (box && (!on() || !hasPassword())) open(); }
  document.addEventListener("visibilitychange", () => { if (document.hidden) away = Date.now(); else if (away && Date.now() - away > 60000) show(); });
  return { show, ready, avail, on, matches, hash };
})();
Lock.show();
const INSTALLS_SHEET = "https://docs.google.com/spreadsheets/d/1IBEfsnkmjxuXahkOfCaCiGzULgTKAy7deZ7vBqMa2eI/edit";
// classmates who agreed send their name, roll number and section to the developer's form (hub posts it, retries until it gets through)
async function reportInstall(pr) {
  try { const r = await api("/api/installs/report", "POST", { name: pr.name || "", roll: pr.roll || "", section: `${pr.branch || ""}-${pr.section || ""}` });
    if (r.ok) { pr.reported = Date.now(); touch(); } } catch { }
}
function installsConsent() {   // classmates who set up before this update: ask once, then report
  const pr = profile();
  if (!isClassmates() || !pr.roll || pr.reported || pr.shareOk === false || $("#share-ask")) return;
  if (pr.shareOk) { reportInstall(pr); return; }
  document.body.insertAdjacentHTML("beforeend", `<dialog id="share-ask" class="wl"><div class="wl-card">
    <h2 style="font-size:1.3rem">A note from the developer</h2>
    <p class="wl-sub">This app was made by <b>Basare Mallikarjun</b>. May it share your <b>name, roll number and section</b> with him, so he knows who uses it? Nothing else is ever shared.</p>
    <button class="btn primary wl-big" id="share-yes">Yes, share</button><button class="btn ghost wl-big" id="share-no">No thanks</button></div></dialog>`);
  const d = $("#share-ask"), done = ok => { pr.shareOk = ok; touch(); d.close(); d.remove(); if (ok) reportInstall(pr); };
  $("#share-yes").onclick = () => done(true); $("#share-no").onclick = () => done(false);
  d.showModal();
}
// the portal can be driven here: Edge on the PC, or the My App APK on the hub tablet
const canBrowse = () => STATUS.local && (STATUS.platform === "windows" || !!STATUS.browser || (STATUS.platform === "android" && !!window.MyAppAndroid));
async function api(path, method = "GET", body, raw) {
  const opt = { method, headers: {} };
  if (body !== undefined) { if (raw) opt.body = body; else { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; } }
  const r = await fetch(path, opt);
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) throw Object.assign(new Error((data && data.message) || r.statusText), { status: r.status, data });
  return data;
}
const STATUS = { ai: { running: false }, platform: "windows", local: true };
async function refreshStatus(have) {
  if (!have) try { Object.assign(STATUS, await api("/api/status")); } catch { }
  const c = $("#ai-chip");
  c.className = "chip " + (STATUS.ai.running && STATUS.ai.model ? "ai" : "");
  c.textContent = STATUS.ai.running && STATUS.ai.model ? "AI on · " + STATUS.ai.model : "AI off (free engine)";
  renderSettings();
}
/* free local AI, streamed */
async function ai(prompt, { json = false, onText, signal } = {}) {
  const r = await fetch("/api/ai/stream", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt, json }), signal });
  if (!r.ok) { let m = "AI unavailable"; try { m = (await r.json()).message || m; } catch { } throw new Error(m); }
  const rd = r.body.getReader(), dec = new TextDecoder(); let text = "";
  for (; ;) { const { done, value } = await rd.read(); if (done) break; text += dec.decode(value, { stream: true }); onText && onText(text); }
  if (!json) return text;
  const a = text.indexOf("{"), b = text.lastIndexOf("}");
  if (a < 0 || b < a) throw new Error("AI reply had no JSON");
  return JSON.parse(text.slice(a, b + 1));
}
const aiOn = () => STATUS.ai.running && STATUS.ai.model;

/* ---------------- example content (until the student adds their own) ---------------- */
const EXAMPLE_NOTE = { id: "example", example: true, title: "Principal Component Analysis (PCA)", subject: "MFC", source: "Example", createdAt: 0, engine: "ai",
  notes: { tldr: "PCA squeezes many correlated features into a few new axes (principal components) that keep **most of the variance**. You get them from the **eigenvectors of the covariance matrix**.",
    eli5: "Imagine photographing a long pencil. From the side you see its full length; from the end you see a dot. PCA finds the 'side view' of your data: the direction where it spreads out the most, then the next best direction at a right angle, and so on.",
    summary: ["Standardise the data first so every feature has mean 0 (and usually variance 1).", "Covariance matrix shows how features vary together.", "Eigenvectors = directions (principal components); eigenvalues = variance along each.", "Sort by eigenvalue, keep the top k components.", "Explained variance ratio tells you how many to keep (often 90–95%).", "Project data: Z = X·W_k gives the reduced dataset."],
    sections: [
      { heading: "Why we need PCA", points: ["Real datasets have **many correlated features** (e.g. soil N, P, K, pH in crop data).", "Too many dimensions → slow models, overfitting, **curse of dimensionality**.", "PCA keeps the information (variance) while dropping redundancy."], formula: null, example: "Leaf images with 4096 pixels → 50 principal components still keep ~95% of the variance.", examTip: "Always write the motivation in 2–3 lines before the steps. It's an easy 1–2 marks." },
      { heading: "The algorithm step by step", points: ["**Step 1**: standardise X (subtract mean, divide by std).", "**Step 2**: covariance matrix C = (1/(n−1)) XᵀX.", "**Step 3**: solve C·v = λ·v for eigenvalues λ and eigenvectors v.", "**Step 4**: sort λ in descending order; pick top k eigenvectors → W_k.", "**Step 5**: project: Z = X·W_k."], formula: "C v = λ v\nExplained variance ratio_i = λ_i / Σ λ_j", example: null, examTip: "Five clear numbered steps plus the formulas is exactly what a 10-mark answer wants." },
      { heading: "Choosing k", points: ["Plot a **scree plot** (eigenvalue vs component number) and look for the elbow.", "Or keep enough components for **cumulative explained variance ≥ 90–95%**."], formula: "Cumulative EV(k) = (λ₁+…+λ_k) / (λ₁+…+λ_n)", example: "λ = [4.2, 1.1, 0.4, 0.3] → first two keep (5.3/6.0) = 88%.", examTip: null },
      { heading: "PCA with SVM", points: ["PCA before an **SVM** cuts training time and can reduce noise.", "Fit PCA on the **training set only**, then transform the test set with the same W_k.", "Too few components can throw away class-separating information."], formula: null, example: null, examTip: "Mention data leakage (fitting PCA on the test set). Examiners love it." }],
    keyTerms: [{ term: "Principal component", meaning: "A new axis = linear combination of original features, orthogonal to the others." }, { term: "Eigenvalue", meaning: "Variance of the data along its eigenvector." }, { term: "Covariance matrix", meaning: "Square matrix of pairwise covariances between features." }, { term: "Explained variance ratio", meaning: "Share of total variance captured by one component." }, { term: "Scree plot", meaning: "Eigenvalues plotted in descending order; elbow suggests k." }, { term: "Standardisation", meaning: "Rescaling to mean 0, std 1 so units don't dominate." }],
    mindmap: { label: "PCA", children: [
      { label: "Why", children: [{ label: "Curse of dimensionality" }, { label: "Correlated features" }, { label: "Faster models" }] },
      { label: "Steps", children: [{ label: "Standardise" }, { label: "Covariance matrix" }, { label: "Eigen decomposition" }, { label: "Sort & pick k" }, { label: "Project Z = XW" }] },
      { label: "Choosing k", children: [{ label: "Scree plot elbow" }, { label: "≥ 95% variance" }] },
      { label: "Maths", children: [{ label: "Cv = λv" }, { label: "Orthogonal axes" }, { label: "λ = variance" }] },
      { label: "With SVM", children: [{ label: "Fit on train only" }, { label: "Less noise" }, { label: "Risk: lose info" }] }] } },
  tools: { flashcards: [{ q: "What does an eigenvalue represent in PCA?", a: "The variance of the data along its eigenvector (principal component)." }, { q: "Why standardise before PCA?", a: "So features with large units don't dominate the variance." }, { q: "Formula for the covariance matrix?", a: "C = (1/(n−1)) XᵀX for mean-centred X." }, { q: "How do you pick k?", a: "Scree-plot elbow, or cumulative explained variance ≥ 90–95%." }, { q: "Are principal components correlated?", a: "No, they are orthogonal (uncorrelated)." }, { q: "What is the projection step?", a: "Z = X·W_k, where W_k holds the top k eigenvectors." }],
    quiz: [{ q: "PCA components are chosen by sorting…", options: ["Eigenvectors by length", "Eigenvalues in descending order", "Features by mean", "Samples by variance"], answer: 1, why: "Bigger eigenvalue = more variance captured." }, { q: "Principal components are always…", options: ["Parallel", "Orthogonal", "Identical to features", "Labels"], answer: 1, why: "Eigenvectors of a symmetric covariance matrix are orthogonal." }, { q: "λ = [5, 3, 2]. Variance kept by PC1?", options: ["50%", "30%", "5%", "20%"], answer: 0, why: "5 / (5+3+2) = 0.5." }],
    examQuestions: [{ marks: 2, q: "Define principal component.", outline: ["New orthogonal axis", "Linear combination of original features", "Ordered by variance captured"] }, { marks: 5, q: "Explain how to choose the number of components in PCA.", outline: ["Explained variance ratio formula", "Cumulative ≥ 90–95%", "Scree plot + elbow", "Small numeric example"] }, { marks: 10, q: "Explain the PCA algorithm with an example and its use before SVM classification.", outline: ["Motivation", "5 steps with formulas", "Worked 2-D example", "Choosing k", "Fit-on-train for SVM pipeline", "Pros/cons"] }],
    mnemonics: ["**S-C-E-S-P**: Standardise, Covariance, Eigen, Sort, Project ('Some Cats Eat Spicy Pizza')."],
    checklist: ["I can write the 5 PCA steps from memory", "I can compute explained variance ratio", "I can explain the scree plot", "I know why we standardise", "I can explain PCA before SVM"] },
  progress: { known: [], quiz: {}, checks: [] } };

function examplePlanner() {
  return { example: true, hours: 3,
    exams: [],   // no sample exams — Calendar and Exams stay empty until the student uploads their own
    scale: "amrita", cur: 1,
    sems: [{ id: uid(), name: "Sem 3", subs: [{ n: "Data Structures", cr: 4, io: 34, im: 40, eo: 48, em: 60 }, { n: "Discrete Maths", cr: 4, io: 30, im: 40, eo: 39, em: 60 }, { n: "Digital Logic", cr: 3, io: 36, im: 40, eo: 51, em: 60 }, { n: "OOP with Java", cr: 3, io: 28, im: 40, eo: 44, em: 60 }, { n: "DS Lab", cr: 2, io: 45, im: 50, eo: 44, em: 50 }] },
      { id: uid(), name: "Sem 4", subs: [{ n: "DBMS", cr: 4, io: 31, im: 40, eo: null, em: 60 }, { n: "Operating Systems", cr: 4, io: 26, im: 40, eo: null, em: 60 }, { n: "Computer Networks", cr: 3, io: 35, im: 40, eo: null, em: 60 }, { n: "MFC", cr: 4, io: 22, im: 40, eo: null, em: 60 }, { n: "OS Lab", cr: 2, io: 42, im: 50, eo: null, em: 50 }] }],
    target: 8.5, nextCr: 20, planDone: {},
    att: { min: 75, subs: [{ id: uid(), n: "DBMS", a: 28, t: 34 }, { id: uid(), n: "Operating Systems", a: 22, t: 32 }, { id: uid(), n: "Computer Networks", a: 30, t: 33 }, { id: uid(), n: "MFC", a: 19, t: 28 }, { id: uid(), n: "OS Lab", a: 11, t: 12 }] } };
}

/* ---------------- state ---------------- */
const S = { tab: "notes", notes: [], current: null, sub: "overview", planner: examplePlanner(), fc: { i: 0, flip: false, order: null }, sources: {}, chats: {}, portal: { links: [] }, polishing: new Set() };
const P = () => S.planner;

const SOLO = { att: "Attendance", marks: "Marks", grades: "Grades & CGPA", gp: "Gate pass", profile: "Profile" };
const PAGE_TITLES = { home: "Amrita BTech", today: "Today", ...SOLO, notes: "Notes", mirror: "myAmrita", cal: "Calendar", exams: "Exams", portal: "Settings" };
/* app-style navigation: Back / Forward buttons (and the phone's back gesture) walk this history */
S.hIdx = 0; S.hMax = 0;
function navButtons() { $("#nav-back").disabled = S.hIdx <= 0; $("#nav-fwd").disabled = S.hIdx >= S.hMax; }
$("#nav-back").onclick = () => history.back();
$("#nav-fwd").onclick = () => history.forward();
window.addEventListener("popstate", e => { const s = e.state || { tab: "home", i: 0 }; S.hIdx = s.i || 0; if (s.sub) S.mirTab = s.sub; setTab(s.tab, false); });
function setTab(t, push = true) {
  if (t === "plan" || !PAGE_TITLES[t]) t = "home";
  const nav = t;
  if (push && (nav !== S.navKey || (nav === "mirror" && S.mirTab !== S.navSub))) {
    S.hIdx++; S.hMax = S.hIdx; history.pushState({ tab: nav, sub: S.mirTab, i: S.hIdx }, "", "#" + nav);
  }
  S.navKey = nav; S.navSub = S.mirTab;
  // Attendance, Marks, Grades, Gate pass and Profile are pages of their own (no myAmrita tab row)
  if (SOLO[t]) { S.mirTab = t; t = "mirror"; }
  $("#p-mirror").classList.toggle("solo", !!SOLO[nav]);
  S.tab = t; $$(".tabs button").forEach(b => b.setAttribute("aria-selected", b.dataset.tab === nav));
  ["home", "today", "notes", "plan", "mirror", "cal", "exams", "portal"].forEach(k => $("#p-" + k).hidden = k !== t);
  $("#page-title").textContent = PAGE_TITLES[nav];
  navButtons(); window.scrollTo(0, 0);
  if (t === "today") renderTodayPage();
  if (t === "home") renderHome();
  ls.set("sd-tab", t);
  if (t === "notes" && S.sub === "mindmap") requestAnimationFrame(mmFit);
  if (t === "plan") renderPlan();
  if (t === "mirror") renderMirror();
  if (t === "cal") renderCal();
  if (t === "portal") { refreshStatus(); renderPortal(); }
}
$$(".tabs button").forEach(b => b.onclick = () => setTab(b.dataset.tab));

/* =========================================================
   NOTES
   ========================================================= */
let picked = [];
$("#file").onchange = e => setPicked([...e.target.files]);
const drop = $("#drop");
["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
drop.addEventListener("drop", e => setPicked([...e.dataTransfer.files].filter(f => f.type === "application/pdf" || f.type.startsWith("image/"))));
function setPicked(f) { picked = f; $("#picked").innerHTML = f.map(x => `<span class="chip" style="margin:2px">${esc(x.name)} · ${(x.size / 1048576).toFixed(1)} MB</span>`).join(""); }
function genMsg(html, cls) { const m = $("#gen-msg"); m.className = "small " + (cls || ""); m.innerHTML = html; }
function step(n, state, label) { const el = $(`.step[data-s="${n}"]`); el.classList.remove("on", "done"); if (state) el.classList.add(state); if (label) el.querySelector("span").textContent = label; }

let stopFlag = false;
$("#stop").onclick = () => stopFlag = true;
$("#go").onclick = generate;
async function generate() {
  const pasted = $("#paste").value.trim();
  if (!picked.length && !pasted) { genMsg("Choose a PDF or paste some text first.", "err"); return; }
  stopFlag = false;
  $("#go").disabled = true; $("#stop").hidden = false; $("#progress").hidden = false;
  [1, 2, 3].forEach(n => step(n)); step(1, "on"); step(3, null, "AI polish (runs in the background)"); genMsg("");
  try {
    let lines = [], pages = 1, sourceText = "";
    const name = picked[0]?.name || "Pasted text";
    for (const f of picked) {
      if (stopFlag) throw { stopped: true };
      if (f.type === "application/pdf") {
        const r = await Engine.readPdf(f, (p, n) => genMsg(`Reading ${esc(f.name)}: page ${p} of ${n}`, "muted"));
        pages += r.pages;
        const chars = r.lines.reduce((n, l) => n + l.t.length, 0);
        if (chars < 60 * r.pages) {
          genMsg("This PDF is scanned, so I'm reading it with free OCR. It's slower, about 5–10 s per page.", "muted");
          const canv = await Engine.pdfPagesToCanvas(r.pdf, 40);
          const ol = await Engine.ocr(canv, (p, n) => genMsg(`Free OCR: page ${p} of ${n}…`, "muted"));
          lines.push(...ol);
        } else lines.push(...r.lines);
      } else if (f.type.startsWith("image/")) {
        const ol = await Engine.ocr([f], () => genMsg(`Reading photo ${esc(f.name)} with free OCR…`, "muted"));
        lines.push(...ol);
      } else {   // Word, PowerPoint, Excel, CSV, HTML, text: the server turns it into lines (headings kept as short lines)
        genMsg(`Reading ${esc(f.name)}…`, "muted");
        const r = await api(`/api/extract?name=${encodeURIComponent(f.name)}`, "POST", f, true);
        lines.push(...Engine.textToLines(r.lines.join("\n")));
      }
    }
    if (pasted) lines.push(...Engine.textToLines(pasted));
    if (!lines.length) throw { friendly: "I couldn't find any text in that file." };
    sourceText = lines.map(l => l.t).join("\n");
    step(1, "done"); step(2, "on");
    await new Promise(r => setTimeout(r, 20));
    const built = Engine.build(lines, { pages, fileName: name });
    // no subject typed: tag it with the current-semester course the PDF is about (course code or name in the text)
    let subject = $("#subject").value.trim();
    if (!subject) { const m = me(), up = sourceText.toUpperCase(); const i = m.codes.findIndex((c, k) => up.includes(c) || (m.names[k] && m.names[k].length > 8 && up.includes(m.names[k].toUpperCase()))); if (i >= 0) subject = m.names[i] || m.codes[i]; }
    const note = { id: "n_" + Date.now().toString(36) + uid().slice(0, 4), kind: "note", title: built.title, subject, source: name, createdAt: Date.now(), engine: "free",
      notes: built.notes, tools: built.tools, progress: { known: [], quiz: {}, checks: [] } };
    S.notes.unshift(note); S.sources[note.id] = sourceText;
    S.sub = "overview"; openNote(note.id);
    await saveNote(note);
    api(`/api/sources/${note.id}`, "PUT", sourceText, true).catch(() => { });
    step(2, "done");
    genMsg(`Done! ${note.notes.sections.length} sections, ${note.tools.flashcards.length} flashcards, ${note.tools.quiz.length} quiz questions.`, "ok");
    if ($("#use-ai").checked && aiOn()) polish(note);
    else step(3, null, aiOn() ? "AI polish (off)" : "AI polish (install free AI to enable)");
  } catch (e) {
    if (e?.stopped) genMsg("Stopped.", "muted");
    else { console.error(e); genMsg(esc(e?.friendly || e?.message || "Something went wrong reading that file."), "err"); }
    [1, 2].forEach(n => { if (!$(`.step[data-s="${n}"]`).classList.contains("done")) step(n); });
  } finally { $("#go").disabled = false; $("#stop").hidden = true; }
}

/* AI polish: TL;DR, ELI5, exam tips, memory trick, using the free local model */
async function getSource(id) {
  if (S.sources[id] != null) return S.sources[id];
  try { S.sources[id] = await api(`/api/sources/${id}`); } catch { S.sources[id] = ""; }
  return S.sources[id];
}
async function polish(note) {
  if (S.polishing.has(note.id)) return;
  S.polishing.add(note.id); step(3, "on", "AI polishing your notes…"); if (S.current?.id === note.id) renderDoc();
  try {
    const src = (await getSource(note.id)).slice(0, 14000);
    const heads = note.notes.sections.slice(0, 12).map((s, i) => `${i + 1}. ${s.heading}`).join("\n");
    const j = await ai(`You help a B.Tech student revise. Read the study material and reply with ONLY JSON:
{"tldr":"2 simple sentences with the core idea","eli5":"3-4 sentences explaining it with an everyday analogy","tips":["one short exam tip for each numbered heading below, same order"],"mnemonic":"one memory trick for a list/steps in the material, or empty string","extraQuestions":[{"q":"likely exam question","marks":5}]}
Headings:
${heads}
<material>
${src}
</material>`, { json: true });
    if (j.tldr) note.notes.tldr = String(j.tldr);
    if (j.eli5) note.notes.eli5 = String(j.eli5);
    (j.tips || []).forEach((t, i) => { if (t && note.notes.sections[i]) note.notes.sections[i].examTip = String(t); });
    if (j.mnemonic) note.tools.mnemonics.unshift(String(j.mnemonic));
    (j.extraQuestions || []).slice(0, 4).forEach(q => q?.q && note.tools.examQuestions.push({ marks: +q.marks || 5, q: String(q.q), outline: [] }));
    note.engine = "free+ai"; note.ai = STATUS.ai.model;
    await saveNote(note);
    step(3, "done", "AI polish done ✓");
  } catch (e) { step(3, null, "AI polish failed: " + (e.message || "error").slice(0, 60)); }
  finally { S.polishing.delete(note.id); if (S.current?.id === note.id) renderDoc(); }
}

/* ---------------- library & persistence ---------------- */
function allNotes() { return S.notes.length ? S.notes : [EXAMPLE_NOTE]; }
$("#lib-q").oninput = renderLib;
function renderLib() {
  const q = $("#lib-q").value.trim().toLowerCase();
  const list = allNotes().filter(n => !q || (n.title + " " + n.subject).toLowerCase().includes(q));
  $("#lib").innerHTML = list.map(n => `<button data-id="${esc(n.id)}" aria-current="${S.current?.id === n.id}"><b>${esc(n.title)}</b><span class="small muted">${esc(n.subject || "No subject")}${n.example ? ' · <span class="chip ex">example</span>' : " · " + new Date(n.createdAt).toLocaleDateString()}</span></button>`).join("") || '<p class="small muted">No matches.</p>';
  $$("#lib button").forEach(b => b.onclick = () => openNote(b.dataset.id));
  const subs = new Set([...S.notes.map(n => n.subject), ...P().exams.map(e => e.sub), ...(P().sems[P().cur]?.subs || []).map(s => s.n), ...P().att.subs.map(s => s.n)].filter(Boolean));
  $("#subject-list").innerHTML = [...subs].map(s => `<option value="${esc(s)}">`).join("");
}
function openNote(id) { S.current = allNotes().find(n => n.id === id) || allNotes()[0]; S.fc = { i: 0, flip: false, order: null }; renderLib(); renderDoc(); }
async function saveNote(n) { if (n.example) return; try { await api(`/api/notes/${n.id}`, "PUT", { note: n, markdown: toMd(n) }); } catch (e) { genMsg("Couldn't save: " + esc(e.message), "err"); } }
let progTimer = null;
function saveProgress() { const n = S.current; if (!n || n.example) return; clearTimeout(progTimer); progTimer = setTimeout(() => api(`/api/notes/${n.id}/progress`, "PATCH", n.progress).catch(() => { }), 800); }
async function deleteNote(id) { S.notes = S.notes.filter(n => n.id !== id); await api(`/api/notes/${id}`, "DELETE").catch(() => { }); S.current = null; openNote(allNotes()[0].id); }

/* ---------------- document view ---------------- */
const SUBS = [["overview", "Overview"], ["notes", "Notes"], ["mindmap", "Mind map"], ["cards", "Flashcards"], ["quiz", "Quiz"], ["exam", "Exam Qs"], ["terms", "Key terms"], ["ask", "Ask AI tutor"]];
function renderDoc() {
  const n = S.current; if (!n) return; const N = n.notes, T = n.tools || {};
  const d = $("#doc");
  const engineChip = n.example ? '<span class="chip ex">Example: upload your own PDF</span>' : S.polishing.has(n.id) ? '<span class="chip ai">AI polishing…</span>' : n.ai ? `<span class="chip ai">AI-polished</span>` : '<span class="chip">Free engine</span>';
  d.innerHTML = `<div class="doc-head"><div style="min-width:0">
      <div class="row" style="gap:6px;margin-bottom:4px">${n.subject ? `<span class="chip">${esc(n.subject)}</span>` : ""}${engineChip}${n.example ? "" : `<span class="chip">${esc(n.source)}</span>`}</div>
      <h2>${esc(n.title)}</h2></div>
    <div class="row">${!n.example && !n.ai && aiOn() && !S.polishing.has(n.id) ? '<button class="btn" id="do-polish">✨ AI polish</button>' : ""}<button class="btn" id="export">Download .md</button>${n.example ? "" : `<button class="btn ghost danger" id="del">Delete</button>`}</div></div>
    <div class="subtabs" role="tablist">${SUBS.map(([k, l]) => `<button role="tab" id="st-${k}" data-k="${k}" aria-selected="${S.sub === k}">${l}</button>`).join("")}</div>
    <div id="sub"></div>`;
  d.querySelectorAll(".subtabs button").forEach(b => b.onclick = () => { S.sub = b.dataset.k; renderDoc(); });
  $("#export").onclick = exportMd;
  const pb = $("#do-polish"); if (pb) pb.onclick = () => polish(n);
  const del = $("#del"); if (del) del.onclick = () => { if (del.dataset.armed) deleteNote(n.id); else { del.dataset.armed = 1; del.textContent = "Click again to delete"; } };
  const box = $("#sub");
  if (S.sub === "overview") {
    box.innerHTML = `<p class="eyebrow">TL;DR</p><p class="tldr">${fmt(N.tldr || "")}</p>
      ${N.eli5 ? `<div class="eli5"><span class="note-hand">Explain like I'm 5 →</span><p style="margin:0">${fmt(N.eli5)}</p></div>` : (S.polishing.has(n.id) ? '<p class="small muted">The free AI is writing a simple explanation…</p>' : "")}
      <div class="two"><div class="card"><span class="eyebrow">Must-remember</span><ul class="clean">${(N.summary || []).map(s => `<li>${fmt(s)}</li>`).join("")}</ul></div>
      <div class="card"><span class="eyebrow">Before-exam checklist</span><ul class="clean check">${(T.checklist || []).map((s, i) => `<li><input type="checkbox" id="ck${i}" data-i="${i}" ${n.progress.checks.includes(i) ? "checked" : ""}><label for="ck${i}">${fmt(s)}</label></li>`).join("")}</ul>
      ${(T.mnemonics || []).length ? `<p class="eyebrow" style="margin-top:14px">Memory tricks</p>${T.mnemonics.map(m => `<p class="note-hand" style="margin:4px 0;font-size:1.15rem">${fmt(m)}</p>`).join("")}` : ""}</div></div>`;
    box.querySelectorAll(".check input").forEach(c => c.onchange = () => { const i = +c.dataset.i, a = n.progress.checks; c.checked ? a.push(i) : a.splice(a.indexOf(i), 1); saveProgress(); });
  } else if (S.sub === "notes") {
    box.innerHTML = (N.sections || []).map(s => `<section class="sec"><h3>${esc(s.heading)}</h3>${s.points.length ? `<ul class="clean">${s.points.map(p => `<li>${fmt(p)}</li>`).join("")}</ul>` : ""}
      ${(s.subs || []).map(x => `<h4>${esc(x.heading)}</h4><ul class="clean">${x.points.map(p => `<li>${fmt(p)}</li>`).join("")}</ul>`).join("")}
      ${s.formula ? `<div class="formula">${esc(s.formula)}</div>` : ""}${s.example ? `<div class="example"><span class="eyebrow">Example</span><div>${fmt(s.example)}</div></div>` : ""}
      ${s.examTip ? `<p class="tip"><span class="note-hand">Exam tip:</span> ${fmt(s.examTip)}</p>` : ""}</section>`).join("") || '<p class="muted">No sections found.</p>';
  } else if (S.sub === "mindmap") {
    box.innerHTML = `<div class="mm" id="mm"><svg id="mmsvg" role="img" aria-label="Mind map of ${esc(n.title)}"><g id="mmg"></g></svg>
      <div class="tools"><button class="btn" id="mm-out" aria-label="Zoom out">−</button><button class="btn" id="mm-in" aria-label="Zoom in">+</button><button class="btn" id="mm-fit">Fit</button><button class="btn" id="mm-fs">Full screen</button></div>
      <div class="hint">Drag to move · scroll or +/− to zoom · tap a branch to fold it</div></div>`; mmInit(N.mindmap);
  } else if (S.sub === "cards") { (T.flashcards || []).length ? renderCards(box) : box.innerHTML = '<p class="muted">No flashcards found in this file.</p>'; }
  else if (S.sub === "quiz") { (T.quiz || []).length ? renderQuiz(box) : box.innerHTML = '<p class="muted">Not enough key terms in this file to make a quiz. Try the flashcards.</p>'; }
  else if (S.sub === "exam") {
    box.innerHTML = `<p class="muted small" style="margin-top:0">Likely questions. Open each one to see what a full-marks answer must include.${aiOn() ? " Use <b>Ask AI tutor</b> to get a full model answer." : ""}</p>` + [...(T.examQuestions || [])].sort((a, b) => a.marks - b.marks).map(q => `<div class="eq"><span class="marks">${esc(q.marks)} M</span><div><b>${fmt(q.q)}</b>${(q.outline || []).length ? `<details><summary>Answer outline</summary><ul class="clean">${q.outline.map(o => `<li>${fmt(o)}</li>`).join("")}</ul></details>` : ""}${aiOn() ? `<button class="btn ghost sm" data-ask="${esc(`Write a ${q.marks}-mark exam answer for: ${q.q}`)}">✨ Model answer</button>` : ""}</div></div>`).join("");
    box.querySelectorAll("[data-ask]").forEach(b => b.onclick = () => { S.sub = "ask"; renderDoc(); askTutor(b.dataset.ask); });
  } else if (S.sub === "terms") { box.innerHTML = `<div class="terms">${(N.keyTerms || []).map(t => `<div class="term"><b>${esc(t.term)}</b><span>${fmt(t.meaning)}</span></div>`).join("")}</div>`; }
  else if (S.sub === "ask") renderAsk(box);
}

/* ---------------- AI tutor ---------------- */
function renderAsk(box) {
  const n = S.current, chat = S.chats[n.id] || (S.chats[n.id] = []);
  const h = n.notes.sections[0]?.heading || n.title, term = n.notes.keyTerms[0]?.term || n.title;
  box.innerHTML = `<p class="small muted" style="margin-top:0">${aiOn() ? `Ask anything about <b>${esc(n.title)}</b>. The free AI on your device answers from your PDF. Nothing leaves your device.` : "The free AI is off, so I'll show you the most relevant parts of your PDF instead. Install free AI (Portal &amp; settings) for real explanations."}</p>
    <div class="chat" id="chat">${chat.map(m => `<div class="msg ${m.me ? "me" : "bot"}">${m.me ? esc(m.t) : fmt(m.t)}${m.src ? `<div class="src">${m.src}</div>` : ""}</div>`).join("")}</div>
    <form class="chat-in" id="ask-f"><input type="text" id="ask-q" placeholder="e.g. Explain ${esc(Engine.shortLabel(h, 5))} simply" autocomplete="off"><button class="btn primary">Ask</button></form>
    ${chat.length ? "" : `<div class="sugg">${[`Explain ${Engine.shortLabel(h, 5)} simply`, `What are the most important points for the exam?`, `Give me a real-life example of ${term}`, `Write a 5-mark answer on ${Engine.shortLabel(h, 5)}`].map(s => `<button data-s="${esc(s)}">${esc(s)}</button>`).join("")}</div>`}`;
  $("#ask-f").onsubmit = e => { e.preventDefault(); const q = $("#ask-q").value.trim(); if (q) askTutor(q); };
  box.querySelectorAll(".sugg button").forEach(b => b.onclick = () => askTutor(b.dataset.s));
}
async function askTutor(q) {
  const n = S.current, chat = S.chats[n.id] || (S.chats[n.id] = []);
  chat.push({ me: true, t: q });
  const bot = { t: aiOn() ? "Thinking…" : "", src: "" }; chat.push(bot); renderDoc();
  const src = await getSource(n.id);
  const notesText = n.example ? JSON.stringify(n.notes).slice(0, 6000) : "";
  const hits = Engine.search(src || notesText, q, 4);
  bot.src = hits.length ? "From your PDF: " + hits.map(h => `“${esc(h.c.slice(0, 110))}…”`).join(" · ") : "";
  if (!aiOn()) { bot.t = hits.length ? hits.slice(0, 3).map(h => h.c.slice(0, 600)).join("\n\n— — —\n\n") : "I couldn't find that in your PDF. Try other words."; bot.src = ""; renderDoc(); return; }
  const ctx = hits.map((h, i) => `[${i + 1}] ${h.c}`).join("\n\n") || (src || notesText).slice(0, 5000);
  const history = chat.slice(-7, -2).map(m => (m.me ? "Student: " : "Tutor: ") + m.t.slice(0, 600)).join("\n");
  try {
    await ai(`You are a friendly B.Tech tutor. Answer the student's question in simple English using the study material below. Use short paragraphs or bullets, **bold** key words, and give a tiny example when helpful. If the material doesn't cover it, say so and answer from general knowledge, clearly marked.
Topic: ${n.title}
${history ? "Earlier chat:\n" + history + "\n" : ""}<material>
${ctx}
</material>
Student: ${q}
Tutor:`, { onText: t => { bot.t = t; const el = $("#chat .msg.bot:last-child"); if (el && S.sub === "ask") el.firstChild.textContent = t; } });
  } catch (e) { bot.t = "The free AI couldn't answer (" + e.message + "). Here's what your PDF says:\n\n" + hits.map(h => h.c.slice(0, 500)).join("\n\n"); }
  if (S.sub === "ask" && S.current?.id === n.id) renderDoc();
}

/* ---------------- flashcards ---------------- */
function renderCards(box) {
  const n = S.current, cards = n.tools.flashcards;
  if (!S.fc.order) S.fc.order = cards.map((_, i) => i);
  const known = n.progress.known, left = S.fc.order.filter(i => !known.includes(i));
  if (!left.length) {
    box.innerHTML = `<div class="card empty"><h3>All ${cards.length} cards known 🎉</h3><p>Nice. Come back tomorrow to keep them fresh.</p><button class="btn" id="fc-reset">Start over</button></div>`;
    $("#fc-reset").onclick = () => { n.progress.known = []; saveProgress(); renderCards(box); }; return;
  }
  const i = left[S.fc.i % left.length], c = cards[i];
  box.innerHTML = `<div class="fc-wrap"><div class="bar" aria-label="${known.length} of ${cards.length} known"><i style="width:${known.length / cards.length * 100}%"></i></div>
    <p class="small muted" style="margin:0"><span class="num">${known.length}/${cards.length}</span> known · ${left.length} to go</p>
    <button class="fc ${S.fc.flip ? "flip" : ""}" id="fc" aria-label="Flip card"><div class="fc-in"><div class="face"><span class="eyebrow">Question</span><div>${fmt(c.q)}</div></div><div class="face back"><span class="eyebrow">Answer</span><div style="white-space:pre-line">${fmt(c.a)}</div></div></div></button>
    <div class="row"><button class="btn" id="fc-again">Again</button><button class="btn primary" id="fc-got">Got it ✓</button><button class="btn ghost" id="fc-shuf">Shuffle</button></div>
    <p class="small muted">Tap the card to flip it. Keyboard: Space flips, → next.</p></div>`;
  $("#fc").onclick = () => { S.fc.flip = !S.fc.flip; $("#fc").classList.toggle("flip", S.fc.flip); };
  $("#fc-again").onclick = () => { S.fc.i++; S.fc.flip = false; renderCards(box); };
  $("#fc-got").onclick = () => { known.push(i); S.fc.flip = false; saveProgress(); renderCards(box); };
  $("#fc-shuf").onclick = () => { S.fc.order.sort(() => Math.random() - .5); S.fc.i = 0; S.fc.flip = false; renderCards(box); };
}
document.addEventListener("keydown", e => {
  if (S.tab !== "notes" || S.sub !== "cards" || /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName)) return;
  if (e.key === " ") { e.preventDefault(); $("#fc")?.click(); } else if (e.key === "ArrowRight") $("#fc-again")?.click(); else if (e.key === "Enter") $("#fc-got")?.click();
});

/* ---------------- quiz ---------------- */
function renderQuiz(box) {
  const n = S.current, qs = n.tools.quiz, ans = n.progress.quiz;
  const done = Object.keys(ans).length, score = qs.filter((q, i) => ans[i] === q.answer).length;
  box.innerHTML = `<div class="row" style="justify-content:space-between;margin-bottom:6px"><b>Score: <span class="num">${score}/${done}</span> answered of ${qs.length}</b><button class="btn ghost" id="qz-reset">Reset quiz</button></div>` +
    qs.map((q, i) => `<div class="q"><b>${i + 1}. ${fmt(q.q)}</b><div class="opts">${q.options.map((o, j) => { const a = ans[i]; let c = ""; if (a !== undefined) { if (j === q.answer) c = "right"; else if (j === a) c = "wrong"; }
      return `<button data-q="${i}" data-o="${j}" class="${c}" ${ans[i] !== undefined ? "disabled" : ""}>${"ABCD"[j]}. ${fmt(o)}</button>`; }).join("")}</div>${ans[i] !== undefined ? `<p class="why">${ans[i] === q.answer ? "✓ Correct." : "✗ Not quite."} ${fmt(q.why)}</p>` : ""}</div>`).join("");
  box.querySelectorAll(".opts button").forEach(b => b.onclick = () => { ans[b.dataset.q] = +b.dataset.o; saveProgress(); renderQuiz(box); });
  $("#qz-reset").onclick = () => { n.progress.quiz = {}; saveProgress(); renderQuiz(box); };
}

/* ---------------- mind map ---------------- */
const MM = { root: null, collapsed: new Set(), s: 1, x: 0, y: 0, nodes: [] };
const mctx = document.createElement("canvas").getContext("2d");
const cssVar = v => getComputedStyle(document.documentElement).getPropertyValue(v);
const FONTS = () => ["800 17px " + cssVar("--f-display"), "700 14.5px " + cssVar("--f-body"), "400 13.5px " + cssVar("--f-body")];
const clip = s => { s = String(s || ""); return s.length > 42 ? s.slice(0, 40) + "…" : s; };
function mmInit(root) {
  MM.root = root; MM.collapsed = new Set(); mmDraw();
  const svg = $("#mmsvg"); let drag = null, moved = 0;
  svg.onpointerdown = e => { drag = { x: e.clientX, y: e.clientY }; moved = 0; svg.setPointerCapture(e.pointerId); };
  svg.onpointermove = e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; moved += Math.abs(dx) + Math.abs(dy); if (moved > 4) svg.classList.add("drag"); MM.x += dx; MM.y += dy; drag = { x: e.clientX, y: e.clientY }; mmApply(); };
  svg.onpointerup = e => { svg.classList.remove("drag"); const was = drag; drag = null;
    if (was && moved <= 4) { const t = document.elementFromPoint(e.clientX, e.clientY)?.closest("[data-p]"); if (t && t.dataset.p !== "r") { const p = t.dataset.p; MM.collapsed.has(p) ? MM.collapsed.delete(p) : MM.collapsed.add(p); mmDraw(false); } } };
  svg.addEventListener("wheel", e => { e.preventDefault(); mmZoom(e.deltaY < 0 ? 1.12 : 1 / 1.12, e.offsetX, e.offsetY); }, { passive: false });
  $("#mm-in").onclick = () => mmZoom(1.2); $("#mm-out").onclick = () => mmZoom(1 / 1.2); $("#mm-fit").onclick = mmFit;
  $("#mm-fs").onclick = () => { const m = $("#mm"); const p = document.fullscreenElement ? document.exitFullscreen() : m.requestFullscreen?.(); p?.then?.(() => setTimeout(mmFit, 120)).catch(() => { }); };
  requestAnimationFrame(mmFit);
}
function mmZoom(f, cx, cy) { const svg = $("#mmsvg"); if (!svg) return; const r = svg.getBoundingClientRect(); cx ??= r.width / 2; cy ??= r.height / 2;
  const ns = Math.min(3, Math.max(.2, MM.s * f)); f = ns / MM.s; MM.x = cx - (cx - MM.x) * f; MM.y = cy - (cy - MM.y) * f; MM.s = ns; mmApply(); }
function mmApply() { const g = $("#mmg"); if (g) g.setAttribute("transform", `translate(${MM.x},${MM.y}) scale(${MM.s})`); }
function mmFit() { const svg = $("#mmsvg"); if (!svg || !MM.nodes.length) return; const r = svg.getBoundingClientRect(); if (!r.width) return;
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; MM.nodes.forEach(n => { x0 = Math.min(x0, n.x - 18); x1 = Math.max(x1, n.x + n.w + 18); y0 = Math.min(y0, n.y - n.h / 2); y1 = Math.max(y1, n.y + n.h / 2); });
  MM.s = Math.min(1.3, Math.min((r.width - 40) / (x1 - x0), (r.height - 60) / (y1 - y0))); MM.x = r.width / 2 - (x0 + x1) / 2 * MM.s; MM.y = r.height / 2 - (y0 + y1) / 2 * MM.s + 6; mmApply(); }
function mmDraw(fit) {
  const root = MM.root; if (!root) return; MM.nodes = []; const F = FONTS();
  const GAP = [54, 38, 26], ROW = 10;
  function build(n, depth, path, branch) { const d = Math.min(depth, 2); mctx.font = F[d]; const label = clip(n.label);
    const kids = (n.children || []).filter(c => c && c.label);
    const node = { label, full: n.label, depth, path, branch, w: mctx.measureText(label).width + (d === 0 ? 40 : d === 1 ? 28 : 16), h: d === 0 ? 46 : d === 1 ? 34 : 26, nKids: kids.length, kids: [] };
    if (!MM.collapsed.has(path)) node.kids = kids.map((c, i) => build(c, depth + 1, path + "." + i, depth === 0 ? i : branch)); return node; }
  const R = build(root, 0, "r", 0);
  const leaves = n => n.kids.length ? n.kids.reduce((s, k) => s + leaves(k), 0) : 1;
  const total = R.kids.reduce((s, k) => s + leaves(k), 0); let acc = 0; const right = [], left = [];
  R.kids.forEach(k => { (acc < total / 2 ? right : left).push(k); acc += leaves(k); }); if (!left.length && right.length > 3) left.push(right.pop());
  R.x = -R.w / 2; R.y = 0; R.side = 0;
  function lay(n, x, side, cur) { n.x = x; n.side = side; const g = GAP[Math.min(n.depth, 2)];
    if (n.kids.length) { n.kids.forEach(k => lay(k, side > 0 ? x + n.w + g : x - g - k.w, side, cur)); n.y = (n.kids[0].y + n.kids[n.kids.length - 1].y) / 2; }
    else { n.y = cur.v + n.h / 2; cur.v += n.h + ROW; } }
  function shift(n, dy) { n.y += dy; n.kids.forEach(k => shift(k, dy)); }
  [[right, 1], [left, -1]].forEach(([arr, side]) => { const cur = { v: 0 }; arr.forEach(k => { lay(k, side > 0 ? R.x + R.w + GAP[0] : R.x - GAP[0] - k.w, side, cur); cur.v += ROW * 1.6; }); const h = cur.v; arr.forEach(k => shift(k, -h / 2 + ROW)); });
  const edges = [];
  (function walk(n, parent) { MM.nodes.push(n); if (parent) edges.push([parent, n]); n.kids.forEach(k => walk(k, n)); })(R, null);
  const col = b => `var(--b${(b % 6) + 1})`;
  const E = edges.map(([p, c]) => { const s = c.side, x1 = s > 0 ? p.x + p.w : p.x, y1 = p.y, x2 = s > 0 ? c.x : c.x + c.w, y2 = c.y, mx = (x1 + x2) / 2;
    return `<path d="M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}" fill="none" stroke="${col(c.branch)}" stroke-width="${[0, 4, 2.6, 1.7][Math.min(c.depth, 3)]}" stroke-linecap="round" opacity="${c.depth > 2 ? .7 : 1}"/>`; }).join("");
  const Nd = MM.nodes.map(n => { const d = Math.min(n.depth, 2), c = col(n.branch), cls = d === 0 ? "n-root" : d === 1 ? "n1" : "n2";
    const fill = d === 0 ? "" : d === 1 ? `fill="color-mix(in srgb, ${c} 16%, var(--surface))" stroke="${c}" stroke-width="1.5"` : `fill="color-mix(in srgb, ${c} 7%, var(--surface))" stroke="none"`;
    const tog = n.nKids && d > 0 ? (() => { const cx = n.side > 0 ? n.x + n.w + 9 : n.x - 9, open = !MM.collapsed.has(n.path); return `<g class="tog" data-p="${n.path}"><circle cx="${cx}" cy="${n.y}" r="8" stroke="${c}"/><text x="${cx}" y="${n.y + 3.5}" text-anchor="middle">${open ? "−" : n.nKids}</text></g>`; })() : "";
    return `<g class="node ${cls}" data-p="${n.path}"><title>${esc(n.full)}</title><rect x="${n.x}" y="${n.y - n.h / 2}" width="${n.w}" height="${n.h}" rx="${n.h / 2}" ${fill}/><text x="${n.x + n.w / 2}" y="${n.y + (d === 0 ? 6 : 5)}" text-anchor="middle">${esc(n.label)}</text></g>${tog}`; }).join("");
  $("#mmg").innerHTML = E + Nd; mmApply(); if (fit !== false) mmFit();
}

/* ---------------- export ---------------- */
function toMd(n) {
  const N = n.notes, T = n.tools || {}; const L = [];
  L.push(`# ${n.title}`, "", `*${n.subject || "No subject"}, from ${n.source}, made ${new Date(n.createdAt || Date.now()).toLocaleDateString()}*`, "", "## TL;DR", N.tldr || "", "");
  if (N.eli5) L.push("## Explain like I'm 5", N.eli5, "");
  L.push("## Must-remember", ...(N.summary || []).map(s => "- " + s), "");
  (N.sections || []).forEach(s => { L.push("## " + s.heading, ...s.points.map(p => "- " + p)); (s.subs || []).forEach(x => L.push("", "### " + x.heading, ...x.points.map(p => "- " + p)));
    if (s.formula) L.push("", "```", s.formula, "```"); if (s.example) L.push("", "**Example:** " + s.example); if (s.examTip) L.push("", "> **Exam tip:** " + s.examTip); L.push(""); });
  L.push("## Mind map", "", "```mermaid", "mindmap", `  root((${(N.mindmap?.label || n.title).replace(/[()\[\]{}]/g, "")}))`);
  (function w(c, d) { (c || []).forEach(k => { L.push("  ".repeat(d) + k.label.replace(/[()\[\]{}]/g, "")); w(k.children, d + 1); }); })(N.mindmap?.children, 2);
  L.push("```", "", "## Key terms", ...(N.keyTerms || []).map(t => `- **${t.term}**: ${t.meaning}`), "");
  if ((T.flashcards || []).length) L.push("## Flashcards", ...T.flashcards.map(c => `- **Q:** ${c.q}  \n  **A:** ${c.a.replace(/\n/g, " ")}`), "");
  if ((T.quiz || []).length) L.push("## Quiz", ...T.quiz.map((q, i) => `${i + 1}. ${q.q}\n${q.options.map((o, j) => `   - ${"ABCD"[j]}. ${o}`).join("\n")}\n   - **Answer:** ${"ABCD"[q.answer]}. ${q.why}`), "");
  if ((T.examQuestions || []).length) L.push("## Exam questions", ...T.examQuestions.map(q => `- **[${q.marks} M]** ${q.q}${(q.outline || []).length ? "\n" + q.outline.map(o => "  - " + o).join("\n") : ""}`), "");
  if ((T.mnemonics || []).length) L.push("## Memory tricks", ...T.mnemonics.map(m => "- " + m), "");
  return L.join("\n");
}
function exportMd() {
  const n = S.current, blob = new Blob([toMd(n)], { type: "text/markdown" }), a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = (n.title || "notes").replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "-") + ".md"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

/* =========================================================
   PLANNER (exams, marks, attendance)
   ========================================================= */
let planTimer = null, saving = false;
function touch() { if (P().example) P().example = false; clearTimeout(planTimer); saving = true;
  planTimer = setTimeout(() => api("/api/planner", "PUT", P()).then(r => { if (r && r.rev) S.rev = r.rev; }).catch(() => { }).finally(() => { saving = false; }), 600); renderStrip(); }
/* exams and calendar dates: added/removed one by one on the server, so another open window can't wipe them */
async function listAdd(kind, items) { if (!items.length) return; const r = await api(`/api/planner/${kind}`, "POST", { items }); P()[kind] = r.items; S.rev = r.rev; }
async function listDel(kind, id) { const r = await api(`/api/planner/${kind}/${encodeURIComponent(id)}`, "DELETE"); P()[kind] = r.items; S.rev = r.rev; }
async function listClear(kind) { const r = await api(`/api/planner/${kind}`, "DELETE"); P()[kind] = r.items; S.rev = r.rev; }
/* keep every open window (PC, phone, tablet) in step: reload when another window saved something */
async function pullPlanner(force) {
  if (!force && (saving || document.hidden || /INPUT|SELECT|TEXTAREA/.test(document.activeElement?.tagName))) return;
  const r = await api("/api/planner/rev").catch(() => null); if (!r || r.rev <= (S.rev || 0)) return;
  const p = await api("/api/planner").catch(() => null); if (!p) return;
  S.planner = Object.assign({ hours: 3, planDone: {} }, p); S.rev = p.rev || 0;
  renderPlanner(); if (S.tab === "cal") renderCal(); if (S.tab === "mirror") renderMirror(); if (!S.homeEdit) buildPager();
}
setInterval(pullPlanner, 5000);
window.addEventListener("focus", () => pullPlanner(true));
function exampleBanner(what) { return P().example ? `<div class="banner"><span class="chip ex">Example data</span><span>These ${what} are made up so you can see how it works. Edit them, sync from your portal, or clear them and add your own.</span><button class="btn" onclick="clearExamples()">Clear examples</button></div>` : ""; }
window.clearExamples = () => { const p = P(); p.exams = []; listClear("exams").catch(() => { }); listClear("events").catch(() => { }); p.sems = [{ id: uid(), name: "Sem 1", subs: [{ n: "", cr: 4, io: null, im: 70 }] }]; p.cur = 0; p.att.subs = []; p.planDone = {}; p.example = false; touch(); renderPlanner(); };
function renderPlanner() { renderStrip(); renderExams(); renderMarks(); renderLib(); if (S.tab === "home") renderHome(); }
function keepFocus(fn) { const id = document.activeElement?.id; fn(); if (id) { const el = document.getElementById(id); if (el) el.focus(); } }

/* exams */
function daysLeft(e) { const today = new Date(); today.setHours(0, 0, 0, 0); const d = new Date(e.date + "T00:00"), end = new Date(e.date + "T" + (e.time || "23:59")); return { days: Math.round((d - today) / DAY), past: end < new Date() }; }
const urgency = d => d <= 3 ? "bad" : d <= 7 ? "warn" : "";
// default end-sem timetable (Odd Sem 2026-27): each student sees their own programme + semester + branch until they add their own end-sems
S.defEx = null;
fetch("/default-exams.json", { cache: "no-cache" }).then(r => r.ok ? r.json() : null).then(d => { if (!d) return; S.defEx = d; renderPlanner(); if (S.tab === "home") renderHome(); }).catch(() => { });
const BRANCH = b => { const x = String(b || "").toUpperCase().replace(/[^A-Z]/g, ""); return x === "AID" || x === "AIDS" || x === "AIANDDS" ? "AIDS" : x === "VLSI" || x === "VL" ? "VLSI" : x; };
function myEndsem() {
  const pr = profile(), m = me(), br = BRANCH(pr.branch);
  if (!S.defEx || !br || P().example) return [];
  const prog = /m\.?\s*tech/i.test(pr.programme || "") ? "mtech" : "btech";
  const sem = m.semNo || (pr.batch ? semesterNow(pr.batch) : 0), hidden = new Set(P().endHidden || []);
  const rows = S.defEx.exams.filter(e => e.prog === prog && e.sem === sem && e.branches.includes(br));
  const tail = c => String(c).replace(/^\d{2}/, ""), mine = new Set(m.codes.map(tail)), out = [];   // 19ENG230 on the portal = 23ENG230 on the timetable
  const byDate = {}; rows.forEach(r => (byDate[r.date + r.start] ||= []).push(r));
  Object.values(byDate).forEach(g => {
    // electives: show only the one in your course list; if none is known yet, one entry listing the choices
    const pick = g.length > 1 ? (g.filter(r => mine.has(tail(r.code))).length ? g.filter(r => mine.has(tail(r.code))) : null) : g;
    const list = pick || [{ ...g[0], code: g.map(r => r.code).join(" / "), name: "Elective: " + g.map(r => r.name).join(" / ") }];
    list.forEach(r => { const own = m.names[m.codes.map(tail).indexOf(tail(r.code))];
      out.push({ id: "end-" + r.date + "-" + r.code, sub: own || r.name, type: "End-sem", date: r.date, time: r.start, syl: `${r.code} · ${r.start}–${r.end}`, fromDefault: true }); });
  });
  const own = P().exams.filter(x => /end/i.test(x.type));
  return own.length ? [] : out.filter(x => !hidden.has(x.id));
}
const allExams = () => [...P().exams, ...myEndsem()];
function upcoming() { return allExams().map(e => ({ ...e, ...daysLeft(e) })).filter(e => !e.past).sort((a, b) => (a.date + (a.time || "")).localeCompare(b.date + (b.time || ""))); }
function renderStrip() {   // the "Next up" bar was removed; kept as a no-op so callers stay simple
  const up = upcoming(), st = $("#strip"); if (!st) return;
  if (!up.length) { st.innerHTML = `<span class="lbl">Next up</span><span class="muted">No exams added. Add them in the Exams tab or sync your portal.</span>`; return; }
  st.innerHTML = `<span class="lbl">Next up${P().example ? " (example)" : ""}</span>` + up.slice(0, 5).map(e => `<span class="chip ${urgency(e.days)}">${e.days === 0 ? "TODAY" : e.days === 1 ? "Tomorrow" : e.days + " days"} · ${esc(e.sub)} ${esc(e.type)}</span>`).join("");
}
function renderExams() {
  const all = allExams().map(e => ({ ...e, ...daysLeft(e) })).sort((a, b) => a.past - b.past || a.date.localeCompare(b.date));
  $("#ex-banner").innerHTML = exampleBanner("exams") + (all.some(e => e.fromDefault) ? `<div class="attnote"><b>Note:</b> your end-sem dates are filled in from the college end-semester timetable (${esc(profile().branch || "")}, Sem ${me().semNo || semesterNow(profile().batch)}). Add your own end-sem to replace them.</div>` : "");
  $("#ex-count").textContent = all.length ? `${all.filter(e => !e.past && e.days <= 7).length} in the next 7 days` : "";
  $("#exam-list").innerHTML = all.length ? all.map(e => {
    const notes = S.notes.filter(n => n.subject && n.subject.toLowerCase() === e.sub.toLowerCase()).length;
    return `<div class="exam ${e.past ? "past" : ""}">
     <div class="days ${e.past ? "" : urgency(e.days)}"><b class="num">${e.past ? "✓" : e.days}</b><small>${e.past ? "done" : e.days === 1 ? "day" : "days"}</small></div>
     <div style="min-width:0"><b>${esc(e.sub)}</b> <span class="chip">${esc(e.type)}</span>${notes ? ` <span class="chip">${notes} note${notes > 1 ? "s" : ""}</span>` : ""}<div class="small muted">${new Date(e.date + "T00:00").toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" })}${e.time ? " · " + esc(e.time) : ""}${e.syl ? " · " + esc(e.syl) : ""}</div>
       ${!e.past && e.days <= 3 ? `<div class="small" style="color:var(--bad);font-weight:700">${e.days === 0 ? "It's today. Quick revision only, no new topics." : "Revise with your flashcards and exam questions."}</div>` : ""}</div>
     <button class="btn ghost" data-del="${e.id}" aria-label="Remove ${esc(e.sub)}">✕</button></div>`; }).join("") : `<div class="empty">No exams yet. Add your first one →</div>`;
  $$("#exam-list [data-del]").forEach(b => b.onclick = async () => {
    if (b.dataset.del.startsWith("end-")) { const p = P(); p.endHidden = [...(p.endHidden || []), b.dataset.del]; touch(); }
    else await listDel("exams", b.dataset.del).catch(() => { });
    renderExams(); renderStrip(); });
}
$("#ex-form").onsubmit = async e => { e.preventDefault();
  const ex = { id: uid(), sub: $("#ex-sub").value.trim(), type: $("#ex-type").value, date: $("#ex-date").value, time: $("#ex-time").value, syl: $("#ex-syl").value.trim() };
  try { await listAdd("exams", [ex]); e.target.reset(); } catch (err) { alertMsg = err.message; }
  renderExams(); renderStrip(); renderLib(); };
let alertMsg = "";

/* marks: grades + SGPA/CGPA calculator (end-sem marks are confidential; only grades are published) */
const GP = {
  amrita: [["O", 10], ["A+", 9.5], ["A", 9], ["B+", 8], ["B", 7], ["C", 6], ["P", 5], ["F", 0]],
  ugc: [["O", 10], ["A+", 9], ["A", 8], ["B+", 7], ["B", 6], ["C", 5], ["P", 4], ["F", 0]],
  sabc: [["S", 10], ["A", 9], ["B", 8], ["C", 7], ["D", 6], ["E", 5], ["F", 0]],
};
const scaleOf = () => GP[P().scale] || GP.amrita;
const gpOf = l => { const g = scaleOf().find(x => x[0] === l); return g ? g[1] : null; };
function subCalc(s) {
  const pct = nz(s.io) !== null && +s.im ? s.io / s.im * 100 : null;
  const gp = s.grade ? gpOf(s.grade) : null;
  return { graded: gp !== null, gp, l: s.grade || null, pct, state: gp !== null ? "done" : pct !== null ? "pending" : "empty" };
}
function semCalc(sem, whatIf) {
  let cr = 0, pts = 0, pending = 0;
  sem.subs.forEach(s => { const c = subCalc(s), w = +s.cr || 0;
    const gp = c.graded ? c.gp : whatIf && s.whatIf ? gpOf(s.whatIf) : null;
    if (gp !== null && w) { cr += w; pts += w * gp; } else if (!c.graded) pending++; });
  return { cr, pts, sgpa: cr ? pts / cr : null, pending };
}
function renderMarks() {
  const p = P(); if (!GP[p.scale]) p.scale = "amrita"; $("#scale").value = p.scale; $("#mk-banner").innerHTML = exampleBanner("marks");
  if (p.cur >= p.sems.length) p.cur = p.sems.length - 1; const sem = p.sems[p.cur];
  $("#semtabs").innerHTML = p.sems.map((s, i) => `<button data-i="${i}" aria-selected="${i === p.cur}">${esc(s.name)}</button>`).join("");
  $$("#semtabs button").forEach(b => b.onclick = () => { p.cur = +b.dataset.i; touch(); renderMarks(); });
  const all = p.sems.map(s => semCalc(s, false)), allW = p.sems.map(s => semCalc(s, true));
  const sum = (a, k) => a.reduce((n, x) => n + x[k], 0);
  const cgpa = sum(all, "cr") ? sum(all, "pts") / sum(all, "cr") : null, cgpaW = sum(allW, "cr") ? sum(allW, "pts") / sum(allW, "cr") : null;
  const sc = all[p.cur], scW = allW[p.cur], off = p.official || {};
  const cur = sem.subs.map(subCalc);
  const weakest = sem.subs.map((s, i) => ({ s, c: cur[i] })).filter(x => !x.c.graded && x.c.pct !== null).sort((a, b) => a.c.pct - b.c.pct)[0];
  const fails = p.sems.reduce((n, s) => n + s.subs.filter(x => x.grade === "F").length, 0);
  $("#mk-stats").innerHTML = `<div class="stat"><span class="eyebrow">CGPA</span><b class="num">${off.cgpa ? off.cgpa : cgpa ? cgpa.toFixed(2) : "—"}</b><span class="small muted">${off.cgpa ? "official (AUMS)" : sum(all, "cr") + " credits graded"}${cgpaW && cgpaW !== cgpa ? ` · with what-ifs <b>${cgpaW.toFixed(2)}</b>` : ""}</span></div>
    <div class="stat"><span class="eyebrow">${esc(sem.name)} SGPA</span><b class="num">${off.sgpa?.[sem.name] || (sc.sgpa ? sc.sgpa.toFixed(2) : scW.sgpa ? "≈" + scW.sgpa.toFixed(2) : "—")}</b><span class="small muted">${sc.pending ? (scW.sgpa && !sc.sgpa ? "predicted from your what-if grades" : `${sc.pending} course${sc.pending > 1 ? "s" : ""} without a grade yet`) : "all graded"}</span></div>
    <div class="stat"><span class="eyebrow">Weakest internal now</span><b style="font-size:1.2rem">${weakest ? esc(weakest.s.n) : "—"}</b><span class="small muted">${weakest ? weakest.c.pct.toFixed(0) + "% of internal so far" : ""}</span></div>
    <div class="stat"><span class="eyebrow">Backlogs (F)</span><b class="num" style="color:${fails ? "var(--bad)" : "var(--good)"}">${fails}</b><span class="small muted">${fails ? "clear these first" : "none, keep it up"}</span></div>`;
  const letters = scaleOf().map(x => x[0]);
  const opt = (v, cur) => `<option value="">—</option>${letters.map(l => `<option ${cur === l ? "selected" : ""}>${l}</option>`).join("")}`;
  $("#mk-body").innerHTML = sem.subs.map((s, i) => { const c = cur[i], id = k => `m-${sem.id}-${i}-${k}`;
    return `<tr><td><input type="text" id="${id("n")}" data-i="${i}" data-k="n" value="${esc(s.n)}" placeholder="Course">${s.portal ? `<div class="small muted">${esc(s.code || "")} · myAmrita · ${esc(s.raw || "")}${s.projected ? " · projected" : ""}</div>` : ""}</td>
     <td><input type="number" id="${id("cr")}" data-i="${i}" data-k="cr" value="${s.cr ?? ""}" min="0" max="10" step="0.5"></td>
     <td>${s.portal ? `<select id="${id("mid")}" data-i="${i}" data-k="midW">${[30, 40].map(v => `<option value="${v}" ${(+s.midW || 30) === v ? "selected" : ""}>${v}</option>`).join("")}</select>` : '<span class="muted small">—</span>'}</td>
     <td><input type="number" id="${id("im")}" data-i="${i}" data-k="im" value="${s.im ?? ""}" min="0" max="100"></td>
     <td class="num">${c.pct !== null ? `${(+s.io).toFixed(1)} <span class="muted small">(${c.pct.toFixed(0)}%)</span>` : `<input type="number" id="${id("io")}" data-i="${i}" data-k="io" value="${s.io ?? ""}" min="0" placeholder="—">`}</td>
     <td><select id="${id("gr")}" data-i="${i}" data-k="grade" title="${s.gradeSrc === "aums" ? "From AUMS" : "Set by you"}">${opt("", s.grade)}</select>${s.gradeSrc === "aums" ? '<div class="small muted">AUMS</div>' : ""}</td>
     <td>${c.graded ? '<span class="muted small">—</span>' : `<select id="${id("wi")}" data-i="${i}" data-k="whatIf">${opt("", s.whatIf)}</select>`}</td>
     <td><button class="btn ghost" data-rm="${i}" aria-label="Remove course">✕</button></td></tr>`; }).join("") || '<tr><td colspan="8" class="muted small">No courses yet. Sync myAmrita, get grades from AUMS, or add a course.</td></tr>';
  $$("#mk-body input, #mk-body select").forEach(el => el.onchange = () => {
    const s = sem.subs[el.dataset.i], k = el.dataset.k;
    s[k] = el.tagName === "SELECT" && k !== "midW" ? (el.value || null) : el.type === "number" || k === "midW" ? nz(el.value) : el.value;
    if (k === "grade") s.gradeSrc = s.grade ? "you" : null;
    if (k === "cr") s.crSet = true;   // a credit you typed wins over AUMS
    if (k === "im" || k === "midW") { s.wSet = true; if (s.portal) s.io = Portal.internal(s); }
    touch(); keepFocus(renderMarks);
  });
  $$("#mk-body [data-rm]").forEach(b => b.onclick = () => { sem.subs.splice(+b.dataset.rm, 1); touch(); renderMarks(); });
  // internal marks from the Marks section (your conversions), not the raw site internal
  const conv = buildMarksCourses(S.mirror, sem.name).courses.map(c => ({ c, ci: convInternal(c) })).filter(x => x.ci).sort((a, b) => a.ci.got / a.ci.max - b.ci.got / b.ci.max);
  $("#mk-chart").innerHTML = conv.length ? `<div class="bars">${conv.map(({ c, ci }) => { const v = ci.max ? ci.got / ci.max * 100 : 0, col = v < 50 ? "var(--bad)" : v < 70 ? "var(--warn)" : v >= 85 ? "var(--good)" : "var(--accent)";
      return `<div class="brow nobar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(c.course)}">${esc(c.course)}</span><span class="num" style="white-space:nowrap;color:${col}"><b>${+ci.got.toFixed(1)}</b> / ${+ci.max.toFixed(0)} · <b>${v.toFixed(0)}%</b></span></div>`; }).join("")}</div>
     <p class="small muted" style="margin-bottom:0">Internal marks from your conversions in the Marks section. Tap a subject in Marks to change its conversion.</p>` : `<p class="muted">Internal marks appear here after a myAmrita sync. Set conversions in the Marks section.</p>`;
  // calculator
  const T = +p.target || 0, nc = +p.nextCr || 20, tc = sum(allW, "cr"), tp = sum(allW, "pts"), req = tc ? (T * (tc + nc) - tp) / nc : T;
  const trend = p.sems.map((s, i) => ({ n: s.name, v: +(off.sgpa?.[s.name]) || all[i].sgpa })).filter(x => x.v);
  $("#mk-target").innerHTML = `<p class="small" style="margin:8px 0">Pick a <b>what-if grade</b> for each course without a grade. The SGPA and CGPA above update straight away.</p>
    <div class="row" style="margin:10px 0"><button class="btn sm" id="wi-all-a">Set all what-ifs to A</button><button class="btn sm" id="wi-all-o">to O</button><button class="btn ghost sm" id="wi-clear">Clear what-ifs</button></div>
    <div class="row" style="margin:10px 0"><label for="tg" class="small">Target CGPA</label><input type="number" id="tg" step="0.1" min="0" max="10" value="${T}"><label for="tgc" class="small">Credits next sem</label><input type="number" id="tgc" min="1" value="${nc}"></div>
    <p style="margin:0 0 10px">${!tc ? "Add credits and grades first." : req > 10 ? `<span class="err">${T} isn't reachable next semester (you'd need ${req.toFixed(2)}). Aim for it over two semesters.</span>` : req <= 0 ? `You're already above ${T}. Just don't drop.` : `To reach a CGPA of ${T}, you need an SGPA of <b class="num" style="font-size:1.3rem">${req.toFixed(2)}</b> next semester.`}</p>
    ${trend.length > 1 ? sparkline(trend) : '<p class="small muted">The SGPA trend appears once two semesters have grades.</p>'}`;
  const setAll = v => { sem.subs.forEach(s => { if (!subCalc(s).graded) s.whatIf = v; }); touch(); renderMarks(); };
  $("#wi-all-a").onclick = () => setAll(letters.includes("A") ? "A" : letters[1]); $("#wi-all-o").onclick = () => setAll(letters[0]); $("#wi-clear").onclick = () => setAll(null);
  $("#tg").onchange = e => { p.target = nz(e.target.value); touch(); keepFocus(renderMarks); }; $("#tgc").onchange = e => { p.nextCr = nz(e.target.value); touch(); keepFocus(renderMarks); };
  // Percentages / Calculator switch (like the gate pass buttons)
  const gv = S.gradesView || "percent";
  if ($("#card-percent")) $("#card-percent").hidden = gv !== "percent";
  if ($("#card-calc")) $("#card-calc").hidden = gv !== "calc";
  $$("#grades-switch [data-gview]").forEach(b => { b.classList.toggle("primary", b.dataset.gview === gv); b.onclick = () => { S.gradesView = b.dataset.gview; renderMarks(); }; });
}
function sparkline(pts) { const W = 300, H = 90, pad = 24, lo = Math.max(0, Math.floor(Math.min(...pts.map(p => p.v)) - 1)), hi = 10;
  const x = i => pad + i * (W - 2 * pad) / (pts.length - 1), y = v => H - 18 - (v - lo) / (hi - lo) * (H - 32);
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:${W}px;height:auto" role="img" aria-label="SGPA trend"><path d="M${pts.map((p, i) => x(i) + "," + y(p.v)).join(" L")}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>
   ${pts.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.v)}" r="${i === pts.length - 1 ? 5 : 3.5}" fill="var(--accent)"/><text x="${x(i)}" y="${y(p.v) - 9}" text-anchor="middle" font-size="11" fill="var(--ink)" font-family="JetBrains Mono, monospace">${p.v.toFixed(2)}</text><text x="${x(i)}" y="${H - 3}" text-anchor="middle" font-size="10" fill="var(--muted)">${esc(p.n)}</text>`).join("")}</svg>`; }
$("#scale").onchange = e => { P().scale = e.target.value; touch(); renderMarks(); };
$("#mk-add").onclick = () => { P().sems[P().cur].subs.push({ n: "", cr: 3, io: null, im: 70 }); touch(); renderMarks(); };
$("#sem-add").onclick = () => { const p = P(); p.sems.push({ id: uid(), name: "Sem " + (p.sems.length + 1), subs: [{ n: "", cr: 4, io: null, im: 70 }] }); p.cur = p.sems.length - 1; touch(); renderMarks(); };
$("#sem-del").onclick = e => { const b = e.currentTarget, p = P(); if (p.sems.length < 2) { b.textContent = "Need at least one semester"; return; }
  if (!b.dataset.armed) { b.dataset.armed = 1; b.textContent = "Click again to delete " + p.sems[p.cur].name; return; }
  delete b.dataset.armed; b.textContent = "Delete this semester"; p.sems.splice(p.cur, 1); p.cur = Math.max(0, p.cur - 1); touch(); renderMarks(); };

/* attendance */
function attCalc(s, min) { const a = +s.a || 0, t = +s.t || 0, m = min / 100; const pct = t ? a / t * 100 : 100;
  if (pct >= min) return { pct, ok: true, n: Math.floor(a / m - t) }; return { pct, ok: false, n: Math.ceil((m * t - a) / (1 - m)) }; }

/* =========================================================
   TODAY: smart plan
   ========================================================= */
const TYPE_W = { "End-sem": 3, "Mid-sem": 2, "Lab exam": 1.5, "Project": 1.5, "Assignment": 1.2, "Quiz": 1, "Viva": 1, "Exam": 2 };
function buildPlan() {
  const p = P(), hours = +p.hours || 3, slots = Math.max(1, Math.round(hours * 60 / 50));
  const ups = upcoming().filter(e => e.days <= 21);
  const sem = p.sems[p.cur] || { subs: [] };
  const weak = name => { const s = sem.subs.find(x => x.n && x.n.toLowerCase() === name.toLowerCase()); const c = s ? subCalc(s) : null; return c && c.pct !== null ? Math.max(0, 1 - c.pct / 100) : .4; };
  const days = [];
  for (let d = 0; d < 7; d++) {
    const date = inDays(d), pri = new Map(), why = new Map();
    ups.forEach(e => { const left = e.days - d; if (left < 0) return; const w = (TYPE_W[e.type] || 1.5) / (left + 1) + weak(e.sub) * .35; pri.set(e.sub, (pri.get(e.sub) || 0) + w); if (!why.has(e.sub) || left < why.get(e.sub).left) why.set(e.sub, { left, e }); });
    if (!pri.size) sem.subs.filter(s => s.n).forEach(s => pri.set(s.n, weak(s.n) * .5 + .05));
    const top = [...pri.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
    const total = top.reduce((s, [, v]) => s + v, 0) || 1;
    let alloc = top.map(([sub, v]) => ({ sub, n: Math.floor(v / total * slots), r: (v / total * slots) % 1 }));
    let left = slots - alloc.reduce((s, a) => s + a.n, 0);
    alloc.sort((a, b) => b.r - a.r).forEach(a => { if (left > 0) { a.n++; left--; } });
    alloc = alloc.filter(a => a.n > 0).sort((a, b) => (pri.get(b.sub) || 0) - (pri.get(a.sub) || 0));
    const tasks = [];
    alloc.forEach(a => {
      const w = why.get(a.sub), note = S.notes.find(n => n.subject && n.subject.toLowerCase() === a.sub.toLowerCase());
      for (let k = 0; k < a.n; k++) {
        let what;
        if (!w) what = `Strengthen ${a.sub}: re-read notes and do 5 practice questions`;
        else if (w.left === 0) what = w.e.type === "Assignment" ? `Submit the ${a.sub} assignment` : `${a.sub} ${w.e.type} today: quick checklist only, no new topics`;
        else if (w.e.type === "Assignment" || w.e.type === "Project") what = `Work on ${a.sub} ${w.e.type.toLowerCase()} (due in ${w.left} day${w.left > 1 ? "s" : ""})`;
        else if (w.left === 1) what = k === 0 ? `Final revision of ${a.sub}: flashcards + key terms` : `Solve ${a.sub} exam questions (timed)`;
        else if (w.left <= 3) what = k % 2 ? `Practise ${a.sub} 5- and 10-mark questions` : `Revise ${a.sub} with the mind map and flashcards`;
        else what = k === 0 ? `Learn new ${a.sub} topics${w.e.syl ? " (" + w.e.syl + ")" : ""}` : `Make notes from a ${a.sub} PDF, then quiz yourself`;
        tasks.push({ key: `${date}|${a.sub}|${k}`, sub: a.sub, what, note: note?.id });
      }
    });
    days.push({ date, d, tasks });
  }
  return days;
}
function renderPlan() {
  const p = P(); $("#plan-hours").value = p.hours || 3;
  const days = buildPlan(), colors = new Map(); let ci = 0;
  const color = s => { if (!colors.has(s)) colors.set(s, `var(--b${(ci++ % 6) + 1})`); return colors.get(s); };
  p.planDone = p.planDone || {};
  $("#plan-days").innerHTML = (P().example ? exampleBanner("plans (based on the example exams)") : "") + days.map(day => {
    const dt = new Date(day.date + "T00:00");
    const lbl = day.d === 0 ? "Today" : day.d === 1 ? "Tomorrow" : dt.toLocaleDateString(undefined, { weekday: "long" });
    let t0 = 0;
    const hol = (P().events || []).filter(e => e.start <= day.date && (e.end || e.start) >= day.date);
    return `<div class="card day"><h3>${lbl} <span class="small muted">${dt.toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span>${hol.map(e => ` <span class="tag t-${e.type}" style="font-size:.7rem;font-family:var(--f-body)">${esc(e.title)}</span>`).join("")}</h3>
      ${day.tasks.length ? day.tasks.map(t => { const slot = `${Math.floor(t0 / 60)}h${String(t0 % 60).padStart(2, "0")}`; t0 += 50; const done = p.planDone[t.key];
        return `<div class="task ${done ? "done" : ""}"><span class="slot">${slot}</span><div class="what"><i class="sw" style="background:${color(t.sub)}"></i>${esc(t.what)}</div>
          <div class="row" style="gap:4px">${t.note ? `<button class="btn ghost sm" data-open="${t.note}">Open notes</button>` : ""}${day.d === 0 ? `<input type="checkbox" aria-label="Done" data-done="${esc(t.key)}" ${done ? "checked" : ""}>` : ""}</div></div>`; }).join("") : '<p class="small muted">Free day. Add exams so the plan can fill up.</p>'}</div>`; }).join("");
  $$("#plan-days [data-done]").forEach(c => c.onchange = () => { p.planDone[c.dataset.done] = c.checked; touch(); renderPlan(); });
  $$("#plan-days [data-open]").forEach(b => b.onclick = () => { openNote(b.dataset.open); setTab("notes"); });
  // heads-up
  const alerts = [];
  upcoming().filter(e => e.days <= 3).forEach(e => alerts.push(`<li class="err">${esc(e.sub)} ${esc(e.type)} ${e.days === 0 ? "is TODAY" : e.days === 1 ? "is tomorrow" : "in " + e.days + " days"}</li>`));
  const min = +p.att.min || 75;
  p.att.subs.forEach(s => { const c = attCalc(s, min); if (!c.ok) alerts.push(`<li>${esc(s.n)}: attend the next <b>${c.n}</b> classes (now ${c.pct.toFixed(0)}%)</li>`); });
  (p.sems[p.cur]?.subs || []).forEach(s => { const c = subCalc(s); if (!c.graded && c.pct !== null && c.pct < 50) alerts.push(`<li>${esc(s.n)}: internal only <b>${c.pct.toFixed(0)}%</b> so far. Put extra hours here.</li>`); });
  S.notes.forEach(n => { const left = (n.tools?.flashcards?.length || 0) - (n.progress?.known?.length || 0); if (left > 0 && upcoming().some(e => e.days <= 7 && n.subject && e.sub.toLowerCase() === n.subject.toLowerCase())) alerts.push(`<li>${left} flashcards left in <b>${esc(n.title)}</b></li>`); });
  $("#plan-alerts").innerHTML = alerts.length ? `<ul class="clean">${alerts.join("")}</ul>` : '<p class="small muted">All clear. Nothing urgent.</p>';
  renderCoach();
}
$("#plan-hours").onchange = e => { P().hours = Math.min(12, Math.max(1, +e.target.value || 3)); touch(); renderPlan(); };
function situation() {
  const p = P(), up = upcoming().slice(0, 5).map(e => `${e.sub} ${e.type} in ${e.days} days`).join("; ") || "no exams added";
  const min = +p.att.min || 75, low = p.att.subs.filter(s => !attCalc(s, min).ok).map(s => s.n).join(", ") || "none";
  const sem = p.sems[p.cur]; const weak = sem ? sem.subs.map(s => ({ s, c: subCalc(s) })).filter(x => x.c.pct !== null).sort((a, b) => a.c.pct - b.c.pct).slice(0, 2).map(x => `${x.s.n} (${x.c.pct.toFixed(0)}%)`).join(", ") : "";
  return `Upcoming: ${up}. Low attendance: ${low}. Weakest subjects: ${weak || "unknown"}. Study hours/day: ${p.hours || 3}.`;
}
function renderCoach() {
  const c = $("#coach");
  if (!aiOn()) { c.innerHTML = `<p class="small" style="margin:6px 0">${esc(ruleTip())}</p><p class="small muted" style="margin:0">Install the free AI for personal coaching (Portal &amp; settings).</p>`; return; }
  c.innerHTML = `<p class="small muted" style="margin:6px 0">Gets advice for your exact situation from the free AI on your device.</p><button class="btn" id="coach-go">✨ Coach me for today</button><div id="coach-out" class="small" style="white-space:pre-wrap;margin-top:8px"></div>`;
  $("#coach-go").onclick = async () => { const o = $("#coach-out"); o.textContent = "Thinking…";
    try { await ai(`You are a friendly, practical study coach for a B.Tech student. Situation: ${situation()} Today is ${new Date().toDateString()}. Give 4 short, specific bullet points for today (what to study first, how, and one motivation line). Plain text, no markdown headers.`, { onText: t => o.textContent = t }); }
    catch (e) { o.textContent = "AI error: " + e.message; } };
}
function ruleTip() {
  const up = upcoming();
  if (up[0] && up[0].days <= 1) return `${up[0].sub} is ${up[0].days ? "tomorrow" : "today"}. Only revise: flashcards, key terms and 2–3 exam questions. Sleep 7 hours.`;
  if (up[0] && up[0].days <= 7) return `${up.length} deadline${up.length > 1 ? "s" : ""} coming up. Start with ${up[0].sub}, and do 25-minute focus blocks with 5-minute breaks.`;
  return "No exams this week, so learn ahead: make notes from one PDF a day and finish its flashcards. Future you will thank you.";
}

/* =========================================================
   PORTAL & SETTINGS
   ========================================================= */
async function loadPortal() { try { S.portal = await api("/api/portal"); } catch { } }
function savePortal(patch) { Object.assign(S.portal, patch); return api("/api/portal", "PUT", patch).catch(() => { }); }
const KINDS = [["auto", "Find automatically"], ["attendance", "Attendance"], ["marks", "Marks / results"], ["exams", "Exam timetable"], ["gatepass", "Gate pass"]];

/* =========================================================
   MY AMRITA: offline copy of the portal + gate pass actions
   ========================================================= */
S.mirTab = "att"; S.mirSem = null;
function mirMsg(t, cls) { const el = $("#mir-status"); el.className = "small " + (cls || "muted"); el.textContent = t; }
$$("#mir-tabs button").forEach(b => b.onclick = () => { S.mirTab = b.dataset.m; renderMirror(); });
$("#mir-sync").onclick = () => syncPortal();
$("#mir-open").onclick = () => openPortal("https://students.amrita.edu/client/index");
async function openPortal(url) {
  if (canBrowse()) { try { await api("/api/portal/login", "POST", { url }); mirMsg("Opened your signed-in portal window."); return; } catch { } }
  window.open(url, "_blank");
}
const fmtDT = s => { const d = Portal.passTime(s); return d ? d.toLocaleString(undefined, { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : esc(s); };
function renderMirror() {
  $$("#mir-tabs button").forEach(b => b.setAttribute("aria-selected", b.dataset.m === S.mirTab));
  const m = S.mirror, box = $("#mir-body"), win = canBrowse();
  $("#mir-grades").hidden = S.mirTab !== "grades"; box.hidden = S.mirTab === "grades";
  if (S.mirTab === "grades") { renderMarks(); renderAumsSignin(); return; }
  if (!syncing) mirMsg(m ? `Last synced ${new Date(m.syncedAt).toLocaleString()}${m.attendance?.term ? " · " + m.attendance.term + (m.attendance.sem ? " (" + m.attendance.sem + ")" : "") : ""} · updates automatically every ${S.portal.syncEveryHours || 3} h` : (win ? "Not synced yet. Click Sync now." : "This copy updates when the PC syncs. Sync on the PC, then use Backup & restore."));
  if (S.mirTab === "profile") { box.innerHTML = S.pfEdit ? mirrorProfile(win) + '<div class="row" style="margin-top:12px"><button class="btn primary" id="pf-done">Done</button></div>' : profileCard(); wireProfile(); return; }
  if (!m) { box.innerHTML = `<div class="card empty">Your attendance, marks and gate passes from myAmrita appear here after the first sync.</div>`; return; }
  if (S.mirTab === "att") { box.innerHTML = mirrorAttendance(m);
    box.querySelectorAll("[data-attview]").forEach(b => b.onclick = () => { S.attView = b.dataset.attview; renderMirror(); });
    box.querySelectorAll("[data-day]").forEach(c => c.onclick = () => openAttDay(c.dataset.day, m));
    box.querySelectorAll("[data-attm]").forEach(b => b.onclick = () => { const [y, mo] = (S.attMonth || iso(Date.now()).slice(0, 7)).split("-").map(Number), d = new Date(y, mo - 1 + +b.dataset.attm, 1);
      S.attMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; renderMirror(); }); }
  else if (S.mirTab === "marks") { box.innerHTML = mirrorMarks(m); $$("#mir-body [data-sem]").forEach(b => b.onclick = () => { S.mirSem = b.dataset.sem; renderMirror(); });
    $$("#mir-body [data-course]").forEach(el => el.onclick = () => { const c = S.marksCourses?.[el.dataset.course]; if (c) openMarksConv(c); }); }
  else if (S.mirTab === "profile") { box.innerHTML = mirrorProfile(win); wireProfile(); }
  else { box.innerHTML = mirrorGatepass(m, win); wireGatepass(); }
}
/* ---------- period-wise attendance calendar (like the myAmrita app) ----------
   red    = myAmrita Absent Report (exact date + period)
   blue / purple = approved Duty / Medical leave from the Leave List
   green  = a class that was actually recorded present that day: the course's present count rose
            (today: vs the start-of-day copy; past days: vs the previous synced day). A scheduled
            class that wasn't recorded stays blank, so teacher swaps / cancelled classes don't show green.
   Past days from before the app started logging show only absences and leave (no green). */
const PERIODS = [["08:10", "09:00"], ["09:00", "09:50"], ["09:50", "10:40"], ["11:00", "11:50"], ["11:50", "12:40"], ["13:25", "14:50"], ["14:50", "15:40"]];
const hm = t => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
function slotPeriods(s) {   // which of periods 1–7 a timetable slot covers (≥ 20 min overlap)
  const a = hm(s.start), b = hm(s.end);
  return PERIODS.map(([x, y], i) => Math.min(b, hm(y)) - Math.max(a, hm(x)) >= 20 ? i + 1 : 0).filter(Boolean);
}
// present classes recorded for each course on dateIso (today: since start of day; else: vs previous synced day); null = unknown
function presentCounts(dateIso, m) {
  const today = iso(Date.now());
  if (dateIso === today) {
    const base = m.dayBase?.date === today ? m.dayBase.totals : null, out = {};
    for (const r of m.attendance?.rows || []) { const code = r.code || r.course, was = base ? base[code] : undefined; out[code] = was === undefined ? 0 : Math.max(0, r.present + r.dl + r.medical - was); }
    return out;
  }
  const log = m.attLog || {}, snap = log[dateIso]; if (!snap) return null;
  const prev = Object.keys(log).filter(d => d < dateIso).sort().pop(), base = prev ? log[prev] : {};
  const out = {};
  for (const code in snap) out[code] = Math.max(0, snap[code][0] - (base[code] ? base[code][0] : 0));
  return out;
}
function attDay(dateIso, m) {   // { 1: {v, code, name}, … } — only the periods you were marked absent (or on leave)
  const out = {};
  const leave = (m.leaves || []).find(l => /approved/i.test(l.status) && l.from <= dateIso && l.to >= dateIso);
  const lv = () => /medical/i.test(leave.type) ? "m" : "d";
  for (const row of m.absent?.rows || []) for (const d of row.dates) if (d.date === dateIso)
    out[d.period] = { v: leave ? lv() : "a", code: row.code, name: (S.tt?.subjects || []).find(x => x.code === row.code)?.short || row.code };
  return out;
}
function attCalendar(m) {
  const abs = (m.absent?.rows || []).flatMap(r => r.dates.map(d => d.date)), lv = (m.leaves || []).map(l => l.from);
  const first = [...abs, ...lv].sort()[0] || iso(Date.now()), sw = Cal.semWindow(), start = first < sw.start ? sw.start : first;
  const ym = S.attMonth || iso(Date.now()).slice(0, 7), [y, mo] = ym.split("-").map(Number);
  const days = new Date(y, mo, 0).getDate(), today = iso(Date.now()), name = new Date(y, mo - 1, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });
  let nP = 0, nA = 0, nL = 0, cells = "";
  for (let d = 1; d <= days; d++) {
    const k = `${ym}-${String(d).padStart(2, "0")}`, dow = new Date(y, mo - 1, d).toLocaleDateString(undefined, { weekday: "short" });
    const live = k >= start && k <= today, map = live ? attDay(k, m) : {}, hol = classesOn(k).holiday;
    const box = p => { const x = map[p]; if (x?.v === "a") nA++; if (x?.v === "d" || x?.v === "m") nL++;
      return `<i class="pb ${x?.v || ""}" title="${x ? `Period ${p} · ${esc(x.name)} · absent` : `Period ${p}`}">${x ? p : ""}</i>`; };
    const has = Object.keys(map).length;
    cells += `<div class="acd${k === today ? " now" : ""}${hol && !has ? " hol" : ""}${has ? " tap" : ""}"${has ? ` data-day="${k}"` : ""}><div class="acd-h"><b>${d}</b><span>${dow}</span></div><div class="acd-p">${[1, 2, 3, 4, 5, 6, 7].map(box).join("")}</div></div>`;
  }
  return `<div class="attnote"><b>Note:</b> You'll see only your <b>absent periods</b> here — each red box is a class you were marked absent.</div>
    <div class="card attcal"><div class="row" style="justify-content:space-between;align-items:center;margin-bottom:10px">
      <button class="btn sm" data-attm="-1" aria-label="Previous month">‹</button><h3 style="margin:0;font-size:1.1rem">${name}</h3><button class="btn sm" data-attm="1" aria-label="Next month">›</button></div>
    <div class="small" style="margin:0 0 10px;display:flex;gap:14px;flex-wrap:wrap"><span><i class="pb a"></i> Absent ${nA}</span><span><i class="pb m"></i> Medical / duty leave ${nL}</span></div>
    <div class="acal">${cells}</div>
    <p class="small muted" style="margin:10px 0 0">Absent periods and leave come straight from myAmrita's Absent Report and Leave List. Updates every 30 minutes during class hours.</p></div>`;
}
// tap a day in the calendar → each period's subject, status and teacher
const ATT_LABEL = { p: ["Present", "ok"], a: ["Absent", "bad"], d: ["Duty leave", "e"], m: ["Medical leave", "e"], w: ["Not updated yet", ""] };
function openAttDay(dateIso, m) {
  const map = attDay(dateIso, m), info = classesOn(dateIso), rows = m.attendance?.rows || [];
  const teacher = code => (rows.find(r => (r.code && r.code === code)) || {}).faculty || "";
  const full = (code, short) => (S.tt?.subjects || []).find(x => x.code === code)?.name || short;
  const when = new Date(dateIso + "T00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" });
  let body;
  if (info.holiday) body = `<p class="muted">Holiday${info.holiday.title ? " · " + esc(info.holiday.title.replace(/\s*\(holiday\)/i, "")) : ""}. No classes.</p>`;
  else {
    const list = [1, 2, 3, 4, 5, 6, 7].map(p => ({ p, x: map[p] })).filter(o => o.x);
    body = list.length ? list.map(({ p, x }) => { const [lab, cls] = ATT_LABEL[x.v] || ["", ""];
      return `<div class="adrow"><div class="adp">P${p}<span>${PERIODS[p - 1][0]}</span></div>
        <div style="min-width:0;flex:1"><b>${esc(x.name)}</b> <span class="small muted">${esc(full(x.code, x.name))}</span>${teacher(x.code) ? `<div class="small muted">${esc(teacher(x.code))}</div>` : ""}</div>
        <span class="pill ${cls}">${lab}</span></div>`; }).join("") : '<p class="muted">No classes recorded for this day.</p>';
  }
  let dlg = $("#att-detail");
  if (!dlg) { document.body.insertAdjacentHTML("beforeend", `<dialog id="att-detail" class="sheet"><div class="sheet-card"><div class="row" style="justify-content:space-between;align-items:center;margin-bottom:10px"><h3 id="ad-title" style="margin:0"></h3><button class="btn ghost sm" id="ad-x" aria-label="Close">✕</button></div><div id="ad-body"></div></div></dialog>`); dlg = $("#att-detail"); $("#ad-x").onclick = () => dlg.close(); dlg.onclick = e => { if (e.target === dlg) dlg.close(); }; }
  $("#ad-title").textContent = when;
  $("#ad-body").innerHTML = body;
  dlg.showModal();
}
function mirrorAttendance(m) {
  const rows = m.attendance?.rows || []; if (!rows.length) return '<div class="card empty">No attendance found for this semester yet.</div>';
  const min = +P().att.min || 75;
  const eff = r => r.present + r.dl + r.medical;   // medical leave counts as present
  const tot = rows.reduce((s, r) => s + r.total, 0), pres = rows.reduce((s, r) => s + eff(r), 0), low = rows.filter(r => r.total && eff(r) / r.total * 100 < min);
  const listView = `<div class="stats"><div class="stat"><span class="eyebrow">Overall (medical = present)</span><b class="num">${tot ? (pres / tot * 100).toFixed(1) : "—"}%</b><span class="small muted">${pres}/${tot} classes</span></div>
    <div class="stat"><span class="eyebrow">Below ${min}%</span><b class="num" style="color:${low.length ? "var(--bad)" : "var(--good)"}">${low.length}</b><span class="small muted">${low.length ? low.map(r => esc(r.course)).join(", ") : "all safe"}</span></div>
    <div class="stat"><span class="eyebrow">Medical leaves</span><b class="num">${rows.reduce((s, r) => s + r.medical, 0)}</b><span class="small muted">counted as present here</span></div></div>
    <div class="card">${rows.map(r => { const pct = r.total ? eff(r) / r.total * 100 : 0, c = attCalc({ a: eff(r), t: r.total }, min), col = !c.ok ? "var(--bad)" : c.n <= 1 ? "var(--warn)" : "var(--good)";
      return `<div class="mrow"><div class="ring" style="--p:${pct.toFixed(0)};--c:${col}"><span class="num">${pct.toFixed(0)}%</span></div>
        <div style="min-width:0"><b>${esc(r.course)}</b> <span class="chip">${esc(r.code)}</span><div class="nums"><span>Present <b>${r.present}</b>${r.dl ? " + " + r.dl + " duty leave" : ""}${r.medical ? " + " + r.medical + " medical" : ""} / <b>${r.total}</b></span><span>Absent <b>${r.absent}</b></span><span>Portal shows <b>${r.pct}%</b></span><span>${esc(r.faculty)}</span></div></div>
        <div style="font-weight:800;color:${col};text-align:right" class="small">${c.ok ? (c.n > 0 ? `Can skip <b>${c.n}</b>` : "Don't skip") : `Attend next <b>${c.n}</b>`}</div></div>`; }).join("")}</div>`;
  const view = S.attView || "list";
  const ic = { list: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>`,
    cal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>` };
  return `<div class="row gp-switch" style="gap:10px;margin:0 0 12px">
      <button class="btn big ${view === "list" ? "primary" : ""}" data-attview="list">${ic.list} Attendance</button>
      <button class="btn big ${view === "cal" ? "primary" : ""}" data-attview="cal">${ic.cal} Calendar</button>
    </div>
    ${view === "cal" ? attCalendar(m) : listView}`;
}
/* per-subject mark conversion: tap a subject → set what each component converts to (e.g. mid 42/50 → out of 30).
   Saved in P().conv[code] = { components:[{name, got, max, to}], extra:[{name, got, max, to}] } */
function marksComponents(c) {
  const comps = (c.items || []).map(x => ({ name: x.exam, got: x.got, max: x.max }));
  (c.extra || []).forEach(x => { if (!x.np) comps.push({ name: x.exam, got: typeof x.val === "number" ? x.val : null, max: null }); });
  return comps;
}
const isMidTerm = n => /mid[\s-]*term|mid[\s-]*sem/i.test(n);
function convFor(c) {   // merge saved conversion over the current portal components
  const saved = (P().conv || {})[c.code]?.rows || [];
  return marksComponents(c).map(k => { const s = saved.find(r => r.name === k.name) || {};
    // mid-term defaults to out of 20 (the common scaling) until you change it; other pieces default to their own max
    const to = s.to != null ? s.to : isMidTerm(k.name) ? 20 : k.max;
    return { name: k.name, got: s.got != null ? s.got : k.got, max: s.max != null ? s.max : k.max, to }; });
}
function convInternal(c) {   // computed internal from the conversion (defaults: mid→20, others→max), or null if nothing graded
  const usable = convFor(c).filter(r => r.to && r.max);   // convertible (needs a max); AUMS items without a max don't count until you set it
  const graded = usable.filter(r => r.got != null);
  if (!graded.length) return null;
  const got = graded.reduce((s, r) => s + r.got / r.max * r.to, 0);
  const max = usable.reduce((s, r) => s + (+r.to || 0), 0);
  return { got, max, custom: !!(P().conv || {})[c.code]?.rows?.length };
}
function openMarksConv(c) {
  const rows = convFor(c);
  const row = (r, i) => `<div class="cvrow" data-i="${i}"><div class="cvname">${esc(r.name)}</div>
      <div class="cvio"><input type="number" class="cvget" value="${r.got ?? ""}" placeholder="got" inputmode="decimal"><span>/</span><input type="number" class="cvmax" value="${r.max ?? ""}" placeholder="max" inputmode="decimal"></div>
      <div class="cvarrow">→ out of</div><input type="number" class="cvto" value="${r.to ?? ""}" placeholder="to" inputmode="decimal">
      <div class="cvres num"><b>—</b></div></div>`;
  const html = `<div class="row" style="justify-content:space-between;align-items:center;margin-bottom:6px"><h3 style="margin:0">${esc(c.course)}</h3><button class="btn ghost sm" id="cv-x" aria-label="Close">✕</button></div>
    <p class="small muted" style="margin:0 0 10px">Set what each piece converts to, e.g. mid-term 50 → out of 30. The internal total updates as you type.</p>
    <div class="cvhead small muted"><span>Component</span><span>Your marks</span><span></span><span>Converts to</span><span>= Got</span></div>
    ${rows.length ? rows.map(row).join("") : '<p class="muted">No components published yet. They appear here once marks are out.</p>'}
    <div class="cvtotal">Internal so far <b id="cv-got">—</b> / <b id="cv-max">—</b></div>
    <div class="row" style="margin-top:12px;gap:8px"><button class="btn primary" id="cv-save">Save</button><button class="btn ghost" id="cv-reset">Clear conversion</button></div>`;
  let dlg = $("#conv-dlg");
  if (!dlg) { document.body.insertAdjacentHTML("beforeend", `<dialog id="conv-dlg" class="sheet"><div class="sheet-card" id="conv-body"></div></dialog>`); dlg = $("#conv-dlg"); dlg.onclick = e => { if (e.target === dlg) dlg.close(); }; }
  $("#conv-body").innerHTML = html;
  dlg.showModal();
  const recompute = () => { let g = 0, mx = 0;
    $$("#conv-body .cvrow").forEach(el => { const got = parseFloat(el.querySelector(".cvget").value), max = parseFloat(el.querySelector(".cvmax").value), to = parseFloat(el.querySelector(".cvto").value);
      const conv = (isFinite(got) && isFinite(max) && max > 0 && isFinite(to)) ? got / max * to : null;
      el.querySelector(".cvres").innerHTML = `<b>${conv != null ? +conv.toFixed(1) : "—"}</b>${isFinite(to) ? " / " + to : ""}`;
      if (isFinite(to)) { mx += to; if (conv != null) g += conv; } });
    $("#cv-got").textContent = +g.toFixed(1); $("#cv-max").textContent = +mx.toFixed(0); };
  // "converts to" defaults to the component's own total (mid-term → 20) and follows the total until you edit it
  $$("#conv-body .cvrow").forEach((el, i) => {
    const get = el.querySelector(".cvget"), max = el.querySelector(".cvmax"), to = el.querySelector(".cvto");
    if (!isMidTerm(rows[i].name) && to.value !== "" && to.value === max.value) to.dataset.auto = "1";
    get.oninput = recompute;
    to.oninput = () => { delete to.dataset.auto; recompute(); };
    max.oninput = () => { if (to.dataset.auto) to.value = max.value; recompute(); };
  });
  recompute();
  $("#cv-x").onclick = () => dlg.close();
  $("#cv-save").onclick = () => {
    const out = $$("#conv-body .cvrow").map((el, i) => ({ name: rows[i].name,
      got: el.querySelector(".cvget").value === "" ? null : +el.querySelector(".cvget").value,
      max: el.querySelector(".cvmax").value === "" ? null : +el.querySelector(".cvmax").value,
      to: el.querySelector(".cvto").value === "" ? null : +el.querySelector(".cvto").value }));
    (P().conv = P().conv || {})[c.code] = { rows: out }; touch(); dlg.close(); renderMirror();
  };
  $("#cv-reset").onclick = () => { if (P().conv) delete P().conv[c.code]; touch(); dlg.close(); renderMirror(); };
}
// build the per-course marks (with AUMS extras) for one semester — shared by the Marks page and the Grades percentages
function buildMarksCourses(m, semName) {
  if (!m?.marks?.length) return { sem: null, courses: [] };
  const sem = m.marks.find(b => b.sem === semName) || m.marks[m.marks.length - 1];
  const courses = Portal.courseTotals(sem.rows);
  const am = m.aumsMarks?.[sem.sem] || {};
  const nameOf = code => (m.attendance?.rows.find(r => r.code === code) || {}).course || (P().sems.flatMap(s => s.subs).find(x => x.code === code) || {}).n || code;
  Object.keys(am).filter(code => !courses.some(c => c.code === code)).forEach(code => courses.push({ code, course: nameOf(code), items: [], caGot: 0, caMax: 0, esGot: null }));
  const semSubs = (P().sems.find(s => s.name === sem.sem) || { subs: [] }).subs;
  const attRows = m.attendance?.sem === sem.sem ? m.attendance.rows : [];
  [...semSubs.map(s => ({ code: s.code, course: s.n })), ...attRows.map(r => ({ code: r.code, course: r.course }))]
    .forEach(x => { if (x.code && !courses.some(c => c.code === x.code)) courses.push({ code: x.code, course: x.course, items: [], caGot: 0, caMax: 0, esGot: null }); });
  courses.forEach(c => { const have = new Set(c.items.map(x => Portal.examKey(x.exam)));
    c.extra = (am[c.code] || []).filter(x => !have.has(Portal.examKey(x.exam)) && !(x.np && c.items.length)); });
  courses.sort((a, b) => a.code.localeCompare(b.code));
  return { sem, courses };
}
function mirrorMarks(m) {
  if (!m.marks.length) return '<div class="card empty">No marks found yet.</div>';
  const built = buildMarksCourses(m, S.mirSem); const sem = built.sem; S.mirSem = sem.sem;
  const courses = built.courses, am = m.aumsMarks?.[sem.sem] || {};
  S.marksCourses = Object.fromEntries(courses.map(c => [c.code, c]));
  return `<div class="semtabs" style="margin-bottom:12px">${m.marks.map(b => `<button data-sem="${esc(b.sem)}" aria-selected="${b.sem === sem.sem}">${esc(b.sem)} <span class="small muted">${esc(b.term)}</span></button>`).join("")}</div>
    ${courses.length ? `<div class="mgrid">${courses.map(c => { const ci = convInternal(c);
      const status = ci ? (ci.got >= 40 ? '<span class="pill ok">Pass</span>' : `<span class="pill warn">${+(40 - ci.got).toFixed(1)} left for pass</span>`) : "";
      return `<div class="card mbox tap" data-course="${esc(c.code)}">
        <div class="mhead"><b>${esc(c.course)}</b><span class="chip">${esc(c.code)}</span>${status}</div>
        ${ci ? `<div class="minternal">Internals <b>${+ci.got.toFixed(1)}</b> / <b>${+ci.max.toFixed(0)}</b></div>`
          : c.allMax ? `<div class="small muted num" style="margin:2px 0 6px">Total so far: ${+c.allGot.toFixed(2)} / ${+c.allMax.toFixed(2)}</div>` : ""}
        ${c.items.map(x => `<div class="comp"><span>${esc(x.exam)}</span><span class="num">${x.got ?? "—"} / ${x.max}</span></div>`).join("")}
        ${c.extra.map(x => `<div class="comp"><span>${esc(x.exam)} <span class="chip" style="font-size:.68rem;padding:0 6px">AUMS</span></span><span class="num">${x.np ? '<span class="muted small">not published</span>' : x.val}</span></div>`).join("")}
        ${!c.items.length && !c.extra.length ? '<p class="small muted" style="margin:6px 0 0">No marks published yet.</p>' : ""}
        <div class="small" style="margin-top:8px;color:var(--accent)">Tap to set conversion →</div></div>`; }).join("")}</div>` : '<div class="card empty">No marks published for this semester yet.</div>'}
    ${Object.keys(am).length ? '<p class="small muted">Each assessment is shown once. Entries tagged AUMS were published only on AUMS (AUMS doesn\'t show the maximum marks).</p>' : '<p class="small muted">Save your AUMS sign-in (Grades &amp; CGPA) to also add marks that are only on AUMS.</p>'}
    <p class="small muted">Your internal marks per course also appear under <b>Grades &amp; CGPA</b>, next to your AUMS grades and the what-if calculator.</p>`;
}
function passState(p) {
  const s = (p.status || "").toLowerCase(), from = Portal.passTime(p.from), to = Portal.passTime(p.to), now = new Date();
  if (/cancel/.test(s)) return "cancelled"; if (/reject|denied/.test(s)) return "rejected";
  if (/approved/.test(s)) return to && to < now ? "used" : from && from <= now ? "out" : "upcoming";
  return to && to < now ? "expired" : "pending";
}
const PASS_CHIP = { upcoming: ["good", "Approved"], out: ["good", "You're out now"], pending: ["warn", "Waiting for approval"], used: ["", "Done"], cancelled: ["", "Cancelled"], rejected: ["bad", "Rejected"], expired: ["", "Expired"] };
function mirrorGatepass(m, win) {
  const list = (m.gatepass || []).map(p => ({ ...p, st: passState(p) }));
  const live = list.filter(p => ["out", "upcoming", "pending"].includes(p.st)).sort((a, b) => (Portal.passTime(a.from) || 0) - (Portal.passTime(b.from) || 0));
  const tom = inDays(1);
  const card = p => `<div class="card ${p.st === "pending" ? "hero-pass wait" : "hero-pass"}" style="margin-bottom:10px"><div class="row" style="justify-content:space-between">
      <div><span class="chip ${PASS_CHIP[p.st][0]}">${PASS_CHIP[p.st][1]}</span> <b style="font-size:1.1rem">${esc(p.name)}</b> <span class="small muted">#${esc(p.id)} · ${esc(p.level)}</span>
      <div style="margin-top:4px">${fmtDT(p.from)} → ${fmtDT(p.to)}</div></div>
      <div class="row">${win ? `<button class="btn sm" data-detail="${esc(p.id)}">Approvals</button><button class="btn ghost sm danger" data-cancel="${esc(p.id)}">Cancel pass</button>` : ""}</div></div><div class="small" id="det-${esc(p.id)}"></div></div>`;
  const applyCard = `<div class="card"><h3 style="font-size:1.1rem;margin-bottom:8px">Apply for a gate pass</h3>${win ? `
      <form class="form" id="gp-form">
        <label for="gp-type">Pass type<select id="gp-type"><option value="out">Out pass (same day)</option><option value="home">Home pass</option><option value="placement">Placement</option></select></label>
        <label for="gp-reason">Reason<input type="text" id="gp-reason" required placeholder="e.g. Going home for the weekend"></label>
        <div class="row" style="flex-wrap:nowrap"><label for="gp-fd" style="flex:1">From date<input type="date" id="gp-fd" required value="${tom}"></label><label for="gp-ft" style="flex:1">From time (24 h)<input type="time" id="gp-ft" required value="07:00"></label></div>
        <div class="row" style="flex-wrap:nowrap"><label for="gp-td" style="flex:1">To date<input type="date" id="gp-td" required value="${tom}"></label><label for="gp-tt" style="flex:1">To time (24 h)<input type="time" id="gp-tt" required value="20:00"></label></div>
        <button class="btn primary" type="submit" id="gp-review">Review request</button>
      </form><div id="gp-confirm" class="small" style="margin-top:8px"></div>` : '<p class="small muted">Applying and cancelling run on the PC (it holds your portal sign-in). Open My App on the PC to do this.</p>'}</div>`;
  const past = list.filter(p => !live.includes(p));
  const historyCard = `<div class="card"><h3 style="font-size:1.1rem;margin-bottom:8px">History of passes</h3>${past.slice(0, 50).map(p => `<div class="pass"><div><b>${esc(p.name)}</b> <span class="small muted">#${esc(p.id)}</span><div class="small muted">${fmtDT(p.from)} → ${fmtDT(p.to)}</div></div><span class="chip ${PASS_CHIP[p.st][0]}">${PASS_CHIP[p.st][1]}</span></div>`).join("") || '<p class="small muted">No past passes yet.</p>'}</div>`;
  const view = S.gpView || "apply";
  return `${live.length ? live.map(card).join("") : '<div class="card" style="margin-bottom:10px"><p class="muted" style="margin:0">No active or pending passes.</p></div>'}
    <div class="row gp-switch" style="gap:10px;margin:0 0 12px">
      <button class="btn big ${view === "apply" ? "primary" : ""}" data-gpview="apply">＋ Apply pass</button>
      <button class="btn big ${view === "history" ? "primary" : ""}" data-gpview="history">History of passes${past.length ? ` (${past.length})` : ""}</button>
    </div>
    ${view === "apply" ? applyCard : historyCard}`;
}
function wireGatepass() {
  $$("#mir-body [data-gpview]").forEach(b => b.onclick = () => { S.gpView = b.dataset.gpview; renderMirror(); });
  $$("#mir-body [data-detail]").forEach(b => b.onclick = async () => { const box = $("#det-" + b.dataset.detail); box.textContent = "Loading approvals…";
    try { const d = await api("/api/gatepass/detail?id=" + b.dataset.detail); const t = d.text.split("\n").map(s => s.trim()).filter(Boolean); const i = t.findIndex(s => /^Pass Name/i.test(s));
      box.innerHTML = `<div class="raw" style="margin-top:8px">${esc(t.slice(i >= 0 ? i : 0).filter(s => !/E-Governance|Cancel Pass Request/.test(s)).join("\n"))}</div>`; }
    catch (e) { box.innerHTML = `<span class="err">${esc(e.message)}</span>`; } });
  $$("#mir-body [data-cancel]").forEach(b => b.onclick = async () => {
    if (!b.dataset.armed) { b.dataset.armed = 1; b.textContent = "Click again to cancel on the portal"; return; }
    b.disabled = true; b.textContent = "Cancelling…";
    try { const r = await api("/api/gatepass/cancel", "POST", { id: b.dataset.cancel }); if (r.passes) mergePasses(r.passes); mirMsg(r.ok ? `Pass #${b.dataset.cancel} cancelled on the portal.` : (r.message || "The portal didn't confirm the cancellation. Check the History."), r.ok ? "ok" : "err"); }
    catch (e) { mirMsg(e.message, "err"); } renderMirror(); });
  const f = $("#gp-form"); if (!f) return;
  f.onsubmit = e => { e.preventDefault();
    const req = { type: $("#gp-type").value, reason: $("#gp-reason").value.trim(), fromDate: $("#gp-fd").value, fromTime: $("#gp-ft").value, toDate: $("#gp-td").value, toTime: $("#gp-tt").value };
    if (req.type === "out") req.toDate = req.fromDate;
    if (new Date(req.toDate + "T" + req.toTime) <= new Date(req.fromDate + "T" + req.fromTime)) { $("#gp-confirm").innerHTML = '<span class="err">"To" must be after "From".</span>'; return; }
    const label = { out: "Out pass", home: "Home pass", placement: "Placement pass" }[req.type];
    $("#gp-confirm").innerHTML = `<div class="banner" style="margin:0"><span><b>${label}</b> · ${fmtDT(req.fromDate + " " + req.fromTime)} → ${fmtDT(req.toDate + " " + req.toTime)}<br>Reason: ${esc(req.reason)}</span><button class="btn primary" id="gp-send">Send to warden</button><button class="btn ghost" id="gp-edit">Edit</button></div>`;
    $("#gp-edit").onclick = () => $("#gp-confirm").innerHTML = "";
    $("#gp-send").onclick = async () => { const s = $("#gp-send"); s.disabled = true; s.textContent = "Sending…";
      try { const r = await api("/api/gatepass/apply", "POST", req); if (r.passes) mergePasses(r.passes);
        $("#gp-confirm").innerHTML = r.ok ? `<p class="ok">Request sent: pass #${esc(r.pass.id)}, ${esc(r.pass["final status"] || "pending")}. You'll get a notification when it's approved.</p>` : `<p class="err">The portal didn't accept it.${r.messages?.length ? " It said: " + esc(r.messages.join(" · ")) : ""}</p>`;
        if (r.ok) { f.reset(); renderMirror(); } }
      catch (e) { $("#gp-confirm").innerHTML = `<p class="err">${esc(e.message)}</p>`; } };
  };
}
function mergePasses(rows) {
  const list = rows.map(r => ({ id: r.id, name: r["pass name"], from: r.from, to: r.to, level: r["level status"], status: r["final status"], created: r["created on"] }));
  S.mirror = { ...(S.mirror || { marks: [], attendance: null }), gatepass: list, syncedAt: Date.now() };
  api("/api/mirror", "PUT", S.mirror).catch(() => { });
}
function renderPortal() {
  const win = canBrowse();
  const links = S.portal.links || [];
  $("#links").innerHTML = links.length ? links.map((l, i) => `<div class="link">
      <input type="text" id="lk-l-${l.id}" data-i="${i}" data-k="label" value="${esc(l.label)}" placeholder="Name">
      <input type="url" id="lk-u-${l.id}" data-i="${i}" data-k="url" value="${esc(l.url)}" placeholder="https://erp.yourcollege.edu/attendance">
      <select id="lk-k-${l.id}" data-i="${i}" data-k="kind">${KINDS.map(([v, t]) => `<option value="${v}" ${l.kind === v ? "selected" : ""}>${t}</option>`).join("")}</select>
      ${win ? `<button class="btn sm" data-login="${i}">Sign in</button>` : "<span></span>"}<button class="btn ghost sm" data-rm="${i}" aria-label="Remove">✕</button></div>`).join("")
    : `<p class="small muted">No portal pages yet. Add one below.</p>`;
  $$("#links input, #links select").forEach(el => el.onchange = () => { links[el.dataset.i][el.dataset.k] = el.value.trim(); savePortal({ links }); });
  $$("#links [data-rm]").forEach(b => b.onclick = () => { links.splice(+b.dataset.rm, 1); savePortal({ links }); renderPortal(); });
  $$("#links [data-login]").forEach(b => b.onclick = async () => { const l = links[+b.dataset.login]; if (!/^https?:\/\//.test(l.url || "")) { syncMsg("Enter the page URL first (starting with https://).", "err"); return; }
    try { await api("/api/portal/login", "POST", { url: l.url }); syncMsg(window.MyAppAndroid ? "A sign-in window opened. Sign in to your portal, then tap Done." : "An Edge window opened. Sign in to your portal there, then close that window."); } catch (e) { syncMsg(e.message, "err"); } });
  $("#auto-sync").checked = !!S.portal.autoSync; $("#auto-sync").disabled = !win;
  $("#sync").hidden = !win;
  if (!$("#paste-portal")) {
    $("#sync-review").insertAdjacentHTML("beforebegin", `<div class="card" id="paste-card" style="margin-bottom:16px"><h3 style="font-size:1.1rem">Or copy-paste from any device</h3>
      <p class="small muted" style="margin:4px 0 8px">Open your portal page (attendance, marks or timetable) in any browser. Select all (Ctrl+A, or long-press → Select all on a phone), copy, then paste into the box below.</p>
      <div id="paste-portal" contenteditable="true" class="raw" style="min-height:70px;cursor:text" aria-label="Paste portal page here"></div>
      <div class="row" style="margin-top:8px"><select id="paste-kind">${KINDS.map(([v, t]) => `<option value="${v}">${t}</option>`).join("")}</select><button class="btn" id="paste-read">Read pasted page</button></div></div>`);
    $("#paste-portal").addEventListener("paste", e => { e.preventDefault(); const html = e.clipboardData.getData("text/html"), text = e.clipboardData.getData("text/plain"); S.pasted = { html, text }; $("#paste-portal").textContent = `Pasted ${html ? "a web page" : "text"} (${(text || html).length.toLocaleString()} characters). Click "Read pasted page".`; });
    $("#paste-read").onclick = readPasted;
  }
  const last = S.portal.lastSync ? new Date(S.portal.lastSync).toLocaleString() : "never";
  if (!$("#sync-status").dataset.busy) syncMsg(win ? `Last synced: ${last}.` : "Automatic sync needs the Windows PC. On this device, use copy-paste below.");
}
function syncMsg(t, cls) { const el = $("#sync-status"); el.className = "small " + (cls || "muted"); el.textContent = t; }
$("#link-add").onclick = () => { (S.portal.links = S.portal.links || []).push({ id: uid(), label: "", url: "", kind: "auto" }); savePortal({ links: S.portal.links }); renderPortal(); };
$("#auto-sync").onchange = e => savePortal({ autoSync: e.target.checked });
$("#sync").onclick = () => syncPortal();
let syncing = null;
function syncPortal() {
  if (syncing) return syncing;
  const btns = [$("#sync"), $("#mir-sync")]; btns.forEach(b => { b.disabled = true; b.textContent = "Syncing…"; });
  $("#sync-status").dataset.busy = 1; syncMsg("Syncing… reading your portal in the background."); mirMsg("Syncing with your portal…");
  syncing = (async () => {
    try { const cache = await api("/api/portal/sync", "POST", {}); S.portal.lastSync = cache.fetchedAt; await reviewResults(cache.results); }
    catch (e) { const m = e.data?.error === "no_links" ? "Add at least one portal page first." : "Sync failed: " + e.message; syncMsg(m, "err"); mirMsg(m, "err"); }
    finally { btns.forEach(b => { b.disabled = false; b.textContent = "Sync now"; }); delete $("#sync-status").dataset.busy; syncing = null; }
  })();
  return syncing;
}
/* Amrita portal pages → offline copy (attendance, marks, grades data), no review needed */
async function applyAmrita(results) {
  const m = Portal.mirrorFrom(results, S.mirror);
  if (!m.found) return false;
  if (P().example) { const p = P(); p.exams = []; listClear("exams").catch(() => { }); p.sems = []; p.att.subs = []; p.planDone = {}; p.cur = 0; p.example = false; }
  Portal.applyMirror(m, P(), uid);
  if (!P().sems.length) P().sems.push({ id: uid(), name: "Sem 1", subs: [] });
  S.mirror = m; await api("/api/mirror", "PUT", m).catch(() => { });
  touch(); renderPlanner(); renderMirror();
  const login = results.filter(r => r.needsLogin).length;
  const msg = `Synced ${new Date(m.syncedAt).toLocaleTimeString()}: ${m.attendance?.rows.length || 0} courses' attendance, ${m.marks.reduce((n, b) => n + b.rows.length, 0)} marks entries across ${m.marks.length} semesters, ${m.gatepass?.length || 0} gate passes.` + (login ? " Some pages need you to sign in again (Portal & settings → Sign in)." : "");
  syncMsg(msg, login ? "err" : "ok"); $("#sync-review").innerHTML = "";
  return true;
}
async function reviewResults(results) {
  if (await applyAmrita(results)) return;
  let found = { att: [], marks: [], exams: [] }; const notes = [];
  for (const r of results) {
    if (!r.ok) { notes.push(`<li class="err">${esc(r.label || r.url)}: ${r.needsLogin ? "you're signed out. Click Sign in, sign in, close the window, then sync again." : esc(r.error || "couldn't read")}</li>`); continue; }
    let f = Portal.readTables(r.tables || [], r.kind || "auto");
    if (!Portal.count(f) && aiOn()) { try { f = Portal.fromAi(await ai(Portal.AI_PROMPT(r.text || ""), { json: true })); } catch { } }
    notes.push(`<li>${esc(r.label || r.url)}: found ${f.att.length} attendance, ${f.marks.length} marks, ${f.exams.length} exam rows</li>`);
    found = Portal.merge(found, f);
  }
  showChanges(found, notes, results);
}
async function readPasted() {
  if (!S.pasted) { syncMsg("Paste a portal page into the box first.", "err"); return; }
  const kind = $("#paste-kind").value;
  let tables = S.pasted.html ? Portal.tablesFromHtml(S.pasted.html) : []; if (!tables.length) tables = Portal.tablesFromText(S.pasted.text || "");
  let f = Portal.readTables(tables, kind);
  if (!Portal.count(f) && aiOn()) { syncMsg("No tables recognised, so I'm asking the free AI to read the page…"); try { f = Portal.fromAi(await ai(Portal.AI_PROMPT(S.pasted.text || ""), { json: true })); } catch { } }
  showChanges(f, [`<li>Pasted page: found ${f.att.length} attendance, ${f.marks.length} marks, ${f.exams.length} exam rows</li>`], [{ label: "Pasted page", text: S.pasted.text, tables }]);
}
function showChanges(found, notes, results) {
  if (P().example && Portal.count(found)) clearExamples();
  const changes = Portal.diff(found, P());
  S.pendingChanges = changes;
  $("#sync-review").innerHTML = `<div class="card"><h3 style="font-size:1.15rem">Review before saving</h3><ul class="clean small">${notes.join("")}</ul>
    ${changes.length ? `<div style="margin-top:10px">${changes.map((c, i) => `<label class="change" for="ch${i}"><input type="checkbox" id="ch${i}" ${c.disabled ? "disabled" : "checked"}><span>${esc(c.label)}</span></label>`).join("")}</div>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="apply">Save selected</button></div>` : `<p class="small muted">Nothing new to update.${Portal.count(found) ? "" : " If your portal shows the data, open the page once here and check it's the right URL."}</p>`}
    <details style="margin-top:10px"><summary>What the page looked like (for checking)</summary>${(results || []).map(r => `<p class="small"><b>${esc(r.label || r.url || "")}</b></p><div class="raw">${esc((r.text || "").slice(0, 3000))}</div>`).join("")}</details></div>`;
  const ap = $("#apply"); if (ap) ap.onclick = () => {
    let n = 0; changes.forEach((c, i) => { if (!c.disabled && $("#ch" + i).checked) { c.apply(); n++; } });
    P().example = false; touch(); renderPlanner(); savePortal({ appliedAt: Date.now() });
    $("#sync-review").innerHTML = `<div class="card"><p class="ok" style="margin:0">Saved ${n} change${n === 1 ? "" : "s"}. Check the myAmrita and Exams tabs.</p></div>`;
    syncMsg(`Last synced: ${new Date().toLocaleString()}.`);
  };
  syncMsg(changes.length ? `${changes.length} change${changes.length > 1 ? "s" : ""} found. Review them below.` : "Synced. Nothing new.");
}

/* settings */
function renderSettings() {
  const win = STATUS.platform === "windows", here = STATUS.local;
  renderAumsSignin(); if ($("#aums-card")) $("#aums-card").hidden = !canBrowse();
  $("#ver").textContent = APP_VERSION; renderUpdate(); renderAdmin(); $("#data-dir").textContent = STATUS.dataDir || "";
  $("#alerts-on").checked = S.portal.alerts !== false;
  $("#class-on").checked = S.portal.classAlerts !== false; $("#class-lead").value = String(S.portal.classLead || 5);
  $("#class-alarm").checked = !!S.portal.classAlarm;
  $("#alarm-sound").value = S.portal.alarmSound || "alarm"; $("#alarm-vib").checked = S.portal.alarmVibrate !== false; $("#alarm-rep").checked = S.portal.alarmRepeat !== false; $("#class-lead").disabled = $("#class-alarm").disabled = !$("#class-on").checked;
  const h = $("#alert-hour"); if (!h.options.length) for (let i = 5; i <= 22; i++) h.add(new Option(`${i}:00`, i)); h.value = S.portal.alertHour ?? 8;
  $("#startup-on").checked = !!STATUS.startup; $("#startup-on").closest("label").hidden = !(win && here);
  $("#quit").hidden = !here;
  const m = STATUS.ai.models || [];
  $("#ai-info").innerHTML = STATUS.ai.running
    ? (STATUS.ai.model ? `<p class="ok" style="margin:0 0 6px">Free AI is on: ${esc(STATUS.ai.model)}</p><p class="muted" style="margin:0">Runs on ${win ? "this PC" : "this device"}, works offline, costs nothing. Used for note polish, the AI tutor, the study coach and reading portal pages.</p>`
      : `<p style="margin:0">Ollama is running but has no model yet. ${here ? '<button class="btn sm" id="ai-pull">Download free model (2 GB)</button>' : ""}</p>`)
    : `<p style="margin:0 0 6px">Free AI is <b>off</b>. Everything still works with the built-in engine.</p><p class="muted" style="margin:0">To turn it on: install <b>Ollama</b> from ollama.com (free), then come back here and click "Download free model".</p>`;
  const pull = $("#ai-pull"); if (pull) pull.onclick = async () => { pull.disabled = true; pull.textContent = "Downloading… (this takes a while)"; try { await api("/api/ai/pull", "POST", {}); } catch (e) { pull.textContent = "Failed: " + e.message; } refreshStatus(); };
  renderLan();
}
$("#alerts-on").onchange = e => savePortal({ alerts: e.target.checked });
// small app updates: the app downloads a ~0.5 MB signed pack by itself; one tap restarts into it (no new APK)
const verDate = v => v ? new Date(v * 60000).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "";
async function renderUpdate(check) {
  const card = $("#upd-card");
  if (check && card) paintUpdate({ ...(S.update || {}), busy: true });
  let u; try { u = await api(check ? "/api/update/check" : "/api/update", check ? "POST" : "GET"); } catch { if (check) paintUpdate({ ...(S.update || {}), busy: false, error: "no connection to the app" }); return; }
  S.update = u; updateBanner(); paintUpdate(u);
}
function paintUpdate(u) {
  const card = $("#upd-card"); if (!card) return;
  card.hidden = !u.enabled;
  const kb = u.size ? Math.max(1, Math.round(u.size / 1024)) + " KB" : "";
  const st = u.busy ? { cls: "busy", icon: '<span class="upd-spin"></span>', title: "Checking for updates…", sub: "Downloading a small update if there is one.", btn: ["Checking…", "", true] }
    : u.ready ? { cls: "ready", icon: "⬆", title: "Update ready", sub: [kb, u.notes].filter(Boolean).map(esc).join(" · "), btn: ["Install update & restart", "go"] }
    : u.apk ? { cls: "apk", icon: "⬇", title: "New app version", sub: "This one needs the full app file (about 22 MB). Your data stays.", btn: ["Download new app", "apk"] }
    : u.error ? { cls: "err", icon: "!", title: "Couldn't check for updates", sub: esc(u.error), btn: ["Try again", "check"] }
    : { cls: "ok", icon: "✓", title: "You're up to date", sub: `Version from ${verDate(u.current)}${u.checked ? " · checked " + esc(u.checked.slice(11)) : ""}`, btn: ["Check for updates", "check"] };
  card.className = "card upd-card " + st.cls;
  card.innerHTML = `<div class="upd-row"><div class="upd-ico" aria-hidden="true">${st.icon}</div><div style="min-width:0"><b class="upd-title">${st.title}</b><div class="small muted">${st.sub}</div></div></div>
    <button class="btn ${u.ready || u.apk ? "primary" : ""} upd-btn" id="upd-act" ${st.btn[2] ? "disabled" : ""}>${st.btn[0]}</button>`;
  $("#upd-act").onclick = () => st.btn[1] === "go" ? restartForUpdate() : st.btn[1] === "apk" ? window.open(u.apk, "_blank") : renderUpdate(true);
}
// admin (your own edition only): installs reported by classmates
async function renderAdmin(check) {
  const card = $("#admin-card"); if (!card) return;
  if (isClassmates()) return;
  $("#inst-url").value = S.portal?.installsUrl || "";
  let d; try { d = await api(check ? "/api/installs/check" : "/api/installs", check ? "POST" : "GET"); } catch { return; }
  $("#inst-meta").textContent = d.error && d.error !== "no link" ? "Couldn't check: " + d.error : d.checked ? `${d.rows.length} installs · checked ${d.checked.replace("T", " ")}` : "";
  $("#inst-list").innerHTML = (d.rows || []).length ? `<table class="tbl"><thead><tr><th>Name</th><th>Roll</th><th>Section</th><th>When</th></tr></thead><tbody>${d.rows.map(r =>
    `<tr><td>${esc(r.name || "")}</td><td>${esc(r.roll || "")}</td><td>${esc(r.section || "")}</td><td class="small muted">${new Date(r.t).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</td></tr>`).join("")}</tbody></table>` : "";
}
$("#inst-url").onchange = async e => { await savePortal({ installsUrl: e.target.value.trim() }); renderAdmin(true); };
$("#inst-check").onclick = () => { $("#inst-meta").textContent = "Checking…"; renderAdmin(true); };
function restartForUpdate() { if (window.MyAppAndroid?.restartApp) MyAppAndroid.restartApp(); else location.reload(); }
// a new update from the developer: ask once per opening, like other apps ("Update now" / "Later")
function updateBanner() {
  const u = S.update;
  if (!u?.ready || S.updLater === u.ready || $("#upd-dlg")) return;
  const d = document.createElement("div"); d.id = "upd-dlg"; d.className = "upd-dlg"; d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true"); d.setAttribute("aria-labelledby", "upd-dlg-t");
  const kb = Math.max(1, Math.round((u.size || 0) / 1024));
  d.innerHTML = `<div class="upd-box"><div class="upd-hero" aria-hidden="true"><span>⬆</span></div>
    <h2 id="upd-dlg-t">Update available</h2>
    <p class="muted">${esc(u.notes || "Improvements and fixes")}</p>
    <div class="upd-facts"><span>${kb} KB</span><span>Takes a few seconds</span><span>Your data stays</span></div>
    <button class="btn primary upd-btn" id="upd-now">Update now</button>
    <button class="btn ghost upd-btn" id="upd-later">Later</button></div>`;
  document.body.append(d);
  const close = () => { S.updLater = u.ready; d.remove(); };
  $("#upd-now").onclick = () => { $("#upd-now").textContent = "Updating…"; $("#upd-now").disabled = true; restartForUpdate(); };
  $("#upd-later").onclick = close;
  d.onclick = e => { if (e.target === d) close(); };
  d.onkeydown = e => { if (e.key === "Escape") close(); };
  $("#upd-now").focus();
}
setTimeout(async () => { await renderUpdate(); if (!S.update?.ready && S.update?.enabled) renderUpdate(true); }, 3000);   // after the welcome screen: look for a developer update once setInterval(() => renderUpdate(), 30 * 60000);
$("#class-on").onchange = e => { savePortal({ classAlerts: e.target.checked }); renderSettings(); };
$("#class-alarm").onchange = e => savePortal({ classAlarm: e.target.checked });
$("#alarm-sound").onchange = e => savePortal({ alarmSound: e.target.value });
$("#alarm-vib").onchange = e => savePortal({ alarmVibrate: e.target.checked });
$("#alarm-rep").onchange = e => savePortal({ alarmRepeat: e.target.checked });
$("#class-lead").onchange = e => savePortal({ classLead: +e.target.value });
$("#class-test").onclick = async () => { const b = $("#class-test"); try { const r = await api("/api/alerts/class-test", "POST", {}); b.textContent = "Sent ✓ " + r.title; } catch (e) { b.textContent = e.message; } };
$("#alert-hour").onchange = e => savePortal({ alertHour: +e.target.value });
$("#startup-on").onchange = async e => { const r = await api("/api/startup", "POST", { enabled: e.target.checked }).catch(() => null); if (r) STATUS.startup = r.startup; renderSettings(); };
$("#alert-test").onclick = async () => { const b = $("#alert-test"); try { await api("/api/alerts/test", "POST", {}); b.textContent = "Sent ✓ (check your notifications)"; } catch (e) { b.textContent = "Couldn't send: " + e.message; } };
$("#quit").onclick = async () => { await api("/api/quit", "POST", {}).catch(() => { }); document.body.innerHTML = '<p style="padding:40px;font-family:sans-serif">Study Desk is closed. Open it again from the desktop icon.</p>'; };

/* phone & tablet pairing + backup (added into the settings column) */
function renderLan() {
  if (!$("#lan-card")) {
    $("#ai-info").closest(".card").insertAdjacentHTML("afterend", `<div class="card" id="lan-card"><span class="eyebrow">Phone &amp; tablet</span><div id="lan" class="small" style="margin-top:6px"></div></div>
      <div class="card small" id="backup-card"><span class="eyebrow">Backup &amp; move to another device</span>
        <p style="margin:6px 0" class="muted">One file holds everything: notes, marks, attendance, exams, portal links. Use it to move Study Desk to your tablet.</p>
        <div class="row"><a class="btn" href="/api/backup" download>Download backup</a><label class="btn" for="restore-f">Restore backup…</label><input type="file" id="restore-f" accept=".zip" hidden></div><p id="restore-msg" style="margin:6px 0 0"></p></div>`);
    $("#restore-f").onchange = async e => { const f = e.target.files[0]; if (!f) return; const m = $("#restore-msg"); m.textContent = "Restoring…";
      try { await api("/api/restore", "POST", f, true); m.innerHTML = '<span class="ok">Restored. Reloading…</span>'; setTimeout(() => location.reload(), 900); } catch (err) { m.innerHTML = `<span class="err">${esc(err.message)}</span>`; } };
  }
  const box = $("#lan");
  if (!STATUS.local) { box.innerHTML = '<p class="muted" style="margin:0">You are on a paired device. Pairing is managed on the main device.</p>'; return; }
  api("/api/lan").then(l => {
    box.innerHTML = `<label class="row" for="lan-on" style="gap:6px"><input type="checkbox" id="lan-on" ${l.enabled ? "checked" : ""}> Let my phone/tablet open Study Desk over Wi-Fi</label>
      ${l.enabled ? (l.urls.length ? `<p style="margin:8px 0 4px">On the same Wi-Fi, scan this with your phone camera:</p><div id="qr" style="background:#fff;padding:8px;border-radius:8px;width:fit-content"></div>
        <p style="margin:6px 0">or open <code>${esc(l.urls[0])}</code> and enter code <b class="num" style="font-size:1.2rem">${esc(l.code)}</b></p>
        <p class="muted" style="margin:0 0 6px">Then in Chrome tap ⋮ → <b>Add to Home screen</b>. Code changes every 10 minutes. ${l.devices.length} device${l.devices.length === 1 ? "" : "s"} paired.</p>
        <div class="row"><button class="btn sm" id="lan-new">New code</button>${l.devices.length ? '<button class="btn ghost sm danger" id="lan-revoke">Unpair all devices</button>' : ""}</div>` : '<p class="err">Not connected to a Wi-Fi network.</p>') : ""}`;
    $("#lan-on").onchange = async e => { await api("/api/lan", "POST", { enabled: e.target.checked }); renderLan(); };
    const nc = $("#lan-new"); if (nc) nc.onclick = async () => { await api("/api/lan/code", "POST", {}); renderLan(); };
    const rv = $("#lan-revoke"); if (rv) rv.onclick = async () => { await api("/api/lan/revoke", "POST", {}); renderLan(); };
    if (l.enabled && l.urls.length) loadScript("vendor/qrcode.min.js").then(() => { const q = qrcode(0, "M"); q.addData(`${l.urls[0]}/pair?code=${l.code}`); q.make(); $("#qr").innerHTML = q.createSvgTag({ cellSize: 4, margin: 2 }); }).catch(() => { });
  }).catch(() => { box.innerHTML = '<p class="muted">Unavailable.</p>'; });
}

/* =========================================================
   PROFILE (who you are: used to filter timetables and calendars)
   ========================================================= */
function profile() {
  const p = P(); p.profile = p.profile || {};
  return p.profile;
}
function me() {   // the student's identity + current courses, for relevance checks
  const pr = profile(), sem = P().sems[P().cur] || { subs: [] };
  const att = S.mirror?.attendance?.rows || [];
  const codes = [...new Set([...att.map(r => r.code), ...sem.subs.map(s => s.code)].filter(Boolean))];
  const names = codes.map(c => (att.find(r => r.code === c) || sem.subs.find(s => s.code === c) || {}).course || (sem.subs.find(s => s.code === c) || {}).n || "");
  const semNo = parseInt((S.mirror?.attendance?.sem || sem.name || "").replace(/\D/g, "")) || null;
  return { ...pr, codes, names, semNo };
}
const PROFILE_FIELDS = [["appName", "App name (shown in the sidebar and window)", ""], ["ttUrl", "Class timetable link (ATU)", ""], ["name", "Name", "portal"], ["email", "College email", "portal"], ["phone", "Phone", ""], ["campus", "Campus", "portal"], ["allotment", "Hostel allotment", "portal"],
  ["reg", "Register number", ""], ["roll", "Roll number", ""], ["branch", "Branch", ""], ["section", "Section", ""], ["batch", "Batch (joining year)", ""], ["programme", "Programme", ""], ["group", "WhatsApp class group name", ""], ["driveUrl", "My Drive folder link", ""]];
function mirrorProfile(win) {
  const pr = profile();
  return `<div class="card" style="max-width:720px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="font-size:1.15rem">Your profile</h3>${win ? '<button class="btn sm" id="pf-sync">Fill from myAmrita</button>' : ""}</div>
    <p class="small muted" style="margin:0 0 10px">Section, branch and roll number decide which timetable rows and calendar dates are yours. Study Desk copies only your name, email, campus and hostel from the portal, never Aadhaar, parents' details or income.</p>
    <div class="form" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">${PROFILE_FIELDS.map(([k, l, src]) => `<label for="pf-${k}">${l}${src ? ' <span class="muted">(myAmrita)</span>' : ""}<input type="text" id="pf-${k}" data-k="${k}" value="${esc(pr[k] || "")}"></label>`).join("")}</div>
    <p class="small" id="pf-msg" style="margin:8px 0 0"></p></div>`;
}
function profileCard() {
  const pr = profile(), p = P(), m = S.mirror || {}, sem = p.sems[p.cur] || { subs: [], name: "" };
  const rows = m.attendance?.rows || [], eff = r => r.present + r.dl + r.medical;
  const tot = rows.reduce((s, r) => s + r.total, 0), att = tot ? rows.reduce((s, r) => s + eff(r), 0) / tot * 100 : null;
  const graded = p.sems.flatMap(s => s.subs).filter(s => s.grade && s.grade !== "F"), credits = graded.reduce((s, x) => s + (+x.cr || 0), 0);
  const name = pr.name || "Your name", ini = name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  const stat = (v, l) => `<div class="pstat"><b class="num">${v}</b><span>${l}</span></div>`;
  const row = (l, v) => v ? `<div class="prow"><span>${l}</span><b>${esc(v)}</b></div>` : "";
  const link = (l, v, href) => v ? `<div class="prow"><span>${l}</span><b><a href="${esc(href)}">${esc(v)}</a></b></div>` : "";
  const hideSem = !!p.home?.hideSem;
  const next = upcoming()[0];
  const photo = S.photoUrl ? `<img src="${S.photoUrl}" alt="Profile photo">` : esc(ini);
  return `<div class="pcard card">
    <div class="pbanner"></div>
    <div class="phead"><div class="avatar-wrap"><div class="avatar">${photo}</div>
        <button class="pcam" id="pf-photo-btn" aria-label="Change photo" title="Change photo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></button></div>
      <div style="min-width:0"><h2>${esc(name)}</h2>
      <div class="muted">${esc(pr.reg || "")}</div>
      <div class="row" style="gap:6px;margin-top:6px"><span class="pill e">${esc(pr.programme || "B.Tech")}</span><span class="pill ok">${esc(pr.branch || "—")}-${esc(pr.section || "—")}</span><span class="pill">Batch ${esc(pr.batch || "")}</span></div></div></div>
    <div class="pstats">${stat(esc(sem.name || "—"), esc(m.attendance?.term || "semester"))}${stat(p.official?.cgpa || "—", "CGPA")}${stat(att === null ? "—" : att.toFixed(1) + "%", "attendance")}${stat(credits || "—", "credits earned")}${stat(sem.subs.length, "courses now")}</div>
    <div class="pgrid"><div>${row("Roll no", pr.roll)}${row("Register no", pr.reg)}${link("Phone", pr.phone, "tel:" + (pr.phone || "").replace(/[^\d+]/g, ""))}${link("College email", pr.email, "mailto:" + (pr.email || ""))}${row("Campus", pr.campus)}${row("Hostel", pr.allotment)}${row("WhatsApp group", pr.group)}</div>
      <div>${row("Next exam", next ? `${next.sub} · ${new Date(next.date + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short" })} (${next.days} d)` : "")}${row("Grades published", graded.length + " courses")}${row("Official SGPAs", Object.entries(p.official?.sgpa || {}).map(([k, v]) => k + ": " + v).join(" · "))}</div></div>
    <button class="psec" id="pf-sem-toggle" aria-expanded="${!hideSem}"><span>This semester · ${sem.subs.length} courses</span><span class="muted">${hideSem ? "Show ▾" : "Hide ▴"}</span></button>
    ${hideSem ? "" : `<div class="row" style="gap:6px">${sem.subs.map(s => `<span class="chip">${esc(s.code || "")} ${esc(s.n)}</span>`).join("")}</div>`}
    <div class="row" style="margin-top:6px"><button class="btn" id="pf-edit">Edit details</button></div>
    ${Lock.avail() ? `<div class="plock">
      <div class="plock-row"><div><b>App lock</b><div class="small muted">Ask for a password when My App opens</div></div>
        <label class="switch"><input type="checkbox" id="pf-lock" ${Lock.on() ? "checked" : ""}><span aria-hidden="true"></span><span class="sr">App lock</span></label></div>
      ${Lock.on() ? `<button class="btn sm" id="pf-pass-btn" aria-expanded="false">Change password</button>
      <form id="pf-pass" class="plock-form" hidden autocomplete="off">
        <input type="password" inputmode="numeric" pattern="[0-9]*" id="pp-old" placeholder="Current password" aria-label="Current password" maxlength="12">
        <input type="password" inputmode="numeric" pattern="[0-9]*" id="pp-new" placeholder="New password (4+ digits)" aria-label="New password" maxlength="12">
        <input type="password" inputmode="numeric" pattern="[0-9]*" id="pp-new2" placeholder="New password again" aria-label="New password again" maxlength="12">
        <div class="row"><button class="btn primary sm" type="submit">Save password</button><span class="small" id="pp-msg" aria-live="polite"></span></div></form>` : ""}</div>` : ""}
    <div id="pf-photo-menu" class="pmenu" hidden>
      <label class="btn sm" for="pf-file">Upload a photo</label><input type="file" id="pf-file" accept="image/*" hidden>
      ${canBrowse() ? '<button class="btn sm" id="pf-portal">Use my myAmrita photo</button>' : ""}
      ${S.photoUrl ? '<button class="btn ghost sm danger" id="pf-remove">Remove photo</button>' : ""}
      <span class="small muted" id="pf-photo-msg"></span></div></div>`;
}
/* profile photo: kept on this device as a small 512 px JPEG */
S.photoUrl = null;
async function loadPhoto() { try { const r = await fetch("/api/profile/photo", { cache: "no-store" }); S.photoUrl = r.ok ? URL.createObjectURL(await r.blob()) : null; } catch { S.photoUrl = null; } }
async function shrinkPhoto(blob) {
  const img = await createImageBitmap(blob), s = 512 / Math.max(img.width, img.height), c = document.createElement("canvas");
  c.width = Math.round(img.width * Math.min(1, s)); c.height = Math.round(img.height * Math.min(1, s));
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  return await new Promise(r => c.toBlob(r, "image/jpeg", 0.88));
}
async function savePhoto(blob) { await api("/api/profile/photo", "PUT", await shrinkPhoto(blob), true); await loadPhoto(); renderMirror(); }
function wireProfile() {
  const lk = $("#pf-lock"); if (lk) lk.onchange = () => { const p = P(); p.appLock = { ...(p.appLock || {}), off: !lk.checked }; touch(); renderMirror(); };
  const pbtn = $("#pf-pass-btn"); if (pbtn) pbtn.onclick = () => { const f = $("#pf-pass"); f.hidden = !f.hidden; pbtn.setAttribute("aria-expanded", !f.hidden); if (!f.hidden) $("#pp-old").focus(); };
  $$("#pf-pass input").forEach(i => i.oninput = () => { i.value = i.value.replace(/\D/g, ""); });   // numbers only
  const pform = $("#pf-pass"); if (pform) pform.onsubmit = async e => { e.preventDefault();
    const msg = t => { $("#pp-msg").innerHTML = t; }, o = $("#pp-old").value, n = $("#pp-new").value.trim(), n2 = $("#pp-new2").value.trim();
    if (!(await Lock.matches(o))) return msg('<span class="err">Current password is wrong.</span>');
    if (!/^\d{4,12}$/.test(n)) return msg('<span class="err">Use 4 to 12 numbers only.</span>');
    if (n !== n2) return msg("<span class=\"err\">The two new passwords don't match.</span>");
    const p = P(); p.appLock = { ...(p.appLock || {}), hash: await Lock.hash(n) }; touch();
    pform.reset(); msg('<span class="ok">✓ Password changed.</span>'); };
  const st = $("#pf-sem-toggle"); if (st) st.onclick = () => { const p = P(); p.home = p.home || {}; p.home.hideSem = !p.home.hideSem; touch(); renderMirror(); };
  const pb = $("#pf-photo-btn"); if (pb) pb.onclick = () => { const m = $("#pf-photo-menu"); m.hidden = !m.hidden; };
  const pfMsg = t => { const e = $("#pf-photo-msg"); if (e) e.innerHTML = t; };
  const pf = $("#pf-file"); if (pf) pf.onchange = async e => { const f = e.target.files[0]; if (!f) return; pfMsg("Saving…"); try { await savePhoto(f); } catch (err) { pfMsg(`<span class="err">${esc(err.message)}</span>`); } };
  const pp = $("#pf-portal"); if (pp) pp.onclick = async () => { pp.disabled = true; pfMsg("Getting your photo from myAmrita…");
    try { await api("/api/profile/photo/portal", "POST", {}); const r = await fetch("/api/profile/photo", { cache: "no-store" }); await savePhoto(await r.blob()); }
    catch (err) { pfMsg(`<span class="err">${esc(err.message)}</span>`); pp.disabled = false; } };
  const pr = $("#pf-remove"); if (pr) pr.onclick = async () => { await api("/api/profile/photo", "DELETE"); S.photoUrl = null; renderMirror(); };
  const pe = $("#pf-edit"); if (pe) pe.onclick = () => { S.pfEdit = true; renderMirror(); };
  const pd = $("#pf-done"); if (pd) pd.onclick = () => { S.pfEdit = false; renderMirror(); };
  $$("#mir-body [data-k]").forEach(i => i.onchange = () => { profile()[i.dataset.k] = i.value.trim(); touch(); applyName(); if (i.dataset.k === "ttUrl") syncTimetable(true); });
  const b = $("#pf-sync"); if (b) b.onclick = async () => { b.disabled = true; $("#pf-msg").textContent = "Reading your basic profile…";
    try { const d = await api("/api/portal/profile"); const pr = profile(), f = fromReg(d.reg) || {};
      delete d.email; delete d.reg;
      Object.entries({ ...f, ...d }).forEach(([k, v]) => { if (v && (!pr[k] || k in d)) pr[k] = v; });
      touch(); renderMirror(); $("#pf-msg").innerHTML = '<span class="ok">Filled from myAmrita.</span>'; }
    catch (e) { $("#pf-msg").innerHTML = `<span class="err">${esc(e.message)}</span>`; b.disabled = false; } };
}

/* =========================================================
   CALENDAR: import PDFs / WhatsApp exports, month view
   ========================================================= */
S.calMonth = null; S.calSel = null;
// default academic calendar (Amrita Bengaluru 2026-27 Odd Sem), shown to everyone until they upload their own
S.defCal = null;
fetch("/default-calendar.json", { cache: "no-cache" }).then(r => r.ok ? r.json() : null).then(d => { if (!d) return; S.defCal = d;
  renderCal?.(); if (S.tab === "home") renderHome(); if (S.tab === "today") renderTodayPage(); }).catch(() => { });
const usingDefaultCal = () => !(P().events || []).length && !!S.defCal?.events?.length;
function allEvents() {
  const ev = (P().events || []).map(e => ({ ...e }));
  // the built-in semester calendar always fills every month; your own uploaded dates are added on top (no duplicates)
  const key = e => e.start + "|" + (e.type === "holiday" ? "H" : e.title.toLowerCase());
  const have = new Set(ev.map(key));
  (S.defCal?.events || []).forEach((e, i) => { if (!have.has(key(e))) ev.push({ ...e, id: "def-" + i, fromDefault: true }); });
  allExams().forEach(x => ev.push({ id: x.id, title: `${x.sub} ${x.type}`, type: /assignment|project/i.test(x.type) ? "deadline" : "exam", start: x.date, end: x.date, time: x.time, fromExams: true }));
  return ev.sort((a, b) => a.start.localeCompare(b.start));
}
function renderCal() {
  const base = S.calMonth ? new Date(S.calMonth + "-01T00:00") : new Date(); base.setDate(1);
  S.calMonth = iso(base).slice(0, 7);
  $("#cal-month").textContent = base.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  let dn = $("#cal-default-note");
  if (!dn) { $("#cal-grid").insertAdjacentHTML("beforebegin", '<p id="cal-default-note" class="small" style="margin:0 0 10px"></p>'); dn = $("#cal-default-note"); }
  dn.innerHTML = usingDefaultCal() ? `<b>Default calendar:</b> ${esc(S.defCal.name)}. Upload your own calendar to replace it.` : "";
  dn.hidden = !usingDefaultCal();
  // the calendar shows working / non-working days only: exams live on the Exams page, not here
  const ev = allEvents().filter(e => e.type !== "exam" && !e.fromExams), today = iso(Date.now()), semW = Cal.semWindow();
  const start = new Date(base); start.setDate(1 - ((base.getDay() + 6) % 7));   // weeks start on Monday
  let html = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(d => `<div class="dow">${d}</div>`).join("");
  for (let i = 0; i < 42; i++) {
    const d = new Date(start); d.setDate(start.getDate() + i); const k = iso(d);
    const items = ev.filter(e => e.start <= k && (e.end || e.start) >= k);
    // every day is H (non-working) or W (working): a holiday in the calendar, or a Sunday outside the semester's calendar
    const hol = items.some(e => e.type === "holiday") || ((k < semW.start || k > semW.end) && d.getDay() === 0);
    const types = [...new Set(items.filter(e => e.type !== "holiday").map(e => e.type))];
    const badge = hol ? '<span class="hw h">H</span>' : '<span class="hw w">W</span>';
    html += `<button data-d="${k}" class="${d.getMonth() !== base.getMonth() ? "out" : ""} ${k === today ? "today" : ""} ${k === S.calSel ? "sel" : ""} ${hol ? "hol" : ""}" aria-label="${k}, ${hol ? "non-working day" : "working day"}${types.length ? ", " + types.join(", ") : ""}"><span class="dn">${d.getDate()}</span>${badge}<span class="dots">${types.map(t => `<i class="dot d-${t}"></i>`).join("")}</span></button>`;
  }
  $("#cal-grid").innerHTML = `<div class="cal">${html}</div>`;
  $$("#cal-grid [data-d]").forEach(b => b.onclick = () => { S.calSel = b.dataset.d; renderCal(); });
  const sel = S.calSel && ev.filter(e => e.start <= S.calSel && (e.end || e.start) >= S.calSel);
  $("#cal-day").innerHTML = sel ? (sel.length ? `<b>${new Date(S.calSel + "T00:00").toDateString()}</b>${sel.map(e => evRow(e, true)).join("")}` : `<span class="muted">${new Date(S.calSel + "T00:00").toDateString()}: nothing on this day.</span>`) : '<span class="muted">Click a date to see what\'s on.</span>';
  $$("#p-cal [data-del-ev]").forEach(b => b.onclick = async () => { await listDel("events", b.dataset.delEv).catch(() => { }); renderCal(); });
}
function evRow(e, canDel) {
  const days = Math.round((new Date(e.start + "T00:00") - new Date(iso(Date.now()) + "T00:00")) / DAY);
  const when = e.end && e.end !== e.start ? `${fmtDay(e.start)} → ${fmtDay(e.end)}` : fmtDay(e.start);
  return `<div class="ev"><span class="tag t-${e.type}" style="font-size:.72rem">${e.type}</span><div style="min-width:0"><b>${esc(e.title)}</b><div class="small muted">${when}${e.time ? " · " + esc(e.time) : ""}${days >= 0 ? ` · ${days === 0 ? "today" : days === 1 ? "tomorrow" : "in " + days + " days"}` : ""}${e.why ? " · " + esc(e.why) : ""}</div></div>${canDel && !e.fromExams && !e.fromDefault ? `<button class="btn ghost sm" data-del-ev="${esc(e.id)}" aria-label="Remove">✕</button>` : "<span></span>"}</div>`;
}
const fmtDay = d => new Date(d + "T00:00").toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" });
$("#cal-prev").onclick = () => { const d = new Date(S.calMonth + "-01T00:00"); d.setMonth(d.getMonth() - 1); S.calMonth = iso(d).slice(0, 7); renderCal(); };
$("#cal-next").onclick = () => { const d = new Date(S.calMonth + "-01T00:00"); d.setMonth(d.getMonth() + 1); S.calMonth = iso(d).slice(0, 7); renderCal(); };
$("#cal-today").onclick = () => { S.calMonth = null; S.calSel = iso(Date.now()); renderCal(); };
const calMsg = (t, cls) => { const m = $("#cal-msg"); m.className = "small " + (cls || "muted"); m.innerHTML = t; };
/* =========================================================
   UPLOAD ANYTHING: one button for every file; Study Desk suggests Calendar (dates) or Notes (study material)
   ========================================================= */
const WA_LINE = /^\[?\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4},?\s+\d{1,2}:\d{2}/m;
const manyDates = text => { const hint = Cal.academicYearHint(), ls = text.split("\n").filter(l => l.trim());
  const withDates = ls.filter(l => Cal.findDates(l, hint).length).length; return withDates >= 6 && withDates / Math.max(1, ls.length) > 0.12; };
async function detectUpload(file) {
  const name = file.name.toLowerCase();
  if (/\.(ics|csv)$/.test(name)) return { to: "dates", why: name.endsWith(".ics") ? "a calendar file" : "a table of dates" };
  if (file.type.startsWith("image/")) return { to: "notes", why: "a photo. If it's a notice or timetable, add it to the Calendar instead" };
  if (file.type === "application/pdf" || name.endsWith(".pdf")) {
    const r = await Engine.readPdf(file); const text = r.lines.map(l => l.t).join("\n");
    if (text.replace(/\s/g, "").length < 60 * r.pages) {   // scanned: one quick look at the first heading
      const head = await Engine.headingText(r.pdf, 1).catch(() => "");
      return /time\s*-?\s*table|schedule|end\s*semester|examination|calendar|notice|circular/i.test(head) ? { to: "dates", why: "a scanned timetable / calendar" } : { to: "notes", why: "scanned study material" };
    }
    if (Cal.isDayRowTable(r.lines)) return { to: "dates", why: "an academic calendar" };
    if (/academic\s*calendar|time\s*-?\s*table|schedule for|examination schedule/i.test(text.slice(0, 1500)) || manyDates(text)) return { to: "dates", why: "a timetable / list of dates" };
    return { to: "notes", why: "study material" };
  }
  const r = await api(`/api/extract?name=${encodeURIComponent(file.name)}`, "POST", file, true).catch(() => null);
  const text = r ? r.lines.join("\n") : "";
  if ((r && r.kind === "whatsapp") || WA_LINE.test(text)) return { to: "dates", why: "a WhatsApp chat" };
  if (/\.pptx$/.test(name)) return { to: "notes", why: "slides" };
  if (/academic\s*calendar|time\s*-?\s*table|schedule for/i.test(text.slice(0, 1500)) || manyDates(text)) return { to: "dates", why: "a notice / list of dates" };
  return { to: "notes", why: "study material" };
}
/* each file is handled start to finish inside its own row of the Upload window */
function sendUpload(file, to, row) {
  const ui = { msg: (t, cls) => { const m = row.querySelector(".up-msg"); m.className = "small up-msg " + (cls || "muted"); m.innerHTML = t; }, box: row.querySelector(".up-body") };
  row.querySelector(".up-act").hidden = true;
  if (to === "dates") importDates(file, { ui });
  else makeNotesFrom(file, ui);
}
async function makeNotesFrom(file, ui) {
  ui.msg("Making notes, mind map and flashcards…");
  setPicked([file]);
  await generate();
  const n = S.current;
  if (n && !n.example && n.source === file.name) {
    ui.msg(`<span class="ok">✓ Notes ready: <b>${esc(n.title)}</b> (${n.notes.sections.length} sections, ${n.tools.flashcards.length} flashcards).</span>`);
    ui.box.innerHTML = '<button class="btn primary sm">Open notes</button>';
    ui.box.querySelector("button").onclick = () => { $("#up-dlg").close(); setTab("notes"); };
  } else ui.msg(`<span class="err">${$("#gen-msg").innerHTML || "Couldn't make notes from this file."}</span>`);
}
async function addUploads(files) {
  const list = $("#up-list");
  for (const f of files) {
    const row = document.createElement("div"); row.className = "upf";
    row.innerHTML = `<b style="overflow-wrap:anywhere">${esc(f.name)}</b><span class="small up-msg muted">Checking what this is…</span><div class="row up-act"></div><div class="up-body"></div>`;
    list.prepend(row);
    let d; try { d = await detectUpload(f); } catch { d = { to: "notes", why: "a file" }; }
    row.querySelector(".up-msg").innerHTML = `Looks like <b>${esc(d.why)}</b>.`;
    row.querySelector(".up-act").innerHTML = `<button class="btn ${d.to === "dates" ? "primary" : ""} sm" data-to="dates">📅 Add dates to Calendar</button><button class="btn ${d.to === "notes" ? "primary" : ""} sm" data-to="notes">📝 Make study notes</button>`;
    row.querySelectorAll("[data-to]").forEach(b => b.onclick = () => sendUpload(f, b.dataset.to, row));
  }
}
$("#up-open").onclick = () => { $("#up-list").innerHTML = ""; $("#up-dlg").showModal(); };
$("#up-close").onclick = () => $("#up-dlg").close();
$("#up-file").onchange = e => { addUploads([...e.target.files]); e.target.value = ""; };
{ const d = $("#up-drop");
  ["dragenter", "dragover"].forEach(ev => d.addEventListener(ev, e => { e.preventDefault(); d.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => d.addEventListener(ev, e => { e.preventDefault(); d.classList.remove("over"); }));
  d.addEventListener("drop", e => addUploads([...e.dataTransfer.files])); }
// dropping a file anywhere on the page opens the same window
document.addEventListener("dragover", e => { if ([...(e.dataTransfer?.types || [])].includes("Files")) e.preventDefault(); });
document.addEventListener("drop", e => { if (e.target.closest("#up-dlg, .drop") || !e.dataTransfer?.files.length) return; e.preventDefault();
  $("#up-list").innerHTML = ""; if (!$("#up-dlg").open) $("#up-dlg").showModal(); addUploads([...e.dataTransfer.files]); });

async function importDates(file, opts = {}) {
  const ui = opts.ui || { msg: calMsg, box: $("#cal-review") }, say = ui.msg;
  const m = me(); let kind = opts.kind || "auto", text = "", found = [];
  try {
    if (/\.pdf$/i.test(file.name) || file.type === "application/pdf") {
      say("Reading the PDF…");
      const r = await Engine.readPdf(file, (p, n) => say(`Reading page ${p} of ${n}…`));
      let lines = r.lines, ocrPages = null;
      if (lines.reduce((n, l) => n + l.t.length, 0) < 60 * r.pages) {   // scanned: free OCR, keeping where each word sits
        say("Scanned PDF, so I'm reading it with free OCR (about 30 s)…");
        const head = kind === "auto" ? await Engine.headingText(r.pdf, 1) : "";
        if (kind === "timetable" || /time\s*-?\s*table|schedule for end|end\s*semester|examination|\bFN\b|\bAN\b/i.test(head)) {
          kind = "timetable";   // read only the page for the student's batch / semester, closely
          const t = await Engine.ocrTimetable(r.pdf, text => Cal.pageIsMine(text, m), s => say(s));
          ocrPages = t.pages;
        } else ocrPages = await Engine.ocrWords(await Engine.pdfPagesToCanvas(r.pdf, 12, 3), (p, n) => say(`Free OCR: page ${p} of ${n}…`));
        lines = ocrPages.flatMap(pg => pg.lines.map(l => ({ t: l.t, s: 10, p: pg.page, y: l.y })));
      }
      text = lines.map(l => l.t).join("\n");
      if (kind === "auto") kind = /time\s*-?\s*table|examination schedule|exam schedule|end\s*semester|\bFN\b|\bAN\b|session/i.test(text) && (m.codes.some(c => text.includes(c)) || /\d{2}[A-Z]{2,4}\d{3}/.test(text)) ? "timetable" : "calendar";
      if (kind !== "timetable" && Cal.isDayRowTable(lines)) { kind = "calendar"; found = Cal.fromDayRows(lines, m); }
      else if (kind === "timetable" && ocrPages) found = Cal.fromGridWords(ocrPages, m);   // only your current courses are picked
      else found = Cal.fromLines(lines, m, kind);
    } else if (file.type.startsWith("image/")) {   // photo or screenshot of a notice / timetable
      say("Reading the image with free OCR…");
      const lines = await Engine.ocr([file], () => { });
      text = lines.map(l => l.t).join("\n");
      if (kind === "auto") kind = /\b(FN|AN)\b|time\s*-?\s*table/i.test(text) ? "timetable" : "calendar";
      found = Cal.fromLines(lines, m, kind);
    } else {   // Word, Excel, PowerPoint, CSV, HTML, .ics, WhatsApp .txt/.zip, plain text
      say("Reading the file…");
      const r = await api(`/api/extract?name=${encodeURIComponent(file.name)}`, "POST", file, true);
      text = r.lines.join("\n");
      if (kind === "auto") kind = r.kind || (/^\[?\d{1,2}\/\d{1,2}\/\d{2,4},?\s+\d{1,2}:\d{2}/m.test(text) ? "whatsapp" : /\b(FN|AN)\b|time\s*-?\s*table/i.test(text) && /\d{2}[A-Z]{2,5}\d{3}/.test(text) ? "timetable" : "calendar");
      found = kind === "whatsapp" ? Cal.fromWhatsApp(text, m) : Cal.fromLines(Engine.textToLines(text), m, kind);
    }
    showFound(found, kind, file.name, 0, ui);
    if (opts.ai && aiOn() && text) {
      say(`Found ${found.length} dates. The free AI is double-checking for anything missed (a minute or two)…`);
      try { const j = await ai(Cal.AI_PROMPT(text, m, kind), { json: true }); const extra = Cal.fromAi(j, m).filter(a => !found.some(f => f.start === a.start && (f.title.toLowerCase().includes(a.title.toLowerCase().slice(0, 12)) || a.title.toLowerCase().includes(f.title.toLowerCase().slice(0, 12)))));
        found = Cal.dedupe([...found, ...extra]); showFound(found, kind, file.name, extra.length, ui); }
      catch (e) { say(`Found ${found.length} dates. (The AI check failed: ${esc(e.message)})`); }
    }
  } catch (e) { say(esc(e.message || "Couldn't read that file."), "err"); }
}
function showFound(found, kind, name, aiAdded, ui) {
  ui = ui || { msg: calMsg, box: $("#cal-review") };
  const label = { calendar: "academic calendar", timetable: "exam timetable", whatsapp: "WhatsApp chat" }[kind] || kind;
  const today = iso(Date.now()), known = new Set([...(P().events || []).map(e => e.start + "|" + e.title.toLowerCase()), ...P().exams.map(x => x.date + "|" + (x.sub + " " + x.type).toLowerCase())]);
  // only the current semester: dates inside its window, and exams of this semester's courses
  const sw = Cal.semWindow(), inSem = f => f.start <= sw.end && (f.end || f.start) >= sw.start && f.rel !== -1;
  const skipped = found.filter(f => !inSem(f)).length;
  const isDup = f => known.has(f.start + "|" + f.title.toLowerCase()) || (f.code && P().exams.some(x => x.date === f.start && (me().names[me().codes.indexOf(f.code)] || "") === x.sub));
  const list = found.filter(inSem).map(f => ({ ...f, dup: isDup(f) }));
  S.found = list;
  const weekly = list.filter(f => f.weekly), rest = list.filter(f => !f.weekly);
  const fresh = list.filter(f => f.rel > 0 && !f.dup && (f.end || f.start) >= today);
  ui.msg(`Read your ${label}: <b>${fresh.length}</b> new date${fresh.length === 1 ? "" : "s"} for ${esc(sw.name)} look like yours${aiAdded ? ` (${aiAdded} added by AI)` : ""}.${skipped ? ` Skipped ${skipped} from other semesters or courses.` : ""}${list.some(f => f.dup) ? " Dates you already have are greyed out." : ""}`, "ok");
  ui.box.innerHTML = `<div class="row" style="margin:6px 0"><button class="btn primary sm" data-add>Add to Calendar</button><button class="btn ghost sm" data-none>Untick all</button></div>
    ${weekly.length ? `<label class="change"><input type="checkbox" data-wk ${weekly.some(f => !f.dup && (f.end || f.start) >= today) ? "checked" : ""}><span><b>${weekly.length} weekend holidays</b> (Sundays, 2nd &amp; 4th Saturdays)</span></label>` : ""}
    ${rest.length ? rest.map((f, i) => `<label class="change ${f.rel <= 0 || f.dup ? "dim" : ""}"><input type="checkbox" data-i="${i}" ${f.rel > 0 && !f.dup && (f.end || f.start) >= today ? "checked" : ""}><span><span class="tag t-${f.type}" style="font-size:.7rem">${f.type}</span> <b>${esc(f.title)}</b> · ${f.end && f.end !== f.start ? fmtDay(f.start) + " → " + fmtDay(f.end) : fmtDay(f.start)}${f.time ? " " + esc(f.time) : ""} <span class="muted small">(${esc(f.dup ? "already added" : f.why)})</span></span></label>`).join("") : (weekly.length ? "" : '<p class="muted">No dates found in this file.</p>')}`;
  const addBtn = ui.box.querySelector("[data-add]");
  const pickedItems = () => [...rest.filter((f, i) => ui.box.querySelector(`[data-i="${i}"]`)?.checked), ...(ui.box.querySelector("[data-wk]")?.checked ? weekly.filter(f => !f.dup && (f.end || f.start) >= today) : [])];
  const count = () => { const n = pickedItems().length; addBtn.textContent = `Add ${n} to Calendar`; addBtn.disabled = !n; };
  ui.box.querySelectorAll("input[type=checkbox]").forEach(c => c.onchange = count); count();
  ui.box.querySelector("[data-none]").onclick = () => { ui.box.querySelectorAll("input[type=checkbox]").forEach(c => c.checked = false); count(); };
  addBtn.onclick = async () => {
    const exams = [], events = [];
    pickedItems().forEach(f => {
      const code = f.code || (me().codes || []).find(c => f.title.toUpperCase().includes(c) || (f.src || "").toUpperCase().includes(c));
      if (f.type === "exam" && (code || kind === "timetable")) {
        const nm = code ? (me().names[me().codes.indexOf(code)] || code) : f.title;
        const type = f.examType || (/mid/i.test(f.title + f.src) ? "Mid-sem" : /end|ese|semester exam/i.test(f.title + f.src) ? "End-sem" : /lab|practical/i.test(f.title + f.src) ? "Lab exam" : /quiz/i.test(f.title) ? "Quiz" : "Exam");
        exams.push({ id: uid(), sub: nm, type, date: f.start, time: f.time || "", syl: code ? "" : f.title });
      } else events.push({ id: uid(), title: f.title, type: f.type, start: f.start, end: f.end || f.start, time: f.time || "", why: f.why, weekly: !!f.weekly });
    });
    addBtn.disabled = true; addBtn.textContent = "Saving…";
    try { await listAdd("exams", exams); await listAdd("events", events); }
    catch (e) { ui.msg("Couldn't save: " + esc(e.message), "err"); addBtn.disabled = false; return; }
    renderPlanner(); renderCal();
    ui.msg(`<span class="ok">✓ Added ${exams.length} exam${exams.length === 1 ? "" : "s"} and ${events.length} date${events.length === 1 ? "" : "s"} to your Calendar.</span>`);
    ui.box.innerHTML = '<button class="btn primary sm">Open Calendar</button>';
    ui.box.querySelector("button").onclick = () => { if ($("#up-dlg").open) $("#up-dlg").close(); setTab("cal"); };
  };
  renderCal();
}

/* =========================================================
   AUMS: grades, credits, official SGPA/CGPA (saved sign-in, or the student signs in)
   ========================================================= */
function applyAums(cache) {
  const p = P(), letters = new Set(Object.values(GP).flat().map(x => x[0]));
  let n = 0, nc = 0; const off = p.official = p.official || {};
  p.scale = "amrita";   // AUMS SGPAs match O 10 · A+ 9.5 · A 9 · B+ 8 · B 7 · C 6 · P 5 exactly
  const semOfLabel = l => (String(l).match(/·\s*(\d{1,2})\s*$/) || [])[1];
  (cache.pages || []).forEach(pg => {
    const text = pg.text || "";
    const cg = text.match(/\bCGPA\s*[:\-]?\s*(\d{1,2}\.\d{1,2})/i); if (cg) off.cgpa = cg[1];
    const pf = profile(), g = re => ((text.match(re) || [])[1] || "").trim();
    if (!pf.name && g(/\bName\s*\n\s*([^\n]+)/)) pf.name = g(/\bName\s*\n\s*([^\n]+)/);
    if (!pf.reg && g(/Roll No\s*\n\s*([A-Z0-9.]+)/)) pf.reg = g(/Roll No\s*\n\s*([A-Z0-9.]+)/);
    if (!pf.programme && g(/Program\s*&\s*Branch\s*\n\s*([^\n]+)/)) pf.programme = g(/Program\s*&\s*Branch\s*\n\s*([^\n]+)/).replace(/(\D)(\d{4})/, "$1 $2");
    (pg.tables || []).forEach(t => {
      const H = t[0].map(h => h.toLowerCase()), ix = re => H.findIndex(h => re.test(h));
      const gC = ix(/^grade$|grade\s*(obtained|awarded|secured)?$/), crC = ix(/credit/), codeC = ix(/code/), nameC = ix(/course name|subject|title|paper/), semC = ix(/^sem|semester/);
      // AUMS "View Course Registration": Course Code · Course Name · … · Credits
      if (gC < 0 && crC >= 0 && codeC >= 0) {
        const semNo = semOfLabel(pg.label);
        t.slice(1).forEach(r => { const code = (r[codeC] || "").trim(), cr = parseFloat(r[crC]); if (!code || isNaN(cr)) return;
          let sem = p.sems.find(s => s.subs.some(x => x.code === code));
          if (!sem && semNo) sem = p.sems.find(s => s.name === "Sem " + semNo) || (p.sems.push({ id: uid(), name: "Sem " + semNo, subs: [] }), p.sems[p.sems.length - 1]);
          if (!sem) return;
          let s = sem.subs.find(x => x.code === code);
          if (!s) { s = { n: (nameC >= 0 ? r[nameC] : code).trim(), code, cr, io: null, im: 70 }; sem.subs.push(s); }
          if (!s.crSet) { s.cr = cr; nc++; }
        });
        return;
      }
      // AUMS "View Grades" ends with an SGPA row for that semester
      if (gC >= 0 && semC >= 0) { const sg = text.match(/\bSGPA\s*[:\-]?\s*(\d{1,2}\.\d{1,2})/i), s1 = (t[1] || [])[semC]; if (sg && s1) (off.sgpa = off.sgpa || {})["Sem " + parseInt(s1)] = sg[1]; }
      if (gC < 0 || (crC < 0 && codeC < 0)) return;
      t.slice(1).forEach(r => {
        const grade = (r[gC] || "").trim().toUpperCase(); if (!letters.has(grade)) return;
        const code = codeC >= 0 ? r[codeC].trim() : ((r.join(" ").match(/\b\d{2}[A-Z]{2,5}\d{3}\b/) || [""])[0]);
        const name = nameC >= 0 && nameC !== codeC ? r[nameC].replace(/^\s*\d{2}[A-Z]{2,5}\d{3}\s*/, "").trim() : code;
        let sem = p.sems.find(s => s.subs.some(x => x.code && x.code === code));
        if (!sem && semC >= 0) { const sn = "Sem " + (parseInt(r[semC]) || ""); sem = p.sems.find(s => s.name === sn) || (p.sems.push({ id: uid(), name: sn, subs: [] }), p.sems[p.sems.length - 1]); }
        if (!sem) return;
        let s = sem.subs.find(x => (x.code && x.code === code) || (name && x.n && x.n.toLowerCase() === name.toLowerCase()));
        if (!s) { s = { n: name || code, code, cr: null, io: null, im: 70 }; sem.subs.push(s); }
        if (crC >= 0 && !isNaN(parseFloat(r[crC]))) s.cr = parseFloat(r[crC]);
        s.grade = grade; s.gradeSrc = "aums"; s.whatIf = null; n++;
      });
    });
  });
  p.sems.sort((a, b) => (parseInt(a.name.replace(/\D/g, "")) || 99) - (parseInt(b.name.replace(/\D/g, "")) || 99));
  // AUMS published marks → myAmrita › Marks (only what myAmrita lacks is shown; AUMS Mid-Term fills a missing one)
  const am = Portal.aumsMarksFrom(cache);
  if (Object.keys(am).length) {
    S.mirror = S.mirror || { marks: [], attendance: null, gatepass: null };
    S.mirror.aumsMarks = am;
    if (S.mirror.marks?.length) Portal.applyMirror(S.mirror, p, uid);
    api("/api/mirror", "PUT", S.mirror).catch(() => { });
    if (S.tab === "mirror") renderMirror();
  }
  p.aumsAt = cache.fetchedAt;
  touch(); renderMarks();
  return { grades: n, credits: nc };
}
const aumsMsg = t => $("#aums-msg").innerHTML = t;
function aumsSummary(r) {
  const o = P().official || {};
  return `<span class="ok">AUMS: ${r.grades} grades, ${r.credits} credits${o.cgpa ? `, CGPA <b>${esc(o.cgpa)}</b>` : ""}${o.sgpa ? " · " + Object.entries(o.sgpa).map(([k, v]) => `${esc(k)} SGPA ${esc(v)}`).join(" · ") : ""}.</span>`;
}
$("#aums-sync").onclick = () => runAums(false);
async function runAums(quiet) {
  const b = $("#aums-sync");
  if (!canBrowse()) { if (!quiet) aumsMsg('<span class="err">AUMS sync runs on the PC or in My App on the hub tablet.</span>'); return; }
  const si = await api("/api/aums/signin").catch(() => ({}));
  try { await api("/api/aums/sync", "POST", {}); } catch (e) { if (!quiet) aumsMsg(`<span class="err">${esc(e.message)}</span>`); return; }
  b.disabled = true;
  aumsMsg(si.saved ? "Signing in to AUMS in the background…" : `${window.MyAppAndroid ? "A sign-in window opened" : "An Edge window opened"}. <b>Sign in to AUMS there</b>. Tip: save your AUMS sign-in below and you'll never have to do this again.`);
  const poll = setInterval(async () => {
    const st = await api("/api/aums/status").catch(() => null); if (!st) return;
    if (st.status === "reading") aumsMsg("Signed in. Reading your grades and credits…");
    if (st.status === "done" || st.status === "error") {
      clearInterval(poll); b.disabled = false;
      if (st.status === "error") { aumsMsg(`<span class="err">${esc(st.message)}</span>`); renderAumsSignin(); return; }
      aumsMsg(aumsSummary(applyAums(await api("/api/aums/cache")))); renderAumsSignin();
    }
  }, 2000);
}
/* saved AUMS sign-in: typed by the student, kept encrypted by Windows on this PC */
async function renderAumsSignin() {
  if (!$("#aums-signin")) $("#aums-msg").insertAdjacentHTML("afterend", '<div id="aums-signin" class="small" style="margin:0 0 10px"></div>');
  const box = $("#aums-signin");
  if (!canBrowse()) { box.innerHTML = ""; return; }
  const si = await api("/api/aums/signin").catch(() => null); if (!si) return;
  const droid = !!window.MyAppAndroid;
  box.innerHTML = si.saved
    ? `<span class="chip good">AUMS sign-in saved for ${esc(si.username)}</span> Grades and credits refresh by themselves every week${si.lastSync ? ` (last: ${new Date(si.lastSync).toLocaleString()})` : ""}. <button class="btn ghost sm" id="aums-forget">Remove saved sign-in</button>`
    : `<details><summary>Stop signing in every time: save your AUMS sign-in on this ${droid ? "tablet" : "PC"}</summary>
        <form id="aums-form" class="row" style="margin-top:8px" autocomplete="off"><input type="text" id="aums-u" placeholder="AUMS username" autocomplete="off" required>
        <input type="password" id="aums-p" placeholder="AUMS password" autocomplete="new-password" required><button class="btn primary sm">Save &amp; sync</button></form>
        <p class="muted" style="margin:6px 0 0">${droid ? "Kept inside the My App app, encrypted with a key locked in Android Keystore. The hub only stores your username." : "Encrypted with Windows' own protection (DPAPI): only your Windows account on this PC can unlock it."} It's never sent anywhere except the AUMS sign-in page, and it isn't included in backups.</p></details>`;
  const f = $("#aums-form"); if (f) f.onsubmit = async e => { e.preventDefault();
    try {
      const u = $("#aums-u").value.trim(), pw = $("#aums-p").value;
      if (droid) { const r = MyAppAndroid.saveAums(pw); if (r !== "ok") throw new Error(r); await api("/api/aums/signin", "POST", { username: u }); }
      else await api("/api/aums/signin", "POST", { username: u, password: pw });
      $("#aums-p").value = ""; await renderAumsSignin(); runAums(false); }
    catch (err) { aumsMsg(`<span class="err">${esc(err.message)}</span>`); } };
  const fg = $("#aums-forget"); if (fg) fg.onclick = async () => { if (droid) MyAppAndroid.forgetAums(); await api("/api/aums/signin", "DELETE"); renderAumsSignin(); };
}


/* first run for a new student: everything comes from their own myAmrita / AUMS sign-in */
function fromReg(reg) {   // BL.SC.U4AIE25000 -> branch AIE, batch 2025, roll 25000, college email bl.sc.u4aie25000@bl.students.amrita.edu
  const r = (reg || "").trim().toLowerCase(), m = r.match(/^([a-z]{2})\.([a-z]{2})\.([a-z]\d)([a-z]+)(\d{2})(\d{3})$/);
  return m && { reg: r.toUpperCase(), branch: m[4].toUpperCase(), batch: "20" + m[5], roll: m[5] + m[6], email: `${r}@${m[1]}.students.amrita.edu` };
}
function semesterNow(batch) { const d = new Date(); return Math.max(1, (d.getFullYear() - +batch) * 2 + (d.getMonth() >= 6 ? 1 : 0)); }
function welcome() {   // portal first: sign in once, the app fetches who you are; one short form for the rest
  if ($("#welcome")) return;
  const droid = !!window.MyAppAndroid;
  document.body.insertAdjacentHTML("beforeend", `<dialog id="welcome" class="wl" aria-labelledby="wl-title">
    <div class="wl-card">
      <img src="icon-192.png" alt="" class="wl-logo" width="72" height="72">
      <h2 id="wl-title">Welcome to ${esc(appName())}</h2>
      <p class="wl-sub">Your attendance, marks, gate passes, grades and CGPA, fetched from your own myAmrita and AUMS. Everything stays on this device.</p>
      <div class="wl-dots" aria-hidden="true"><i class="on"></i><i></i><i></i></div>
      <div id="wl-body"></div>
      <p class="wl-msg" id="wl-msg" role="status"></p>
      <p class="wl-credit">Developed by <b>Basare Mallikarjun</b></p>
    </div></dialog>`);
  const dlg = $("#welcome"), body = $("#wl-body"), msg = t => { $("#wl-msg").innerHTML = t; };
  const dots = n => $$("#welcome .wl-dots i").forEach((d, i) => d.classList.toggle("on", i <= n));
  dlg.addEventListener("cancel", e => e.preventDefault());
  const wait = ms => new Promise(r => setTimeout(r, ms));

  // 1. myAmrita sign-in -> name, register no, branch, batch, roll, college email, mobile, campus, hostel, photo
  const step1 = () => {
    dots(0);
    body.innerHTML = `<button class="btn primary wl-big" id="wl-mya">Sign in with myAmrita</button>
      <p class="wl-hint">Use your college Microsoft account. Tick <b>Stay signed in</b>, wait until myAmrita opens, then tap <b>Done</b>.</p>`;
    $("#wl-mya").onclick = async () => {
      const b = $("#wl-mya"); b.disabled = true; b.textContent = "Waiting for sign-in…"; msg("");
      try {
        await api("/api/portal/login", "POST", { url: "https://students.amrita.edu/client/index" });
        await wait(2500);
        for (let i = 0; i < 600; i++) { const st = await api("/api/status").catch(() => null); if (st && !st.portal.login_open && !st.portal.login_pending) break; await wait(1500); }
        b.textContent = "Reading your profile…";
        const d = await api("/api/portal/profile");
        const f = fromReg(d.reg);
        if (!f) throw new Error("Couldn't read your register number from myAmrita. Sign in again and wait until myAmrita opens before tapping Done.");
        delete d.email;   // myAmrita's Email field is the personal one; keep the college email
        Object.assign(profile(), d, f);
        touch();
        api("/api/profile/photo/portal", "POST", {}).then(async () => { const r = await fetch("/api/profile/photo", { cache: "no-store" }); await savePhoto(await r.blob()); }).catch(() => { });
        step2();
      } catch (err) { msg(`<span class="err">${esc(err.message)}</span>`); b.disabled = false; b.textContent = "Sign in with myAmrita"; }
    };
  };

  // 2. one form: the section (no portal shows it) + AUMS sign-in
  const step2 = () => {
    dots(1);
    const pr = profile();
    body.innerHTML = `<div class="wl-me"><b>Hi ${esc((pr.name || "").split(" ").slice(-1)[0] || pr.name || "")}!</b>
        <span>${esc(pr.reg || "")} · ${esc(pr.branch)} · batch ${esc(pr.batch)}${pr.campus ? " · " + esc(pr.campus) : ""}</span></div>
      <form id="wl-form" class="wl-form" autocomplete="off">
        <label>Section <small>myAmrita doesn't show it</small><input type="text" id="wl-sec" maxlength="2" placeholder="A" required autocapitalize="characters"></label>
        <label>Class timetable <small>filled in from your section</small><input type="url" id="wl-tt" placeholder="https://timetable.nithitsuki.com/…"></label>
        <label>AUMS username<input type="text" id="wl-au" value="${esc(pr.reg || "")}" autocomplete="off"></label>
        <label>AUMS password <small>for grades &amp; CGPA · stays encrypted on this device</small><input type="password" id="wl-ap" autocomplete="new-password" placeholder="Leave empty to add later"></label>
        ${isClassmates() ? `<label class="wl-share"><input type="checkbox" id="wl-share" checked><span>Share my name, roll number and section with the developer (Basare Mallikarjun), so he knows who uses the app. Nothing else is shared.</span></label>` : ""}
        <button class="btn primary wl-big">Finish</button></form>`;
    const sec = $("#wl-sec"), tt = $("#wl-tt");
    sec.oninput = () => { if (!tt.dataset.typed && sec.value.trim()) tt.value = `https://timetable.nithitsuki.com/${pr.batch}/${pr.branch.toLowerCase()}-${sec.value.trim().toLowerCase()}/${semesterNow(pr.batch)}`; };
    tt.oninput = () => { tt.dataset.typed = "1"; };
    sec.focus();
    $("#wl-form").onsubmit = async e => { e.preventDefault();
      const btn = e.target.querySelector("button"); btn.disabled = true; msg("");
      if (P().example) Object.assign(P(), { example: false, exams: [], sems: [{ id: uid(), name: "Sem " + semesterNow(pr.batch), subs: [] }], cur: 0, planDone: {}, att: { min: 75, subs: [] } });
      Object.assign(pr, { section: sec.value.trim().toUpperCase(), ttUrl: tt.value.trim() });
      await savePortal({ batch: +pr.batch, autoSync: true }); touch(); applyName();   // batch saved before the first sync numbers the semesters
      const u = $("#wl-au").value.trim(), pw = $("#wl-ap").value;
      if (u && pw) {
        try {
          if (droid) { const r = MyAppAndroid.saveAums(pw); if (r !== "ok") throw new Error(r); await api("/api/aums/signin", "POST", { username: u }); }
          else await api("/api/aums/signin", "POST", { username: u, password: pw });
        } catch (err) { msg(`<span class="err">AUMS: ${esc(err.message)}</span>`); btn.disabled = false; return; }
      }
      if (pr.ttUrl) syncTimetable(true);
      if ($("#wl-share")) { pr.shareOk = $("#wl-share").checked; touch(); if (pr.shareOk) reportInstall(pr); }
      syncPortal();                       // attendance, marks, gate pass
      if (u && pw) runAums(true);         // grades, credits, SGPA, CGPA (waits its turn)
      step3(!!(u && pw));
    };
  };

  // 3. done: syncs keep running in the background
  const step3 = aums => {
    dots(2);
    body.innerHTML = `<div class="wl-done"><div class="wl-tick" aria-hidden="true">✓</div><b>You're all set</b>
      <span>Attendance, marks and gate passes are syncing now${aums ? ", and AUMS grades and CGPA right after" : ""}. It takes about a minute, and keeps itself up to date every 3 hours.</span></div>
      <button class="btn primary wl-big" id="wl-go">Open my app</button>`;
    $("#wl-go").onclick = () => { dlg.close(); dlg.remove(); setTab("home"); };
  };

  step1();
  dlg.showModal();
}

/* college Wi-Fi (FortiGate) auto-login: Android app only */
function renderWifi() {
  const box = $("#wifi-box"), A = window.MyAppAndroid; if (!box || !A) return;
  const user = A.wifiUser();
  box.innerHTML = user
    ? `<span class="chip good">On for ${esc(user)}</span> <span class="small muted" id="wifi-st">${esc(A.wifiStatus())}</span> <button class="btn ghost sm" id="wifi-off">Turn off</button>`
    : `<form id="wifi-form" class="row" autocomplete="off"><input type="text" id="wifi-u" placeholder="Wi-Fi username" autocomplete="off" required>
        <input type="password" id="wifi-p" placeholder="Wi-Fi password" autocomplete="new-password" required><button class="btn primary sm">Save &amp; turn on</button></form>`;
  const f = $("#wifi-form"); if (f) f.onsubmit = e => { e.preventDefault(); const r = A.saveWifi($("#wifi-u").value.trim(), $("#wifi-p").value);
    if (r !== "ok") { box.insertAdjacentHTML("beforeend", `<p class="err small">${esc(r)}</p>`); return; } renderWifi(); setTimeout(renderWifi, 8000); };
  const off = $("#wifi-off"); if (off) off.onclick = () => { A.forgetWifi(); renderWifi(); };
}

/* =========================================================
   DASHBOARD
   ========================================================= */
function appName() { return (profile().appName || "My App").trim() || "My App"; }
function applyName() { $("#app-name").textContent = appName(); document.title = appName();
  const pr = profile(); $("#app-sub").textContent = `${pr.branch ? pr.branch + "-" + (pr.section || "") : ""} · ${(P().sems[P().cur] || {}).name || ""}`; }
$$("[data-go]").forEach(b => b.onclick = () => { if (b.dataset.sub) S.mirTab = b.dataset.sub; else if (b.dataset.go === "mirror" && /Grades/.test(b.textContent)) S.mirTab = "grades"; setTab(b.dataset.go); });
function renderHome() {
  applyName();
  $("#page-date").textContent = new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  if (!$("#home-kpis")) return;   // the Dashboard is just the tiles now
  const p = P(), m = S.mirror || {}, today = iso(Date.now()), min = +p.att.min || 75;
  const rows = m.attendance?.rows || [], eff = r => r.present + r.dl + r.medical;
  const tot = rows.reduce((s, r) => s + r.total, 0), pres = rows.reduce((s, r) => s + eff(r), 0), attPct = tot ? pres / tot * 100 : null;
  const low = rows.filter(r => r.total && eff(r) / r.total * 100 < min).length;
  const up = upcoming(), next = up[0];
  const ev = allEvents().filter(e => e.start <= today && (e.end || e.start) >= today);
  const sw = Cal.semWindow(), dayKind = ev.some(e => e.type === "holiday") ? ["H", "Non-working day", "var(--bad)"] : ["W", "Working day", "var(--good)"];
  const all = p.sems.map(s => semCalc(s, false)), cr = all.reduce((s, x) => s + x.cr, 0), cg = p.official?.cgpa || (cr ? (all.reduce((s, x) => s + x.pts, 0) / cr).toFixed(2) : "—");
  const gpL = (m.gatepass || []).map(x => ({ ...x, st: passState(x) })), gpLive = gpL.filter(x => ["out", "upcoming", "pending"].includes(x.st)).sort((a, b) => (Portal.passTime(a.from) || 0) - (Portal.passTime(b.from) || 0))[0];
  const kpi = (l, v, s, c) => `<div class="kpi" style="--kc:${c}"><span class="k-l">${l}</span><span class="k-v num">${v}</span><span class="k-s">${s}</span></div>`;
  $("#home-kpis").innerHTML =
    kpi("Today", `<span class="hw ${dayKind[0] === "E" ? "e" : dayKind[0] === "H" ? "h" : dayKind[0] === "W" ? "w" : ""}" style="width:38px;height:38px;font-size:1.3rem;border-radius:10px">${dayKind[0]}</span>`, dayKind[1] + (ev.find(e => e.type !== "holiday" || !e.weekly) ? " · " + esc((ev.find(e => !e.weekly) || {}).title || "") : ""), dayKind[2]) +
    kpi("CGPA", cg, p.official?.cgpa ? "official (AUMS)" : `${cr} credits graded`, "var(--accent)") +
    kpi("Attendance", attPct === null ? "—" : attPct.toFixed(1) + "%", attPct === null ? "sync myAmrita" : low ? `${low} course${low > 1 ? "s" : ""} below ${min}%` : `all courses ≥ ${min}%`, attPct !== null && attPct < min ? "var(--bad)" : "var(--good)") +
    kpi("Next exam", next ? (next.days === 0 ? "Today" : next.days + "d") : "—", next ? esc(next.sub) + " · " + new Date(next.date + "T00:00").toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "no exams added", "var(--b5)") +
    kpi("Gate pass", gpLive ? PASS_CHIP[gpLive.st][1] : "—", gpLive ? esc(gpLive.name) + " · " + fmtDT(gpLive.from) : "no active pass", gpLive?.st === "pending" ? "var(--warn)" : "var(--good)");
  renderTodayClasses();
  // exams this semester
  $("#home-exams").innerHTML = up.length ? `<table class="tbl"><thead><tr><th>Date</th><th>Course</th><th>Session</th><th>In</th></tr></thead><tbody>${up.slice(0, 8).map(e =>
    `<tr><td class="num">${new Date(e.date + "T00:00").toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" })}</td><td>${esc(e.sub)} <span class="pill e">${esc(e.type)}</span></td><td class="num">${e.time ? (e.time < "12:00" ? "FN " : "AN ") + e.time : "—"}</td><td><span class="pill ${e.days <= 3 ? "bad" : e.days <= 7 ? "warn" : "ok"}">${e.days === 0 ? "today" : e.days + " d"}</span></td></tr>`).join("")}</tbody></table>`
    : '<p class="muted small">No exams yet. Upload your exam timetable.</p>';
  // attendance by course (lowest first)
  const bar = (name, v, col, right) => `<div class="mini"><span class="nm" title="${esc(name)}">${esc(name)}</span><div class="track"><i style="width:${Math.min(100, v)}%;background:${col}"></i></div><span class="num small" style="text-align:right">${right}</span></div>`;
  $("#home-att").innerHTML = rows.length ? [...rows].sort((a, b) => eff(a) / a.total - eff(b) / b.total).map(r => { const v = eff(r) / r.total * 100; return bar(r.course, v, v < min ? "var(--bad)" : v < min + 5 ? "var(--warn)" : "var(--good)", v.toFixed(0) + "%"); }).join("") : '<p class="muted small">Sync myAmrita to see attendance.</p>';
  // internal marks this semester
  const sem = p.sems[p.cur] || { subs: [] }, ms = sem.subs.map(s => ({ s, c: subCalc(s) })).filter(x => x.c.pct !== null).sort((a, b) => a.c.pct - b.c.pct);
  $("#home-marks").innerHTML = ms.length ? ms.map(({ s, c }) => bar(s.n, c.pct, c.pct < 50 ? "var(--bad)" : c.pct < 70 ? "var(--warn)" : "var(--good)", c.pct.toFixed(0) + "%")).join("") + `<p class="small muted" style="margin:8px 0 0">${esc(sem.name)} internals so far${ms.some(x => x.s.projected) ? " (some projected)" : ""}.</p>` : '<p class="muted small">No internal marks yet.</p>';
  // gate pass
  const recent = gpL.slice(0, 4);
  $("#home-gp").innerHTML = recent.length ? `<table class="tbl"><tbody>${recent.map(x => `<tr><td>${esc(x.name)}</td><td class="small muted">${fmtDT(x.from)}</td><td><span class="pill ${x.st === "pending" ? "warn" : x.st === "rejected" ? "bad" : x.st === "cancelled" || x.st === "used" || x.st === "expired" ? "" : "ok"}">${PASS_CHIP[x.st][1]}</span></td></tr>`).join("")}</tbody></table>` : '<p class="muted small">No gate passes yet.</p>';
}

/* =========================================================
   TODAY'S CLASSES (class timetable + attendance: attend vs bunk)
   ========================================================= */
S.tt = null;
async function syncTimetable(force) {
  const url = profile().ttUrl; if (!url) return;
  if (!force && S.tt && S.tt.url === url && Date.now() - (S.tt.fetchedAt || 0) < 7 * DAY) return;   // weekly refresh
  try { S.tt = await api("/api/timetable/sync", "POST", { url }); if (S.tab === "home") renderTodayClasses(); }
  catch (e) { if (force) alert("Timetable: " + e.message); }
}
// labs count as 2 classes in attendance, the MFC lab as 3
const classWeight = s => !s.lab ? 1 : /mathematics for computing|^mfc$/i.test(s.name + "|" + s.short) || /^mfc$/i.test(s.short) ? 3 : 2;
const nrm = x => String(x || "").toLowerCase().replace(/[^a-z0-9]/g, "");
function attRowFor(slot) {
  const rows = S.mirror?.attendance?.rows || [];
  let r = rows.find(x => nrm(x.course) === nrm(slot.name));
  const sub = (S.tt?.subjects || []).find(s => s.name === slot.name);
  if (!r && sub) r = rows.find(x => x.code === sub.code || (x.code && x.code.slice(2) === sub.code.slice(2)));
  const el = (S.tt?.electives || []).filter(e => /[a-z]{3}/i.test(e)).map(nrm);
  if (!r && el.includes(nrm(slot.name))) r = rows.find(x => el.includes(nrm(x.course)));   // elective slot (BG) → your elective
  return r;
}
/* today's attendance per class, straight from myAmrita:
   absent  = today's date is in that course's Absent Report
   present = the course's total went up today (vs the start-of-day copy) and today isn't an absence
   otherwise the teacher hasn't entered it yet */
function todayStatus(r, dateIso) {
  const m = S.mirror || {}, key = r.code || r.course;
  const ab = (m.absent?.rows || []).find(x => (x.code && x.code === r.code) || nrm(x.course) === nrm(r.course));
  const absent = ab ? ab.dates.filter(d => d.date === dateIso).map(d => d.period) : [];
  const base = m.dayBase?.date === dateIso ? m.dayBase.totals[key] : undefined;
  const added = base === undefined ? null : (r.present + r.dl + r.medical) - base;
  if (absent.length) return { v: "a", periods: absent, added };
  const lv = (m.leaves || []).find(l => /approved/i.test(l.status) && l.from <= dateIso && l.to >= dateIso);
  if (lv) return { v: "l", type: lv.type, added };
  if (added > 0) return { v: "p", added };
  return { v: "", added };
}
function classesOn(dateIso) {
  const d = new Date(dateIso + "T00:00"), dow = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d.getDay()];
  const ev = allEvents().filter(e => e.start <= dateIso && (e.end || e.start) >= dateIso);
  return { dow, holiday: ev.find(e => e.type === "holiday"), exam: ev.find(e => e.type === "exam"), slots: (S.tt?.days || {})[dow] || [] };
}
function renderTodayClasses(boxSel = "#home-today", titleSel = "#home-today-title") {
  const box = $(boxSel); if (!box) return;
  if (!S.tt) { box.innerHTML = `<p class="muted small">Add your class timetable link in Settings → Profile${profile().ttUrl ? " (syncing…)" : ""}.</p>`; return; }
  const min = +P().att.min || 75, today = iso(Date.now());
  let day = today, info = classesOn(day), note = "";
  if (!info.slots.length || info.holiday) {   // nothing today: show the next class day
    note = info.holiday ? `Today is a holiday (${esc(info.holiday.weekly ? "weekend" : info.holiday.title.replace(/\s*\(holiday\)/i, ""))}).` : "No classes today.";
    for (let i = 1; i <= 14; i++) { const k = inDays(i), c = classesOn(k); if (c.slots.length && !c.holiday) { day = k; info = c; break; } }
  }
  $(titleSel).textContent = day === today ? "Today's classes" : `Next classes · ${new Date(day + "T00:00").toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "short" })}`;
  const pc = (a, t) => t ? a / t * 100 : 0;
  const isToday = day === today, seen = new Set();
  let nP = 0, nA = 0;
  const bellMin = sh => { const v = (P().alarmSubs || {})[sh]; return v === true ? (+S.portal.classLead || 5) : +v || 0; };
  const bell = s => { const mn = bellMin(s.short), on = mn || S.portal.classAlarm;
    return `<button class="bell ${on ? "on" : ""}" data-bell="${esc(s.short)}" aria-pressed="${!!on}" title="Alarm for ${esc(s.short)}">${on ? "🔔" : "🔕"}${mn ? `<small>${mn}m</small>` : ""}</button>`; };
  const rows = info.slots.map(s => {
    const r = attRowFor(s), w = classWeight(s);
    const head = `<div class="tcls-time">${s.start}<span>${s.end}</span></div><div class="tcls-main"><div><b>${esc(s.short)}</b> <span class="small muted">${esc(s.name)}</span>${s.lab ? ` <span class="pill e">LAB ×${w}</span>` : ""}</div>`;
    if (!r) return `<div class="tcls">${head}<div class="tcls-meta">Not in your attendance list</div></div><div class="tcls-right">${bell(s)}</div></div>`;
    const a = r.present + r.dl + r.medical, t = r.total, now = pc(a, t), att = pc(a + w, t + w), bunk = pc(a, t + w);
    const safe = bunk >= min, tight = safe && bunk < min + 2;
    const st = isToday ? todayStatus(r, today) : null;
    if (st && !seen.has(r.course)) { seen.add(r.course); if (st.v === "p") nP++; if (st.v === "a") nA++; }
    const statusPill = !st?.v
      ? `<span class="pill ${!safe ? "bad" : tight ? "warn" : "ok"}">${!safe ? "Don't bunk" : tight ? "Risky" : "Safe to bunk"}</span>`
      : st.v === "l" ? `<span class="pill e">${esc(st.type || "Leave")}</span>`
        : st.v === "a" ? `<span class="pill bad">Absent</span>`
          : st.v === "p" ? `<span class="pill ok">Present</span>` : `<span class="pill">Not updated</span>`;
    const meta = `Now <b>${now.toFixed(1)}%</b>` + (st?.v
      ? (st.v === "a" ? ` · period ${st.periods.join(", ")}` : "")
      : ` · if present <b style="color:var(--good)">${att.toFixed(1)}%</b> · if bunk <b style="color:${safe ? "inherit" : "var(--bad)"}">${bunk.toFixed(1)}%</b>`);
    return `<div class="tcls ${st?.v ? "marked-" + st.v : ""}">${head}<div class="tcls-meta">${meta}</div></div><div class="tcls-right">${bell(s)}${statusPill}</div></div>`;
  }).join("");
  const synced = S.mirror?.syncedAt ? new Date(S.mirror.syncedAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) : null;
  box.innerHTML = (note ? `<p class="small" style="margin:0 0 8px"><b>${note}</b> Here's your next class day.</p>` : "") +
    (info.exam ? `<p class="small" style="margin:0 0 8px"><span class="pill e">Exam</span> ${esc(info.exam.title)}</p>` : "") +
    (isToday && (nP || nA) ? `<p class="small" style="margin:0 0 8px">myAmrita today: <b style="color:var(--good)">${nP} present</b> · <b style="color:var(--bad)">${nA} absent</b></p>` : "") +
    (rows ? `<div class="tlist">${rows}</div>
      <p class="small muted" style="margin:10px 0 0">${isToday ? `Present / absent comes from myAmrita's Absent Report${synced ? ` (last synced ${synced})` : ""}; "Not updated" means the teacher hasn't entered it. ` : ""}Tap 🔕 on a class to set an alarm and choose how many minutes before. Medical leave counts as present. Labs count as 2 classes (MFC lab as 3). "Risky" = bunking leaves you within 2% of ${min}%.</p>` : '<p class="muted small">No classes found for the coming days.</p>');
  box.querySelectorAll("[data-bell]").forEach(b => b.onclick = () => {
    const sh = b.dataset.bell, slot = info.slots.find(x => x.short === sh), cur = bellMin(sh);
    let dlg = $("#bell-dlg");
    if (!dlg) { document.body.insertAdjacentHTML("beforeend", '<dialog id="bell-dlg" class="sheet"><div class="sheet-card" id="bell-body"></div></dialog>'); dlg = $("#bell-dlg"); dlg.onclick = e => { if (e.target === dlg) dlg.close(); }; }
    $("#bell-body").innerHTML = `<div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">🔔 Alarm for ${esc(sh)}</h3><button class="btn ghost sm" id="bell-x" aria-label="Close">✕</button></div>
      <p class="small muted" style="margin:6px 0 12px">${esc(slot?.name || sh)} · rings this many minutes before every ${esc(sh)} class, even on silent.</p>
      <div class="bellgrid">${[1, 2, 5, 10, 15, 20, 30].map(n => `<button class="btn ${cur === n ? "primary" : ""}" data-min="${n}">${n} min</button>`).join("")}</div>
      <button class="btn ghost danger" data-min="0" style="width:100%;margin-top:10px">${cur ? "Turn alarm off" : "No alarm"}</button>`;
    $("#bell-x").onclick = () => dlg.close();
    $$("#bell-body [data-min]").forEach(x => x.onclick = () => {
      const p = P(); p.alarmSubs = p.alarmSubs || {}; const n = +x.dataset.min;
      if (n) p.alarmSubs[sh] = n; else delete p.alarmSubs[sh];
      touch(); dlg.close(); renderTodayClasses(boxSel, titleSel);
    });
    dlg.showModal();
  });
}

function renderTodayPage() {
  const today = iso(Date.now()), info = classesOn(today), sw = Cal.semWindow();
  const kind = info.holiday || ((today < sw.start || today > sw.end) && new Date().getDay() === 0) ? ["H", "Non-working day", "var(--bad)", "h"] : ["W", "Working day", "var(--good)", "w"];
  const n = info.holiday ? 0 : info.slots.length, labs = info.holiday ? 0 : info.slots.filter(s => s.lab).length;
  const kpi = (l, v, s, c) => `<div class="kpi" style="--kc:${c}"><span class="k-l">${l}</span><span class="k-v num">${v}</span><span class="k-s">${s}</span></div>`;
  // current class = the one running now; next class = later today, or the first class of the next class day
  const toMin = hm => { const [h, m] = hm.split(":").map(Number); return h * 60 + m; };
  const nowD = new Date(), nowM = nowD.getHours() * 60 + nowD.getMinutes();
  const mins = d => d >= 60 ? `${Math.floor(d / 60)} h ${d % 60} min` : `${d} min`;
  const todaySlots = info.holiday ? [] : info.slots;
  const cur = todaySlots.find(s => toMin(s.start) <= nowM && nowM < toMin(s.end));
  let next = todaySlots.find(s => toMin(s.start) > nowM) ? { s: todaySlots.find(s => toMin(s.start) > nowM), day: today } : null;
  for (let i = 1; !next && i <= 14; i++) { const k = inDays(i), c = classesOn(k); if (c.slots.length && !c.holiday) next = { s: c.slots[0], day: k }; }
  const attMin = +P().att.min || 75, attOf = s => { const r = attRowFor(s); return r && r.total ? (r.present + r.dl + r.medical) / r.total * 100 : null; };
  const nextAtt = next ? attOf(next.s) : null;
  $("#today-kpis").innerHTML = kpi("Today", `<span class="hw ${kind[3]}" style="width:38px;height:38px;font-size:1.3rem;border-radius:10px">${kind[0]}</span>`, kind[1], kind[2]) +
    kpi("Classes", n, n ? `${labs} lab${labs === 1 ? "" : "s"}` : "none today", "var(--accent)") +
    kpi("Current class", cur ? esc(cur.short) : "—", cur ? `${cur.start}–${cur.end} · ends in ${mins(toMin(cur.end) - nowM)}` : n ? "no class right now" : "no classes today", cur ? "var(--good)" : "var(--muted)") +
    kpi("Next class", next ? `${esc(next.s.short)}${nextAtt != null ? " " + nextAtt.toFixed(0) + "%" : ""}` : "—",
      next ? `${next.day === today ? "" : new Date(next.day + "T00:00").toLocaleDateString(undefined, { weekday: "short" }) + " "}${next.s.start}${next.day === today ? " · in " + mins(toMin(next.s.start) - nowM) : " · " + esc(next.s.name)}` : "nothing coming up",
      nextAtt != null ? (nextAtt < attMin ? "var(--bad)" : nextAtt < attMin + 5 ? "var(--warn)" : "var(--good)") : "var(--accent)");
  clearTimeout(S.todayTimer); S.todayTimer = setTimeout(() => { if (S.tab === "today") renderTodayPage(); }, 30000);   // keep "current / next" live
  renderTodayClasses("#today-classes", "#today-title");
  const ev = allEvents().filter(e => e.start <= today && (e.end || e.start) >= today);
  $("#today-events").innerHTML = ev.length ? ev.map(e => evRow(e, false)).join("") : '<p class="muted small">Nothing on the calendar today.</p>';
}
// My Drive tile: opens the student's own folder link (asked once, editable in Profile → Edit details)
function openDrive() {
  const pr = profile();
  if (!pr.driveUrl) {
    const u = (prompt("Paste your Drive folder link (from Share → Copy link):") || "").trim();
    if (!/^https?:\/\//i.test(u)) { if (u) alert("That doesn't look like a link. It should start with https://"); return; }
    pr.driveUrl = u; touch();
  }
  window.open(pr.driveUrl, "_blank", "noopener");
}
// portal-style tiles on the Dashboard
$$(".tile").forEach(b => b.onclick = () => {
  if (S.homeEdit) return openIconEditor(b);
  const k = b.dataset.tile, sub = b.dataset.sub;
  if (k === "upload") return $("#up-open").click();
  if (k === "drive") return openDrive();
  if (k === "mirror" && sub) S.mirTab = sub;
  setTab(k);
});
// home screen pages: 8 app icons per page (4 × 2), swipe / drag / dots / arrow keys, like a phone launcher.
// Customize: rename, recolour, move or hide any icon; the layout is saved with your data (P().home).
const HOME_COLORS = ["#F97316", "#14B8A6", "#22C55E", "#6366F1", "#A855F7", "#EF4444", "#EC4899", "#84CC16", "#3B82F6", "#F59E0B", "#64748B", "#0EA5E9"];
const tileKey = t => t.dataset.tile + (t.dataset.sub ? ":" + t.dataset.sub : "");
S.tileNodes = null; S.homeEdit = false;
function homeLayout() { const p = P(); p.home = Object.assign({ order: [], hidden: [], colors: {}, labels: {} }, p.home || {}); return p.home; }
function buildPager() {
  if (!S.tileNodes) { const grid = $("#p-home .tiles"); if (!grid) return;
    S.tileNodes = [...grid.querySelectorAll(".tile")]; S.tileNodes.forEach(t => { t.dataset.label0 = t.querySelector(".tl").textContent; t.dataset.color0 = t.style.getPropertyValue("--tc"); });
    const holder = document.createElement("div"); holder.id = "home-screen"; grid.replaceWith(holder); }
  const L = homeLayout(), keys = S.tileNodes.map(tileKey);
  const order = [...L.order.filter(k => keys.includes(k)), ...keys.filter(k => !L.order.includes(k))];
  const shown = order.filter(k => !L.hidden.includes(k)).map(k => S.tileNodes[keys.indexOf(k)]);
  S.tileNodes.forEach(t => { const k = tileKey(t); t.querySelector(".tl").textContent = L.labels[k] || t.dataset.label0; t.style.setProperty("--tc", L.colors[k] || t.dataset.color0); });
  const holder = $("#home-screen"); holder.innerHTML = "";
  const pager = document.createElement("div"); pager.className = "pager" + (S.homeEdit ? " editing" : ""); pager.id = "home-pager"; pager.tabIndex = 0; pager.setAttribute("aria-label", "Home screen pages");
  const per = 1e9;   // one page you scroll down (vertical), 3 icons per row
  for (let i = 0; i < Math.max(1, shown.length); i += per) { const pg = document.createElement("div"); pg.className = "tiles-page"; shown.slice(i, i + per).forEach(t => pg.appendChild(t)); pager.appendChild(pg); }
  const pages = [...pager.children], dots = document.createElement("div"); dots.className = "dots";
  pages.forEach((_, i) => { const d = document.createElement("button"); d.setAttribute("aria-label", `Page ${i + 1}`); d.onclick = () => go(i); dots.appendChild(d); });
  const tools = document.createElement("div"); tools.className = "home-tools";
  tools.innerHTML = S.homeEdit ? `<span class="small muted">Drag icons to reorder · tap one to rename, recolour or hide.</span><button class="btn sm" id="home-reset">Reset</button><button class="btn primary sm" id="home-done">Done</button>` : `<button class="btn ghost sm" id="home-edit">✎ Customize</button>`;
  holder.append(pager, ...(pages.length > 1 ? [dots] : []), tools);
  if (S.homeEdit && L.hidden.length) { const h = document.createElement("div"); h.className = "home-hidden small";
    h.innerHTML = `<span class="muted">Hidden:</span> ` + L.hidden.filter(k => keys.includes(k)).map(k => `<button class="chip" data-unhide="${k}">＋ ${esc(L.labels[k] || S.tileNodes[keys.indexOf(k)].dataset.label0)}</button>`).join(" ");
    holder.append(h); h.querySelectorAll("[data-unhide]").forEach(b => b.onclick = () => { L.hidden = L.hidden.filter(x => x !== b.dataset.unhide); touch(); buildPager(); }); }
  const cur = () => Math.round(pager.scrollLeft / Math.max(1, pager.clientWidth));
  const go = i => pager.scrollTo({ left: Math.max(0, Math.min(pages.length - 1, i)) * pager.clientWidth, behavior: "smooth" });
  const mark = () => [...dots.children].forEach((d, i) => d.setAttribute("aria-current", i === cur()));
  pager.addEventListener("scroll", () => requestAnimationFrame(mark)); mark();
  pager.addEventListener("keydown", e => { if (e.key === "ArrowRight") go(cur() + 1); if (e.key === "ArrowLeft") go(cur() - 1); });
  if (S.homeEdit) {   // customize: press and drag an icon (finger or mouse) to a new spot; the order is saved on release
    let mv = null;
    pager.addEventListener("pointerdown", e => { const t = e.target.closest(".tile"); if (!t || e.button > 0) return;
      mv = { t, x: e.clientX, y: e.clientY, on: false, id: e.pointerId }; });
    pager.addEventListener("pointermove", e => { if (!mv || e.pointerId !== mv.id) return;
      if (!mv.on) { if (Math.hypot(e.clientX - mv.x, e.clientY - mv.y) < 8) return; mv.on = true; mv.t.classList.add("dragging"); pager.setPointerCapture(e.pointerId); closeIconEditor(); }
      e.preventDefault();
      mv.t.style.transform = `translate(${e.clientX - mv.x}px,${e.clientY - mv.y}px)`;
      const over = document.elementsFromPoint(e.clientX, e.clientY).map(el => el.closest?.(".tile")).find(x => x && x !== mv.t);
      if (over && over.parentNode === mv.t.parentNode) { const r = mv.t.getBoundingClientRect(), list = [...over.parentNode.children];
        over.parentNode.insertBefore(mv.t, list.indexOf(over) > list.indexOf(mv.t) ? over.nextSibling : over);
        const r2 = mv.t.getBoundingClientRect(); mv.x += r2.left - r.left; mv.y += r2.top - r.top;
        mv.t.style.transform = `translate(${e.clientX - mv.x}px,${e.clientY - mv.y}px)`; }
      const pr = pager.getBoundingClientRect();   // near the top/bottom edge: scroll the page along
      if (e.clientY > innerHeight - 60) scrollBy(0, 12); else if (e.clientY < Math.max(60, pr.top - 20)) scrollBy(0, -12); });
    const drop = e => { if (!mv) return; const m = mv; mv = null; if (!m.on) return;
      m.t.classList.remove("dragging"); m.t.style.transform = "";
      const L = homeLayout(), seen = [...pager.querySelectorAll(".tile")].map(tileKey);
      L.order = [...seen, ...keys.filter(k => !seen.includes(k))]; touch();
      pager.addEventListener("click", ev => { ev.stopPropagation(); ev.preventDefault(); }, { capture: true, once: true }); };
    pager.addEventListener("pointerup", drop); pager.addEventListener("pointercancel", drop);
  }
  let drag = null;   // mouse drag on the PC (touch already swipes natively)
  pager.addEventListener("pointerdown", e => { if (e.pointerType !== "mouse" || S.homeEdit) return; drag = { x: e.clientX, left: pager.scrollLeft, moved: 0 }; pager.style.scrollSnapType = "none"; });
  pager.onpointermove = e => { if (!drag) return; drag.moved = Math.abs(e.clientX - drag.x); pager.scrollLeft = drag.left - (e.clientX - drag.x); };
  const end = () => { if (!drag) return; const d = drag; drag = null; pager.style.scrollSnapType = "";
    const start = Math.round(d.left / pager.clientWidth), delta = pager.scrollLeft - d.left;
    go(Math.abs(delta) > pager.clientWidth * 0.18 ? start + Math.sign(delta) : start);
    if (d.moved > 6) pager.addEventListener("click", ev => { ev.stopPropagation(); ev.preventDefault(); }, { capture: true, once: true }); };
  pager.onpointerup = end; pager.onpointerleave = end;
  const ed = $("#home-edit"); if (ed) ed.onclick = () => { S.homeEdit = true; buildPager(); };
  const dn = $("#home-done"); if (dn) dn.onclick = () => { S.homeEdit = false; closeIconEditor(); buildPager(); };
  const rs = $("#home-reset"); if (rs) rs.onclick = () => { P().home = { order: [], hidden: [], colors: {}, labels: {} }; touch(); buildPager(); };
}
function closeIconEditor() { $("#icon-ed")?.remove(); }
function openIconEditor(t) {
  closeIconEditor();
  const L = homeLayout(), k = tileKey(t), keys = S.tileNodes.map(tileKey);
  const order = [...L.order.filter(x => keys.includes(x)), ...keys.filter(x => !L.order.includes(x))];
  const box = document.createElement("div"); box.id = "icon-ed"; box.className = "card icon-ed";
  box.innerHTML = `<div class="row" style="justify-content:space-between"><b>Edit icon</b><button class="btn ghost sm" data-x aria-label="Close">✕</button></div>
    <label class="small muted" for="ie-name">Name<input type="text" id="ie-name" value="${esc(t.querySelector(".tl").textContent)}" maxlength="18" style="width:100%"></label>
    <div class="small muted" style="margin-top:8px">Colour</div>
    <div class="swatches">${HOME_COLORS.map(c => `<button style="--sw:${c}" data-c="${c}" aria-label="Colour ${c}" ${(L.colors[k] || "").toLowerCase() === c.toLowerCase() ? 'aria-pressed="true"' : ""}></button>`).join("")}</div>
    <div class="row" style="margin-top:10px"><button class="btn sm" data-mv="-1">◀ Move earlier</button><button class="btn sm" data-mv="1">Move later ▶</button><button class="btn ghost sm danger" data-hide>Hide</button></div>`;
  $("#home-screen").append(box);
  box.querySelector("[data-x]").onclick = closeIconEditor;
  box.querySelector("#ie-name").onchange = e => { const v = e.target.value.trim(); if (v && v !== t.dataset.label0) L.labels[k] = v; else delete L.labels[k]; touch(); buildPager(); openIconEditor(t); };
  box.querySelectorAll("[data-c]").forEach(b => b.onclick = () => { L.colors[k] = b.dataset.c; touch(); buildPager(); openIconEditor(t); });
  box.querySelectorAll("[data-mv]").forEach(b => b.onclick = () => { const i = order.indexOf(k), j2 = i + +b.dataset.mv; if (j2 < 0 || j2 >= order.length) return;
    [order[i], order[j2]] = [order[j2], order[i]]; L.order = order; touch(); buildPager(); openIconEditor(t); });
  box.querySelector("[data-hide]").onclick = () => { if (!L.hidden.includes(k)) L.hidden.push(k); touch(); closeIconEditor(); buildPager(); };
}
/* =========================================================
   boot
   ========================================================= */
(async function boot() {
  if ("serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("/sw.js").catch(() => { });
  openNote(allNotes()[0].id); renderPlanner();
  history.replaceState({ tab: "home", i: 0 }, "", "#home"); S.navKey = "home"; setTab("home", false);
  document.fonts?.ready.then(() => { if (S.sub === "mindmap" && S.tab === "notes") mmDraw(); });
  // everything the first screens need is asked for at once (the phone's server answers them side by side)
  const later = { status: api("/api/status").catch(() => null), mirror: api("/api/mirror").catch(() => null), cache: api("/api/portal/cache").catch(() => null),
    aums: api("/api/aums/cache").catch(() => null), tt: api("/api/timetable").catch(() => null) };
  try {
    const [plan, notes] = await Promise.all([api("/api/planner"), api("/api/notes"), loadPortal()]);
    if (plan && plan.sems) S.planner = Object.assign({ hours: 3, planDone: {} }, plan);
    S.notes = Array.isArray(notes) ? notes : [];
    openNote(allNotes()[0].id); renderPlanner();
  } catch (e) { genMsg("Can't reach the Study Desk server. Is it running?", "err"); }
  try { const st = await later.status; if (st) Object.assign(STATUS, st); } catch { }
  refreshStatus(true);
  // offline copy of the portal; pick up syncs that ran in the background
  try {
    S.mirror = await later.mirror;
    const cache = await later.cache;
    if (cache && cache.results && cache.fetchedAt > (S.mirror?.syncedAt || 0)) await applyAmrita(cache.results);
  } catch { }
  renderMirror();
  if (S.tab === "portal") renderPortal();
  // AUMS: apply the newest grades/credits (the server refreshes them weekly when a sign-in is saved)
  try { const ac = await later.aums; if (ac && ac.fetchedAt && ac.fetchedAt !== P().aumsAt) aumsMsg(aumsSummary(applyAums(ac))); } catch { }
  // put every course back in the semester the portal lists it in (repairs data from older, miscounted syncs)
  if (S.mirror?.attendance?.rows?.length) { const before = JSON.stringify(P().sems); Portal.fixSems(S.mirror, P(), uid);
    if (JSON.stringify(P().sems) !== before) { touch(); renderPlanner(); renderMirror(); } }
  renderAumsSignin();
  loadPhoto();
  Lock.ready();
  if (!profile().roll) welcome(); else setTimeout(installsConsent, 4000);
  if (!isClassmates() && $("#admin-card")) $("#admin-card").hidden = false;
  if (window.MyAppAndroid) { $("#android-hub").hidden = false; $("#android-hub-now").textContent = "Connected to " + MyAppAndroid.hub(); if (MyAppAndroid.saveWifi) renderWifi(); }
  buildPager();
  try { S.tt = await later.tt; } catch { }
  syncTimetable(false).then(() => { if (S.tab === "home") renderHome(); });
  if (S.tab === "home") renderHome();
  // keep it fresh: sync on open when the last sync is over an hour old (PC only)
  if (canBrowse() && profile().roll && (S.portal.links || []).length && Date.now() - (S.portal.lastSync || 0) > 3600e3) syncPortal();
  setInterval(refreshStatus, 60000);
  setInterval(renderStrip, 30 * 60000);
})();
